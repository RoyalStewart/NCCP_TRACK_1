/********************************************************************************
** Form generated from reading UI file 'prismframeworkmainwindow.ui'
**
** Created: Tue Dec 20 15:17:29 2011
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRISMFRAMEWORKMAINWINDOW_H
#define UI_PRISMFRAMEWORKMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PrismFrameworkMainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *startScenarioManagerButton;
    QPushButton *startVisualizerButton;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QMainWindow *PrismFrameworkMainWindow)
    {
        if (PrismFrameworkMainWindow->objectName().isEmpty())
            PrismFrameworkMainWindow->setObjectName(QString::fromUtf8("PrismFrameworkMainWindow"));
        PrismFrameworkMainWindow->resize(640, 480);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(PrismFrameworkMainWindow->sizePolicy().hasHeightForWidth());
        PrismFrameworkMainWindow->setSizePolicy(sizePolicy);
        QIcon icon;
        icon.addFile(QString::fromUtf8("image/prism.png"), QSize(), QIcon::Normal, QIcon::Off);
        PrismFrameworkMainWindow->setWindowIcon(icon);
        centralWidget = new QWidget(PrismFrameworkMainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        sizePolicy.setHeightForWidth(centralWidget->sizePolicy().hasHeightForWidth());
        centralWidget->setSizePolicy(sizePolicy);
        centralWidget->setAutoFillBackground(false);
        startScenarioManagerButton = new QPushButton(centralWidget);
        startScenarioManagerButton->setObjectName(QString::fromUtf8("startScenarioManagerButton"));
        startScenarioManagerButton->setGeometry(QRect(75, 345, 210, 50));
        sizePolicy.setHeightForWidth(startScenarioManagerButton->sizePolicy().hasHeightForWidth());
        startScenarioManagerButton->setSizePolicy(sizePolicy);
        startScenarioManagerButton->setFocusPolicy(Qt::ClickFocus);
        startVisualizerButton = new QPushButton(centralWidget);
        startVisualizerButton->setObjectName(QString::fromUtf8("startVisualizerButton"));
        startVisualizerButton->setGeometry(QRect(355, 345, 210, 50));
        sizePolicy.setHeightForWidth(startVisualizerButton->sizePolicy().hasHeightForWidth());
        startVisualizerButton->setSizePolicy(sizePolicy);
        startVisualizerButton->setFocusPolicy(Qt::ClickFocus);
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(200, 440, 241, 16));
        QPalette palette;
        QBrush brush(QColor(224, 224, 224, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        QBrush brush1(QColor(146, 145, 144, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label->setPalette(palette);
        QFont font;
        font.setPointSize(7);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(200, 456, 241, 16));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_2->setPalette(palette1);
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignCenter);
        PrismFrameworkMainWindow->setCentralWidget(centralWidget);

        retranslateUi(PrismFrameworkMainWindow);

        QMetaObject::connectSlotsByName(PrismFrameworkMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *PrismFrameworkMainWindow)
    {
        PrismFrameworkMainWindow->setWindowTitle(QApplication::translate("PrismFrameworkMainWindow", "SUNPRISM Framework Tools", 0, QApplication::UnicodeUTF8));
        startScenarioManagerButton->setText(QApplication::translate("PrismFrameworkMainWindow", "SUNPRISM Scenario Manager", 0, QApplication::UnicodeUTF8));
        startVisualizerButton->setText(QApplication::translate("PrismFrameworkMainWindow", "SUNPRISM Visualizer", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("PrismFrameworkMainWindow", "Copyright by Sohei Okamoto 2011", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("PrismFrameworkMainWindow", "All Rights Reserved", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class PrismFrameworkMainWindow: public Ui_PrismFrameworkMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRISMFRAMEWORKMAINWINDOW_H
