/********************************************************************************
** Form generated from reading UI file 'prismframeworkmainwindow.ui'
**
** Created: Fri Oct 14 14:25:37 2011
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRISMFRAMEWORKMAINWINDOW_H
#define UI_PRISMFRAMEWORKMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PrismFrameworkMainWindow
{
public:
    QWidget *centralWidget;
    QMenuBar *menuBar;
    QMenu *menuTest;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *PrismFrameworkMainWindow)
    {
        if (PrismFrameworkMainWindow->objectName().isEmpty())
            PrismFrameworkMainWindow->setObjectName(QString::fromUtf8("PrismFrameworkMainWindow"));
        PrismFrameworkMainWindow->resize(600, 400);
        centralWidget = new QWidget(PrismFrameworkMainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        PrismFrameworkMainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(PrismFrameworkMainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 21));
        menuTest = new QMenu(menuBar);
        menuTest->setObjectName(QString::fromUtf8("menuTest"));
        PrismFrameworkMainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(PrismFrameworkMainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        PrismFrameworkMainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(PrismFrameworkMainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        PrismFrameworkMainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuTest->menuAction());

        retranslateUi(PrismFrameworkMainWindow);

        QMetaObject::connectSlotsByName(PrismFrameworkMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *PrismFrameworkMainWindow)
    {
        PrismFrameworkMainWindow->setWindowTitle(QApplication::translate("PrismFrameworkMainWindow", "PrismFrameworkMainWindow", 0, QApplication::UnicodeUTF8));
        menuTest->setTitle(QApplication::translate("PrismFrameworkMainWindow", "test", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class PrismFrameworkMainWindow: public Ui_PrismFrameworkMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRISMFRAMEWORKMAINWINDOW_H
