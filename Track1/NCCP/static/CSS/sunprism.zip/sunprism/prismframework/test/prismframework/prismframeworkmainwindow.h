#ifndef PRISMFRAMEWORKMAINWINDOW_H
#define PRISMFRAMEWORKMAINWINDOW_H

#include <QMainWindow>

namespace Ui {
    class PrismFrameworkMainWindow;
}

class PrismFrameworkMainWindow : public QMainWindow {
    Q_OBJECT
public:
    PrismFrameworkMainWindow(QWidget *parent = 0);
    ~PrismFrameworkMainWindow();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::PrismFrameworkMainWindow *ui;
};

#endif // PRISMFRAMEWORKMAINWINDOW_H
