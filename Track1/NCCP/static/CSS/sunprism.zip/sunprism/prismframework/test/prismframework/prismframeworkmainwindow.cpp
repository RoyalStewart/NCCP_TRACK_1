#include "prismframeworkmainwindow.h"
#include "ui_prismframeworkmainwindow.h"

PrismFrameworkMainWindow::PrismFrameworkMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PrismFrameworkMainWindow)
{
    ui->setupUi(this);
}

PrismFrameworkMainWindow::~PrismFrameworkMainWindow()
{
    delete ui;
}

void PrismFrameworkMainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
