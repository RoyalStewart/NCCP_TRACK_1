#include "prismframeworkmainwindow.h"
#include "ui_prismframeworkmainwindow.h"


PrismFrameworkMainWindow::PrismFrameworkMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PrismFrameworkMainWindow)
{
    // TODO: this is quick solution to ensure image and other path-dependent loading
    // it should change the loading to use the application path, and utilize "resource" registeration
    QDir::setCurrent(QCoreApplication::applicationDirPath());
    
    ui->setupUi(this);

    setStyleSheet("#centralWidget {background-image: url(image/prism_framework_tools_background2.png) }");
    
    
    QObject::connect( &process, SIGNAL(error(QProcess::ProcessError)), 
                      this, SLOT(processError(QProcess::ProcessError)) );
    
    connect( ui->startScenarioManagerButton, SIGNAL(clicked()),
             this, SLOT(startScenarioManager()) );
    
    connect( ui->startVisualizerButton, SIGNAL(clicked()),
             this, SLOT(startVisualizer()) );
}


PrismFrameworkMainWindow::~PrismFrameworkMainWindow()
{
    delete ui;
}


void PrismFrameworkMainWindow::processError(QProcess::ProcessError error)
{
	switch(error)
	{
	case QProcess::FailedToStart:
		QMessageBox::information(0,"FailedToStart","FailedToStart");
		break;
	case QProcess::Crashed:
		QMessageBox::information(0,"Crashed","Crashed");
		break;
	case QProcess::Timedout:
		QMessageBox::information(0,"FailedToStart","FailedToStart");
		break;
	case QProcess::WriteError:
		QMessageBox::information(0,"Timedout","Timedout");
		break;
	case QProcess::ReadError:
		QMessageBox::information(0,"ReadError","ReadError");
		break;
	case QProcess::UnknownError:
		QMessageBox::information(0,"UnknownError","UnknownError");
		break;
	default:
		QMessageBox::information(0,"default","default");
		break;
	}
}


void PrismFrameworkMainWindow::startScenarioManager()
{
	process.start("../prism_latest/prism");
}


void PrismFrameworkMainWindow::startVisualizer()
{
	process.start("../prism_visualizer_latest/prismvisualizer/prismvisualizer");
}

