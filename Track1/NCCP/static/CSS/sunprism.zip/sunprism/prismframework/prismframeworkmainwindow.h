#ifndef PRISMFRAMEWORKMAINWINDOW_H
#define PRISMFRAMEWORKMAINWINDOW_H

#include <QtGui>
#include <QProcess>

namespace Ui {
    class PrismFrameworkMainWindow;
}


class PrismFrameworkMainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    PrismFrameworkMainWindow(QWidget *parent = 0);
    ~PrismFrameworkMainWindow();
    
    void processError(QProcess::ProcessError err);
    
private slots:
    void startScenarioManager();
    void startVisualizer();

private:
    Ui::PrismFrameworkMainWindow *ui;
    
	QProcess process;
};

#endif // PRISMFRAMEWORKMAINWINDOW_H

