#include <QtGui/QApplication>
#include "prismframeworkmainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    PrismFrameworkMainWindow w;
    w.show();
    return a.exec();
}
