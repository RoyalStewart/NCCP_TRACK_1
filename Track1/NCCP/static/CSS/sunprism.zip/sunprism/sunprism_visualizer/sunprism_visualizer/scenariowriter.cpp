/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scenariowriter.h"

#include <QtGui>


ScenarioWriter::ScenarioWriter(map<QString, QString> *scenario_info_list, vector<Unit*> *unit_list)
{
    scenarioInfoList = scenario_info_list;
    unitList = unit_list;
  
    xml_writer.setAutoFormatting(true);
}


bool ScenarioWriter::writeScenario(QIODevice *device)
{
    xml_writer.setDevice(device);

    xml_writer.writeStartDocument();

    xml_writer.writeStartElement("scenario");

    map<QString, QString>::iterator iterator;
    for( iterator = scenarioInfoList->begin(); iterator != scenarioInfoList->end(); iterator++ )
    {
        xml_writer.writeTextElement(iterator->first, iterator->second);
    }    
    
    for( int i = 0; i < unitList->size(); i++ )
    {
        //get unit
        Unit *unit = (*unitList)[i];

        writeUnit(unit);
    }

    xml_writer.writeEndElement();

    xml_writer.writeEndDocument();

    return true;
}


void ScenarioWriter::writeUnit(Unit *unit)
{
    xml_writer.writeStartElement("unit");

    xml_writer.writeAttribute("type", unit->getElementType()->getNameType());
    xml_writer.writeAttribute("cmdr", QString::number(unit->getOwnerID()));
    
    if( unit->getUnitID() >= 0 )
    {
        xml_writer.writeAttribute("unit_id", QString::number(unit->getUnitID()));
    }
    
    xml_writer.writeTextElement("name", unit->getName());
    xml_writer.writeTextElement("x", QString::number(unit->getX()));
    xml_writer.writeTextElement("y", QString::number(unit->getY()));
    xml_writer.writeTextElement("course", QString::number(unit->getCourse()));
    xml_writer.writeTextElement("velocity", QString::number(unit->getVelocity()));

    ElementType *element_type = unit->getElementType();

    for( unsigned int property_index = 0; property_index < element_type->getPropSize(); property_index++ )
    {
        char* property_name = element_type->getPropName(property_index);
        float property_value = unit->getProperty(property_name);
        xml_writer.writeTextElement(property_name, QString::number(property_value));
    }             
    
    xml_writer.writeEndElement();
}
