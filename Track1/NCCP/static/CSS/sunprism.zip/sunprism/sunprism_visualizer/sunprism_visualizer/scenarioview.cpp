/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include <QtGui>
#include <QtOpenGL>

#include <math.h>

#include "scenarioview.h"


ScenarioView::ScenarioView(QWidget *parent) :
    QGLWidget(QGLFormat(QGL::SampleBuffers), parent)
{
    setFocusPolicy(Qt::StrongFocus);
    
    setMouseTracking(true);
    
    mouseMode = NONE;
    
    viewScale[0] = 1.0;
    viewScale[1] = 1.0;
    viewScale[2] = 1.0;
    
    scene = NULL;
}


ScenarioView::~ScenarioView()
{
}


QSize ScenarioView::minimumSizeHint() const
{
    return QSize(50, 50);
}


QSize ScenarioView::sizeHint() const
{
    return QSize(400, 400);
}


void ScenarioView::setScene(SceneInterface *scene)
{
    this->scene = scene;
    
    connect(this->scene->getQObject(), SIGNAL(sceneSelectionChanged()),
            this, SIGNAL(sceneSelectionChanged()));
    
    // TODO: pay attention for multi-context rendering
    initializeGL();
        
    updateGL();
}


void ScenarioView::setMouseMode(MOUSE_MODE mouse_mode)
{
    mouseMode = mouse_mode;
    
    /*
    switch(mouseMode)
    {
        case NONE:
            //viewport()->unsetCursor();
            //unsetCursor();
            viewport()->setCursor(Qt::OpenHandCursor);
            setCursor(Qt::OpenHandCursor);
            
            setDragMode(ScrollHandDrag);
            break;
        case PICK_LOCATION:
            viewport()->setCursor(Qt::CrossCursor);
            setCursor(Qt::CrossCursor);
            
            setDragMode(NoDrag);
            break;
        case PICK_TARGET:
            viewport()->setCursor(Qt::ArrowCursor);
            setCursor(Qt::ArrowCursor);
            
            setDragMode(NoDrag);
            break;
    }
    */
}


void ScenarioView::setSimulationMode(bool simulation_mode)
{
    if( scene != NULL )
    {
        scene->setSimulationMode(simulation_mode);
    }
}


void ScenarioView::scale(float dx, float dy, float dz)
{
    viewScale[0] *= dx;
    viewScale[1] *= dy;
    viewScale[2] *= dz;
    
    updateGL();
}


void ScenarioView::updateScenarioScene(double delta_time)
{
    if( scene != NULL )
    {
        scene->updateScene(delta_time);
        
        updateGL();
    }
}


void ScenarioView::initializeGL()
{
    if( scene != NULL )
    {
        scene->initializeScene();
    }
}


void ScenarioView::paintGL()
{
    if( scene != NULL )
    {
        scene->drawScene();
    }
    else
    {
        glClearColor(1.0, 1.0, 1.0, 0.0);
        glClearDepth(1.0);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
}


void ScenarioView::resizeGL(int width, int height)
{
    int side = qMax(width, height);
    glViewport((width - side) / 2, (height - side) / 2, side, side);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    //glOrtho(-0.5, +0.5, -0.5, +0.5, 4.0, 15.0);
    //glOrtho(-textureImage.width()*3, textureImage.width()*3, -textureImage.height()*3, textureImage.height()*3, -textureImage.height()*3, textureImage.height()*3);
    
    side = 1.0;
    //glOrtho(-side, side, -side, side, -textureImage.height(), textureImage.height());
    glFrustum(-side, side, -side, side, 1.0, 100000.0); // TODO: far-value should be determined based on map size
    
    glMatrixMode(GL_MODELVIEW);
}


void processHits2 (GLint hits, GLuint buffer[])
{
   unsigned int i, j;
   GLuint names, *ptr, minZ,*ptrNames, numberOfNames;

   printf ("hits = %d\n", hits);
   ptr = (GLuint *) buffer;
   minZ = 0xffffffff;
   for (i = 0; i < hits; i++) {	
      names = *ptr;
	  ptr++;
	  if (*ptr < minZ) {
		  numberOfNames = names;
		  minZ = *ptr;
		  ptrNames = ptr+2;
	  }
	  
	  ptr += names+2;
	}
  printf ("The closest hit names are ");
  ptr = ptrNames;
  for (j = 0; j < numberOfNames; j++,ptr++) {
     printf ("%d ", *ptr);
  }
  printf ("\n");
   
}


void ScenarioView::mousePressEvent(QMouseEvent *event)
{
    if( scene != NULL )
    {
        lastPos = event->pos();
     
        if( event->button() == Qt::LeftButton )
        {
            scene->setButtonState("button3", true);
        }
        if( event->button() == Qt::RightButton )
        {
            scene->setButtonState("button1", true);
        }
    }
}


void ScenarioView::mouseReleaseEvent(QMouseEvent *event)
{
    if( scene != NULL )
    {
        if( event->button() == Qt::LeftButton )
        {
            scene->setButtonState("button3", false);
        }
        if( event->button() == Qt::RightButton )
        {
            scene->setButtonState("button1", false);
        }
    }
}

        
void ScenarioView::mouseMoveEvent(QMouseEvent *event)
{
    if( scene != NULL )
    {
        int x = event->pos().x();
        int y = event->pos().y();
        
        GLint viewport[4];
        GLdouble modelview[16];
        GLdouble projection[16];
        GLfloat window_x, window_y, window_z;
        GLdouble world_x, world_y, world_z;
     
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
        glGetDoublev(GL_PROJECTION_MATRIX, projection);
        glGetIntegerv(GL_VIEWPORT, viewport);
     
        window_x = (float)x;
        window_y = (float)viewport[3] - (float)y;
        glReadPixels(x, int(window_y), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &window_z);
     
        gluUnProject(window_x, window_y, window_z, modelview, projection, viewport, &world_x, &world_y, &world_z);
     
        scene->setWandPosition(world_x, world_y, world_z);
        //scene->setWandPosition(winX, winY, 0);
    }
    
#if 0
    int dx = event->x() - lastPos.x();
    int dy = event->y() - lastPos.y();

    if( event->buttons() & Qt::LeftButton )
    {
        int x_angle = viewRotation[0] + 8 * dy;
        int y_angle = viewRotation[1] + 8 * dx;
        int z_angle = viewRotation[2];
        
        setRotation(x_angle, y_angle, z_angle);
    }
    else if( event->buttons() & Qt::RightButton )
    {
        int x_angle = viewRotation[0] + 8 * dy;
        int y_angle = viewRotation[1];
        int z_angle = viewRotation[2] + 8 * dx;
        
        setRotation(x_angle, y_angle, z_angle);
    }
    
    lastPos = event->pos();
#endif
}


void ScenarioView::wheelEvent(QWheelEvent *event)
{    
    //QGraphicsScene::wheelEvent(event);
    //if (event->isAccepted())
    //    return;
#if 0
    // wheel scroll forward gives positive delta
    // and backward gives negative delta
    float delta_scale = 1.0 + event->delta() / 120 / 10.0; 
    
    scale(delta_scale, delta_scale, delta_scale);
    
    event->accept();
    
    updateGL();
#endif
}


void ScenarioView::keyPressEvent(QKeyEvent *event)
{   
    if( scene != NULL )
    {
        switch( event->key() )
        {
            case Qt::Key_Up:
            case Qt::Key_Down:
            case Qt::Key_Left:
            case Qt::Key_Right:
            case Qt::Key_R:
                scene->setKeyboardModifiers(event->modifiers());
                
                scene->setKeyState((Qt::Key)event->key(), true);
                
                break;
                
            default:
                QGLWidget::keyPressEvent(event);
                break;
        }
    }
}


void ScenarioView::keyReleaseEvent(QKeyEvent *event)
{   
    if( scene != NULL )
    {
        switch( event->key() )
        {
            case Qt::Key_Up:
            case Qt::Key_Down:
            case Qt::Key_Left:
            case Qt::Key_Right:
            case Qt::Key_R:
                scene->setKeyboardModifiers(event->modifiers());
                
                scene->setKeyState((Qt::Key)event->key(), false);
                
                break;
                
            default:
                QGLWidget::keyPressEvent(event);
                break;
        }
    }
}
