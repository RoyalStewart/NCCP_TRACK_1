/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scene.h"

#include "scenedefinitionreader.h"

#include <GL/glut.h>

static const double PI = 3.14159265358979323846264338327950288419717;
#ifndef degree_to_radian
#define degree_to_radian(degree) ((degree) * PI/180.0) 
#endif


Scene::Scene()
{
    viewPosition[0] = 0.0;
    viewPosition[1] = 0.0;
    viewPosition[2] = 0.0;
    
    viewDirection[0] = 0.0;
    viewDirection[1] = 0.0;
    viewDirection[2] = 0.0;
    
    keyboardModifiers = Qt::NoModifier;
    
    wandPosition[0] = 0.0;
    wandPosition[1] = 0.0;
    wandPosition[2] = 0.0;
    
    //wandDirection[0] = 0.0;
    //wandDirection[1] = 180.0;
    //wandDirection[2] = 0.0;
    
    pointedScenarioObject = NULL;
    selectedScenarioObject = NULL;
    
    simulationMode = false;
    
    wandMode = SELECT_OBJECT;
    
    pointedCommandNum = -1;
    selectedCommandNum = -1;
}


QString Scene::getName()
{
    return "defaultscene";
}


QObject* Scene::getQObject()
{
    return this;
}


void Scene::readSceneDefinition()
{
    QString scene_definition_file_name = "scene/" + getName() + ".scn";
    QFile scene_definition_file(scene_definition_file_name);
        
    if ( !scene_definition_file.open(QIODevice::ReadOnly | QIODevice::Text) )
    {
        fprintf(stderr, "ERROR: cannot open scene definition file\n");
        
        return;
    }
    
    SceneDefinitionReader scene_definition_reader(&sceneDefinition);
        
    if( !scene_definition_reader.read(&scene_definition_file) )
    {
        fprintf(stderr, "ERROR: cannot read scene definition file\n");
    
        return;
    }
}


bool Scene::readScene(QIODevice *device)
{
    xml_reader.setDevice(device);

    if( xml_reader.readNextStartElement() )
    {
        if( xml_reader.name() == "scenario" )
        {
            readScenario();
            
            if( !scenarioInfoList.value("terrain").isEmpty() )
            {
                terrain.load(scenarioInfoList.value("terrain").toLocal8Bit().data());
            }
        }
        else
        {
            xml_reader.raiseError(QObject::tr("The file is not an Scenario file."));
        }
    }

    return !xml_reader.error();
}


QString Scene::errorString() const
{
    return QObject::tr("%1\nLine %2, column %3")
            .arg(xml_reader.errorString())
            .arg(xml_reader.lineNumber())
            .arg(xml_reader.columnNumber());
}


void Scene::readScenario()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "scenario");
    
    QMap<QString, ScenarioObject*> remove_scenario_object_list = scenarioObjectList;
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "object" )
        {
            QString scenario_object_id = xml_reader.attributes().value("object_id").toString();
            
            QString object_type_name = xml_reader.attributes().value("object_type").toString();
            
            scenarioObject = scenarioObjectList.value(scenario_object_id);

            if( scenarioObject == NULL )
            {
                scenarioObject = createSceneObject(object_type_name);
                
                scenarioObject->setScenarioObjectID(scenario_object_id);
                
                ScenarioObjectType *object_type = sceneDefinition.getScenarioObjectTypeList()->value(object_type_name);

                scenarioObject->setScenarioObjectType(object_type);
                 
                scenarioObjectList.insert(scenario_object_id, scenarioObject);
            }
            else
            {
                remove_scenario_object_list.remove(scenario_object_id);
            }
            
            // put everything in field value list for now
            scenarioObject->getFieldValueList()->insert("object_id", scenario_object_id);
            
            readScenarioObject();
        }
        else
        {
            //xml_reader.skipCurrentElement();
            
            QString value = xml_reader.readElementText();
            
            scenarioInfoList.insert(name, value);
        }
    }

    QMap<QString, ScenarioObject*>::const_iterator remove_iterator = remove_scenario_object_list.constBegin();

    while( remove_iterator != remove_scenario_object_list.constEnd() )
    {
        scenarioObjectList.remove(remove_iterator.key());
        
        delete remove_iterator.value();
        
        ++remove_iterator;
    }    
}


void Scene::readScenarioObject()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "object");
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "translation" )
        {
            QString value_string = xml_reader.readElementText();

            QStringList value_string_list = value_string.split(":");
            if( value_string_list.size() == 3 )                
            {
                scenarioObject->setTranslation(value_string_list[0].toDouble(), value_string_list[1].toDouble(), value_string_list[2].toDouble());
            }
            
            // put everything in field value list for now
            scenarioObject->getFieldValueList()->insert(name, value_string);
        }
        else if( name == "scale" )
        {
            QString value_string = xml_reader.readElementText();

            QStringList value_string_list = value_string.split(":");
            if( value_string_list.size() == 3 )                
            {
                scenarioObject->setScale(value_string_list[0].toDouble(), value_string_list[1].toDouble(), value_string_list[2].toDouble());
            }
            
            // put everything in field value list for now
            scenarioObject->getFieldValueList()->insert(name, value_string);
        }
        else if( name == "velocity" )
        {
            QString value_string = xml_reader.readElementText();

            QStringList value_string_list = value_string.split(":");
            if( value_string_list.size() == 3 )                
            {
                scenarioObject->setVelocity(value_string_list[0].toDouble(), value_string_list[1].toDouble(), value_string_list[2].toDouble());
            }
            
            // put everything in field value list for now
            scenarioObject->getFieldValueList()->insert(name, value_string);
        }                
        else
        {
            QString value = xml_reader.readElementText();
            
            scenarioObject->getFieldValueList()->insert(name, value);
        }
    }
}


ScenarioObject* Scene::createSceneObject(QString object_type_name)
{
    ScenarioObject *scene_object = new ScenarioObject(this);
    
    return scene_object;
}

void Scene::initializeScene()
{
    /* 0 = directional, 1 = location */
    GLfloat	position_0[4] = {1.0, -10.0, 10.0, -10.0},
            ambient_0[4] = {0.5, 0.5, 0.5, 1.0},
            diffuse_0[4] = {0.8, 0.8, 0.8, 1.0},
            specular_0[4] = {0.2, 0.2, 0.2, 1.0};


    GLfloat light_diffuse[] = {1.0, 1.0, 1.0, 1.0};  /* Red diffuse light. */
    GLfloat light_position[] = {1.0, 1.0, 1.0, 0.0};  /* Infinite light location. */

    /* set the polygon shading parameters */
    glShadeModel(GL_SMOOTH);

    glEnable(GL_LIGHTING);

    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient_0);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular_0);
    glEnable(GL_LIGHT0);
    //SO glDisable(GL_LIGHTING);

    //glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    //glEnable(GL_COLOR_MATERIAL);

    /* These two lines cause the vertex colors to be used (otherwise all is grey) */
    glColorMaterial(GL_FRONT, GL_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);
    
    // anti-aliasing
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

#if 0
    GLfloat mat_specular[] = {0.3, 0.3, 0.3, 1.0};
    GLfloat mat_shininess[] = { 10.0 };
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
#endif

    glEnable(GL_NORMALIZE);	/* this is required when calling glScalef() w/ lighting */

    //SO Maybe use the following: see drawing.c
    //glDepthFunc(GL_LEQUAL);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glEnable(GL_MULTISAMPLE);
    //SO glCullFace(GL_BACK);

    /* set the line parameters */
    glLineWidth(2.0);
}


void Scene::drawScene()
{
    lock.lockForRead();
    
    glEnable(GL_LIGHTING);
    //glEnable(GL_TEXTURE_2D);
    
    glClearColor(0.7, 0.7, 0.9, 0.0);
    glClearDepth(1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();	

    glPushMatrix();
    
    // view transformation
    //glScalef(worldScale, worldScale, worldScale);
    glRotatef(-viewDirection[0], 1.0, 0.0, 0.0);
    glRotatef(-viewDirection[1], 0.0, 1.0, 0.0);
    glRotatef(-viewDirection[2], 0.0, 0.0, 1.0);
    glTranslatef(-viewPosition[0], -viewPosition[1], -viewPosition[2]);
    
    //TODO: determine where the global light position based on map
    // fix light position relative to world (not view location)
    GLfloat	light_position[4] = {0.0, 7000.0, 3000.0, 1.0};
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    
    if( !scenarioInfoList.value("terrain").isEmpty() )
    {
        terrain.draw();
    }

#if 0
		glBegin(GL_QUADS);
			// Front Face
			glVertex3f(-1.0f, -1.0f,  1.0f);
			glVertex3f( 1.0f, -1.0f,  1.0f);
			glVertex3f( 1.0f,  1.0f,  1.0f);
			glVertex3f(-1.0f,  1.0f,  1.0f);
			// Back Face
			glVertex3f(-1.0f, -1.0f, -1.0f);
			glVertex3f(-1.0f,  1.0f, -1.0f);
			glVertex3f( 1.0f,  1.0f, -1.0f);
			glVertex3f( 1.0f, -1.0f, -1.0f);
			// Top Face
			glVertex3f(-1.0f,  1.0f, -1.0f);
			glVertex3f(-1.0f,  1.0f,  1.0f);
			glVertex3f( 1.0f,  1.0f,  1.0f);
			glVertex3f( 1.0f,  1.0f, -1.0f);
			// Bottom Face
			glVertex3f(-1.0f, -1.0f, -1.0f);
			glVertex3f( 1.0f, -1.0f, -1.0f);
			glVertex3f( 1.0f, -1.0f,  1.0f);
			glVertex3f(-1.0f, -1.0f,  1.0f);
			// Right face
			glVertex3f( 1.0f, -1.0f, -1.0f);
			glVertex3f( 1.0f,  1.0f, -1.0f);
			glVertex3f( 1.0f,  1.0f,  1.0f);
			glVertex3f( 1.0f, -1.0f,  1.0f);
			// Left Face
			glVertex3f(-1.0f, -1.0f, -1.0f);
			glVertex3f(-1.0f, -1.0f,  1.0f);
			glVertex3f(-1.0f,  1.0f,  1.0f);
			glVertex3f(-1.0f,  1.0f, -1.0f);
		glEnd();
#endif

    QMap<QString, ScenarioObject*>::const_iterator scenario_object_iterator = scenarioObjectList.constBegin();
    
    while( scenario_object_iterator != scenarioObjectList.constEnd() )
    {
        ScenarioObject *scenario_object = scenario_object_iterator.value();
        
        scenario_object->draw();
    
        ++scenario_object_iterator;
    }    
    
    glPopMatrix();
    
#if 0
    // draw wand    
    glPushMatrix();
    
    glTranslatef(wandPosition[0], wandPosition[1], wandPosition[2]);
    
    glRotatef(-wandDirection[0], 1.0, 0.0, 0.0);
    glRotatef(-wandDirection[1], 0.0, 1.0, 0.0);
    glRotatef(-wandDirection[2], 0.0, 0.0, 1.0);
    
    glutSolidCone(100, 100, 10, 2);
    
    glPopMatrix();
#endif


#if 1
    // draw wand line    
    glPushMatrix();
    
    glTranslatef(wandPosition[0], wandPosition[1], wandPosition[2]);
    
    glRotatef(-wandDirection[0], 1.0, 0.0, 0.0);
    glRotatef(-wandDirection[1], 0.0, 1.0, 0.0);
    glRotatef(-wandDirection[2], 0.0, 0.0, 1.0);
    
    glTranslatef(0.0, 0.0, -25.0);
    glScalef(0.03, 0.03, 50.0);
    
    glutSolidCube(1.0);
    
    glPopMatrix();
#endif


    if( wandMode == SELECT_COMMAND )
    {
        drawCommand();
    }
    
    
    lock.unlock();
}


void Scene::drawCommand(bool selection_mode)
{
    int highlight = pointedCommandNum;
    
    // get flags
    GLboolean gl_lighting = getGLBoolean(GL_LIGHTING);
    
    // get current color
    GLfloat gl_current_color[4];
    glGetFloatv(GL_CURRENT_COLOR, gl_current_color);
             
    /* make the text bright regardless of light */
    glDisable(GL_LIGHTING);
       
    //if( status == SELECT_CMD )
    {
        QVector<Command*>* command_vector = NULL;
        
        if( selectedScenarioObject != NULL )  // scenario object's type commands
        {
            ScenarioObjectType *scenario_object_type = selectedScenarioObject->getScenarioObjectType();
         
            command_vector = scenario_object_type->getCommandVector();
        }
        else  // scene commands
        {
            command_vector = sceneDefinition.getCommandVector();
        }
        
        if( command_vector != NULL )
        {
            int num_command = command_vector->size();
            float command_margin = 0.3;
            float command_width = 1.5;
            float command_height = 0.4;
    
            glPushMatrix();
            
            glTranslatef(commandPosition[0], commandPosition[1], commandPosition[2]);
                
            for( int i = 0; i < num_command; i++ )
            {
                glPushMatrix();
                //glTranslatef(-4.0, 3.0-i, -5.0);
                
                //glTranslatef(-1.0, num_command*command_margin + command_margin*2 - i*command_margin, -5.0);
                //glTranslatef(0, num_command*command_margin - i*command_margin, 0);
                glTranslatef(0, (num_command-1)*(command_height+command_margin) - i*(command_height+command_margin), 0);
    
                
                glTranslatef(0, 0, -1.0);
                
                GLfloat	normal[2][3] = { 
                    {0.0, 1.0, 0.0},
                    {0.0, 0.0, 1.0}, };
                GLfloat vertex[4][3] = {
                    {-1.0, 1.0, 0.0},
                    {1.0, 1.0, 0.0},
                    {1.0, -1.0, 0.0},
                    {-1.0, -1.0, 0.0} };
                    
                glBegin(GL_QUADS);
                
                if( selection_mode )
                {
                    unsigned long color_id = i+1; // 4 bytes data
                    //unsigned long color_id = i+151; // 4 bytes data
                    GLubyte color_byte_array[4]; // broken down byte array
                    
                    // convert unsigned long to byte array
                    color_byte_array[0] = (GLubyte)((color_id) & 0xFF);
                    color_byte_array[1] = (GLubyte)((color_id >> 8) & 0xFF);
                    color_byte_array[2] = (GLubyte)((color_id >> 16) & 0xFF);
                    color_byte_array[3] = (GLubyte)((color_id >> 24) & 0xFF);
                    //glColor4ub(color_byte_array[0], color_byte_array[1], color_byte_array[2], color_byte_array[3]);
                    glColor3ub(color_byte_array[0], color_byte_array[1], color_byte_array[2]);
                }
                else
                {
                    glColor3f(0.5, 0.5, 0.5);
                }
                
                glNormal3f(0.0, 0.0, 1.0);
                glVertex3f(0.0, 0.0, 0.0);
                glVertex3f(command_width, 0.0, 0.0);
                glVertex3f(command_width, command_height, 0.0);
                glVertex3f(0.0, command_height, 0.0);
                glEnd();
                
                if( !selection_mode )
                {
                    if( i == highlight )
                    {
                        glColor3f(1.0, 0.5, 0.5);
                    }
                    else
                    {
                        glColor3f(0.0, 0.0, 0.0);
                    }
        
                    glRasterPos3f(0.1, 0.1, 0.1);
        
                    char *string = command_vector->at(i)->getName().toLocal8Bit().data();
                    int length = (int) strlen(string);
                    
                    for( unsigned int string_i = 0; string_i < length; string_i++ )
                    {
                        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, string[string_i]);
                    }
                }
                
                glPopMatrix();
            }
            
            glPopMatrix();            
        }
    }
    //else if( status == SELECT_POS )
    {

    }

    // restore color
    glColor4fv(gl_current_color);
    
    // restore flags 
    setGLBoolean(GL_LIGHTING, gl_lighting);
}


void Scene::setSimulationMode(bool simulation_mode)
{
    simulationMode = simulation_mode;
}


void Scene::setKeyboardModifiers(Qt::KeyboardModifiers keyboard_modifiers)
{
    keyboardModifiers = keyboard_modifiers;
}


void Scene::setKeyState(Qt::Key key, bool state) 
{
    keyState.insert(key, state);
}


void Scene::setButtonState(QString button, bool state) 
{
    if( buttonState.value(button) && !state)
    {
        buttonReleased.insert(button, true);
    }
    
    buttonState.insert(button, state);
    
}


void Scene::setWandPosition(float x, float y, float z)
{
    wandPosition[0] = x;
    wandPosition[1] = y;
    wandPosition[2] = z;
}


void Scene::updateScene(double delta_time)
{
    lock.lockForWrite();
    
    // travel view position and direction
    
    float move_factor = 1000.0/5;
    float rotatoin_factor = 10.0*5;
    
    if( keyState.value(Qt::Key_Left) )
    {
        if( keyboardModifiers & Qt::ControlModifier )
        {
            rotateViewDirection(0.0, rotatoin_factor*delta_time, 0.0);
        }
        else
        {
            moveViewPosition(-move_factor*delta_time, 0.0, 0.0);
        }
    }
    if( keyState.value(Qt::Key_Right) )
    {
        if( keyboardModifiers & Qt::ControlModifier )
        {
            rotateViewDirection(0.0, -rotatoin_factor*delta_time, 0.0);
        }
        else
        {
            moveViewPosition(move_factor*delta_time, 0.0, 0.0);
        }
    }
    if( keyState.value(Qt::Key_Up) )
    {
        if( keyboardModifiers & Qt::ControlModifier )
        {
            rotateViewDirection(rotatoin_factor*delta_time, 0.0, 0.0);
        }
        else if( keyboardModifiers & Qt::ShiftModifier )
        {
            moveViewPosition(0.0, move_factor*delta_time, 0.0);
        }
        else
        {
            moveViewPosition(0.0, 0.0, -move_factor*delta_time);
        }
    }
    if( keyState.value(Qt::Key_Down) )
    {
        if( keyboardModifiers & Qt::ControlModifier )
        {
            rotateViewDirection(-rotatoin_factor*delta_time, 0.0, 0.0);
        }
        else if( keyboardModifiers & Qt::ShiftModifier )
        {
            moveViewPosition(0.0, -move_factor*delta_time, 0.0);
        }
        else
        {
            moveViewPosition(0.0, 0.0, move_factor*delta_time);
        }
    }
    if( keyState.value(Qt::Key_R) )
    {
        viewPosition[0] = 0;
        viewPosition[1] = 0;
        viewPosition[2] = 0;
        viewDirection[0] = 0;
        viewDirection[1] = 0;
        viewDirection[2] = 0;  
    }
    
    if( simulationMode )
    {
        QMap<QString, ScenarioObject*>::const_iterator scenario_object_iterator = scenarioObjectList.constBegin();
        
        while( scenario_object_iterator != scenarioObjectList.constEnd() )
        {
            ScenarioObject *scenario_object = scenario_object_iterator.value();
            
            scenario_object->update(delta_time);
          
            ++scenario_object_iterator;  
        }
    }
    
    if( wandMode == SELECT_OBJECT )
    {
        updateSelectedScenarioObject();
    }
    else if( wandMode == SELECT_COMMAND )
    {
        updateCommand();
    }
    
    if( buttonReleased.value("button1") )
    {
        switch( wandMode )
        {
            case SELECT_OBJECT:
                wandMode = SELECT_COMMAND;
                updateCommandPosition();
                
                break;
            case SELECT_COMMAND:
                wandMode = SELECT_OBJECT;
                break;
        }
        
        // remove the released-button flag
        buttonReleased.insert("button1", false);
    }
    
    lock.unlock();
}


void Scene::moveViewPosition(float x, float y, float z)
{
    /*
    viewPosition[0] += x;
    viewPosition[1] += y;
    viewPosition[2] += z;
    */
    
    float radian = degree_to_radian(-viewDirection[1]);
                                   
    viewPosition[0] += qCos(radian) * x - qSin(radian) * z;
    viewPosition[1] += y;
    viewPosition[2] += qSin(radian) * x + qCos(radian) * z;
}


void Scene::rotateViewDirection(float x, float y, float z)
{
    viewDirection[0] += x;
    viewDirection[1] += y;
    viewDirection[2] += z;
}


void Scene::updatePointedScenarioObject()
{
    lock.lockForWrite();
    
    // draw on back buffer for color-based picking
    glDrawBuffer(GL_BACK);
    
    // get flags
    GLboolean gl_lighting = getGLBoolean(GL_LIGHTING);
    GLboolean gl_texture_2d = getGLBoolean(GL_TEXTURE_2D);
    GLboolean gl_dither = getGLBoolean(GL_DITHER);
    GLboolean gl_fog = getGLBoolean(GL_FOG);
    
    // get current color
    GLfloat gl_current_color[4];
    glGetFloatv(GL_CURRENT_COLOR, gl_current_color);
                
    // disable
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_DITHER);
    glDisable(GL_FOG);
    
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glClearDepth(1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();	
    
    glPushMatrix();
    
    // view transformation
    //glScalef(worldScale, worldScale, worldScale);
    glRotatef(-viewDirection[0], 1.0, 0.0, 0.0);
    glRotatef(-viewDirection[1], 0.0, 1.0, 0.0);
    glRotatef(-viewDirection[2], 0.0, 0.0, 1.0);
    glTranslatef(-viewPosition[0], -viewPosition[1], -viewPosition[2]);
    
    unsigned long color_id = 1; // 4 bytes data
    GLubyte color_byte_array[4]; // broken down byte array

    if( wandMode != SELECT_COMMAND )
    {
        QMap<QString, ScenarioObject*>::const_iterator scenario_object_iterator = scenarioObjectList.constBegin();
        
        while( scenario_object_iterator != scenarioObjectList.constEnd() )
        {
            ScenarioObject *scenario_object = scenario_object_iterator.value();
            
            // convert unsigned long to byte array
            color_byte_array[0] = (GLubyte)((color_id) & 0xFF);
            color_byte_array[1] = (GLubyte)((color_id >> 8) & 0xFF);
            color_byte_array[2] = (GLubyte)((color_id >> 16) & 0xFF);
            color_byte_array[3] = (GLubyte)((color_id >> 24) & 0xFF);
            //glColor4ub(color_byte_array[0], color_byte_array[1], color_byte_array[2], color_byte_array[3]);
            glColor3ub(color_byte_array[0], color_byte_array[1], color_byte_array[2]);
            
            scenario_object->draw(true);
            ++color_id;
        
            ++scenario_object_iterator;
        }    
    }
    
    glPopMatrix();

    if( wandMode == SELECT_COMMAND )
    {
        drawCommand(true);
    }
    
    GLint viewport[4];
    GLdouble modelview[16];
    GLdouble projection[16];
    GLdouble winX, winY, winZ;
    
    // map wand coordinates to window coordinates
    glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
    glGetDoublev(GL_PROJECTION_MATRIX, projection);
    glGetIntegerv(GL_VIEWPORT, viewport);

    gluProject(wandPosition[0], wandPosition[1], wandPosition[2], modelview, projection, viewport, &winX, &winY, &winZ);
    
    // read pixel on back buffer
    glReadBuffer(GL_BACK);
    
    //glReadPixels(winX, winY, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, color_byte_array);
    glReadPixels(winX, winY, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, color_byte_array);
    
    
    //color_id = (color_byte_array[0]) |
    //           (color_byte_array[1] << 8) |
    //           (color_byte_array[2] << 16) |
    //           (color_byte_array[3] << 24);
    
    color_id = (color_byte_array[0]) |
               (color_byte_array[1] << 8) |
               (color_byte_array[2] << 16);
    
    
    if( wandMode != SELECT_COMMAND )
    {
        ScenarioObject *preselect_scenario_object = NULL;
        
        if( color_id > 0 )
        {
            unsigned long id_counter = 1;
            
            QMap<QString, ScenarioObject*>::const_iterator scenario_object_iterator = scenarioObjectList.constBegin();
        
            while( preselect_scenario_object == NULL && scenario_object_iterator != scenarioObjectList.constEnd() )
            {
                if( color_id == id_counter )
                {
                    preselect_scenario_object = scenario_object_iterator.value();
                }
                
                ++id_counter;
                ++scenario_object_iterator;
            }
        }
        
        pointedScenarioObject = preselect_scenario_object;
    }
    else
    {
        if( color_id > 0 )
        {
            pointedCommandNum = color_id - 1;
        }
        else
        {
            pointedCommandNum = -1;
        }
    }
    
    // restore color
    glColor4fv(gl_current_color);
    
    // restore flags 
    setGLBoolean(GL_LIGHTING, gl_lighting);
    setGLBoolean(GL_TEXTURE_2D, gl_texture_2d);
    setGLBoolean(GL_DITHER, gl_dither);
    setGLBoolean(GL_FOG, gl_fog);
    
    lock.unlock();
}


GLboolean Scene::getGLBoolean(GLenum parameter)
{
    GLboolean value;
    glGetBooleanv(parameter, &value);
    
    return value;
}


void Scene::setGLBoolean(GLenum parameter, GLboolean value) 
{
    if( value )
    {
        glEnable(parameter);
    }
    else
    {
        glDisable(parameter);
    }
}


void Scene::updateSelectedScenarioObject()
{
    // if button is released
    if( buttonReleased.value("button3") )
    {
        // if it is on preselect object
        if( pointedScenarioObject != NULL )
        {
            // if preselect object is not a selected object
            if( pointedScenarioObject != selectedScenarioObject )
            {
                // set new selected object
                selectedScenarioObject = pointedScenarioObject;
                
                //cmdStatus = CMD_NONE;
                //cmdStatus = CMD_SELECT_ELEMENT;
                //fprintf(stderr, "set cmdStatus to %d\n", cmdStatus);
                
                emit sceneSelectionChanged();
            }
        }
        else
        {
            // deselect previous selected object
            if( selectedScenarioObject != NULL )
            {
                selectedScenarioObject = NULL;
            
                emit sceneSelectionChanged();
            }
        }
        
        // remove the released-button flag
        buttonReleased.insert("button3", false);
    }

    updateDisplayState();
}


void Scene::updateDisplayState()
{
    if( selectedScenarioObject != NULL )
    {
        selectedScenarioObject->setDisplayState(ScenarioObject::SELECT);
    }
    
    // set highlighted object and reset all other non-selected objects
    
    QMap<QString, ScenarioObject*>::const_iterator scenario_object_iterator = scenarioObjectList.constBegin();

    while( scenario_object_iterator != scenarioObjectList.constEnd() )
    {
        ScenarioObject *scenario_object = scenario_object_iterator.value();
        
        if( scenario_object != selectedScenarioObject )
        {
            if( scenario_object == pointedScenarioObject )
            {
                scenario_object->setDisplayState(ScenarioObject::HIGHLIGHT);
            }
            else
            {
                scenario_object->setDisplayState(ScenarioObject::APPEAR);
            }
        }

        ++scenario_object_iterator;
    }
}


ScenarioObject* Scene::getSelectedScenarioObject()
{
    return selectedScenarioObject;
}


void Scene::updateCommandPosition()
{
    commandPosition[0] = wandPosition[0];
    commandPosition[1] = wandPosition[1];
    commandPosition[2] = wandPosition[2] - 1.0; // TODO: need to calculate based on the wand direction
}


void Scene::updateCommand()
{   
    // if button is released
    if( buttonReleased.value("button3") )
    {
        selectedCommandNum = pointedCommandNum;
        
        if( selectedCommandNum >= 0 )
        {
            Command *command = NULL; 
            
            if( selectedScenarioObject != NULL )  // scenario object's type commands
            {
                ScenarioObjectType *scenario_object_type = selectedScenarioObject->getScenarioObjectType();
            
                command = scenario_object_type->getCommandVector()->at(selectedCommandNum);
            }
            else  // scene commands
            {
                command = sceneDefinition.getCommandVector()->at(selectedCommandNum);
            }
            
            if( command != NULL )
            {
                //int command_type = scenario_object_type->getCmdType(selectedCommandNum);
                Command::TYPE command_type = command->getType();
                    
                //if( command_type == 0 )
                if( command_type == Command::NO_PARAMETER )
                {
                    //QString request = "command";
                    
                    //QString command = scenario_object_type->getCmdName(selectedCommandNum);
                    QString command_name = command->getName();
                    QString command_mode = "";        
                    QString scenario_object_id = "";
                    
                    if( selectedScenarioObject != NULL )  // scenario object's type commands
                    {
                        command_mode = "scenario_object";
                        scenario_object_id = selectedScenarioObject->getScenarioObjectID();
                    }
                    else  // scene commands
                    {
                        command_mode = "scene";
                    }
                    
                    QString command_string = QString("%1:%2:%3:%4").arg(command_mode).arg(command_name).arg(scenario_object_id).arg((int)command_type);
                    
                    //emit sendRequest(request, data);
                    processCommand(command_string);
                    
                    // reset command and wand mode
                    pointedCommandNum = -1;
                    selectedCommandNum = -1;
                    wandMode = SELECT_OBJECT;
                }
                // if command type 0
                //     if on scenario object
                //         scenario_object->processCommand(command_string, parameter_list)
                //     else
                //         processCommand(command_string, parameter_list)
                // if command type 1
                //    ...
                // if command type 2
                //    ...
            }
        }
        
        // reset command and wand mode
        pointedCommandNum = -1;
        selectedCommandNum = -1;
        wandMode = SELECT_OBJECT;
        
        // remove the released-button flag
        buttonReleased.insert("button3", false);
    }
}


void Scene::processCommand(QString command_string)
{
    QStringList parameter_list = command_string.split(":");
        
    QString command_mode = parameter_list[0];
    QString command = parameter_list[1];
    
    // if command_mode is scenario_object, the command string is:
    //   scenario_object:command:scenario_object_id:command_type:additional_parameters...
    if( command_mode == "scenario_object" )
    {
        QString scenario_object_id = parameter_list[2];
        
        ScenarioObject *scenario_object = findScenarioObject(scenario_object_id);
        
        if( scenario_object != NULL )
        {
            scenario_object->processCommand(command, parameter_list.mid(3));
        }
        else
        {
            cerr<<"unit cannot be found..."<<endl;
        }
    }
    else if( command_mode == "scene" )
    {
        if( command == "Start simulation" )
        {
            simulationMode = true;
        }
        else if( command == "Stop simulation" )
        {
            simulationMode = false;
        }
    }    
}


ScenarioObject* Scene::findScenarioObject(const QString scenario_object_id)
{
    QMap<QString, ScenarioObject*>::const_iterator scenario_object_iterator = scenarioObjectList.constBegin();

    while( scenario_object_iterator != scenarioObjectList.constEnd() )
    {    
        ScenarioObject *scenario_object = scenario_object_iterator.value();
        
        scenario_object->draw();
    
        if( scenario_object->getScenarioObjectID() == scenario_object_id )
        {
            return scenario_object;
        }
        
        ++scenario_object_iterator;
    }    

    return NULL;
}


// plugin macro can only be used per plugin
// Scene is used as a base class for all plugin (it is semi-abstact class)
// thus, macro should be in each plugin subclasses, and not here
//Q_EXPORT_PLUGIN2(defaultscene, Scene);

