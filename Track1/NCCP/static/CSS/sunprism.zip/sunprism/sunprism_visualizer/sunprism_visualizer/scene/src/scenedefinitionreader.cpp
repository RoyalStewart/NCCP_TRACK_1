/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scenedefinitionreader.h"

#include <QtGui>


SceneDefinitionReader::SceneDefinitionReader(SceneDefinition *scene_definition)
{
    sceneDefinition = scene_definition;
}


bool SceneDefinitionReader::read(QIODevice *device)
{
    xml_reader.setDevice(device);

    if( xml_reader.readNextStartElement() )
    {
        if( xml_reader.name() == "scene" )
        {
            readSceneDefinition();
        
            if( scenarioObjectTypeVector.size() == 0 )
            {
                xml_reader.raiseError(QObject::tr("Scene loading failed."));
            }
            
            for( int i = 0; i < scenarioObjectTypeVector.size(); i++ )
            {
                ScenarioObjectType *scenario_object_type = scenarioObjectTypeVector[i];
        
                sceneDefinition->getScenarioObjectTypeList()->insert(scenario_object_type->getName(), scenario_object_type);
            }

            for( int i = 0; i < commandVector.size(); i++ )
            {
                sceneDefinition->getCommandVector()->push_back(commandVector[i]);
            }
            
            for( int i = 0; i < environmentFactorVector.size(); i++ )
            {
                EnvironmentFactor *environment_factor = environmentFactorVector[i];
        
                sceneDefinition->getEnvironmentFactorList()->insert(environment_factor->getName(), environment_factor);
            }
        }
        else if( xml_reader.name() == "scenario" )
        {
            readScenario();
        }
        else
        {
            xml_reader.raiseError(QObject::tr("The file is not an Scene or Scenario file."));
        }
    }

    return !xml_reader.error();
}


QString SceneDefinitionReader::errorString() const
{
    return QObject::tr("%1\nLine %2, column %3")
            .arg(xml_reader.errorString())
            .arg(xml_reader.lineNumber())
            .arg(xml_reader.columnNumber());
}


void SceneDefinitionReader::readSceneDefinition()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "scene");

    scenarioObjectTypeVector.clear();
    environmentFactorVector.clear();
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "scenario_object_type" )
        {
            readScenarioObjectType();
        }
        else if( name == "command" )
        {
            readSceneCommand();
        }
        else if( name == "env_factor" )
        {
            readEnvironmentFactor();
        }
        else
        {
            //xml_reader.skipCurrentElement();
            
            QString value = xml_reader.readElementText();
            
            sceneDefinition->getSceneInfoList()->insert(name, value);
        }
    }
}
 

void SceneDefinitionReader::readScenario()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "scenario");

    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "scene" )
        {
            QString file_name = xml_reader.readElementText();
     
            QFile scene_file(file_name);
            if( !scene_file.open(QFile::ReadOnly | QFile::Text) )
            {            
                xml_reader.raiseError(QObject::tr("Cannot read Scene file."));
            }
        
            SceneDefinitionReader scene_reader(sceneDefinition);
            if( !scene_reader.read(&scene_file) )
            {  
               xml_reader.raiseError(QObject::tr("Parse error in Scene file."));
            } 
        }
        else
        {
            xml_reader.skipCurrentElement();
        }
    }
}


void SceneDefinitionReader::readScenarioObjectType()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "scenario_object_type");
    
    ScenarioObjectType *scenario_object_type = new ScenarioObjectType();
    scenarioObjectTypeVector.push_back(scenario_object_type);

    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "name" )
        {
            QString value = xml_reader.readElementText();
            scenario_object_type->setName(value.toLocal8Bit().data());
        }
        else if( name == "property")
        {
            readProperty();
        }
        else if( name == "command")
        {
            readCommand();
        }
        else
        {
            xml_reader.skipCurrentElement();
        }
    }
}


void SceneDefinitionReader::readSceneCommand()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "command");
    
    Command *command = new Command();
    commandVector.push_back(command);
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();

        if( name == "name" )
        {
            QString value = xml_reader.readElementText();
            command->setName(value);
        }
        else if( name == "type" )
        {
            QString value = xml_reader.readElementText();
            command->setType((Command::TYPE)value.toInt());
        }
        else
        {
            xml_reader.skipCurrentElement();
        }
    }
}


void SceneDefinitionReader::readEnvironmentFactor()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "env_factor");
    
    EnvironmentFactor *environment_factor = new EnvironmentFactor();
    environmentFactorVector.push_back(environment_factor);
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "name" )
        {
            QString value = xml_reader.readElementText();
            environment_factor->setName(value.toLocal8Bit().data());
        }
        else if( name == "initial" )
        {
            QString value = xml_reader.readElementText();
            environment_factor->setInitial(value.toFloat());
        }
        else if( name == "max" )
        {
            QString value = xml_reader.readElementText();
            environment_factor->setMax(value.toFloat());
        }
        else if( name == "min" )
        {
            QString value = xml_reader.readElementText();
            environment_factor->setMin(value.toFloat());
        }
        else
        {
            xml_reader.skipCurrentElement();
        }
    }
}


void SceneDefinitionReader::readProperty()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "property");
    
    ScenarioObjectType *scenario_object_type = scenarioObjectTypeVector.back();
    scenario_object_type->addProperty();
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "name" )
        {
            QString value = xml_reader.readElementText();
            scenario_object_type->setPropName(value.toLocal8Bit().data());
        }
        else if( name == "initial" )
        {
            QString value = xml_reader.readElementText();
            scenario_object_type->setPropInit(value.toFloat());
        }
        else if( name == "max" )
        {
            QString value = xml_reader.readElementText();
            scenario_object_type->setPropMax(value.toFloat());
        }
        else if( name == "min" )
        {
            QString value = xml_reader.readElementText();
            scenario_object_type->setPropMin(value.toFloat());
        }
        else
        {
            xml_reader.skipCurrentElement();
        }
    }
}


void SceneDefinitionReader::readCommand()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "command");
    
    ScenarioObjectType *scenario_object_type = scenarioObjectTypeVector.back();
    scenario_object_type->addCmd();
               
    Command *command = new Command();
    scenario_object_type->getCommandVector()->push_back(command);
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "name" )
        {
            QString value = xml_reader.readElementText();
            scenario_object_type->setCmdName(value.toLocal8Bit().data());
            
            command->setName(value);
        }
        else if( name == "type" )
        {
            QString value = xml_reader.readElementText();
            scenario_object_type->setCmdType(value.toInt());
            
            command->setType((Command::TYPE)value.toInt());
        }
        else
        {
            xml_reader.skipCurrentElement();
        }
    }
}


QString SceneDefinitionReader::readScenarioSceneName(QIODevice *device)
{
    QXmlStreamReader xml_reader;
    
    xml_reader.setDevice(device);

    if( xml_reader.readNextStartElement() )
    {
        if( xml_reader.name() == "scenario" )
        {
            while( xml_reader.readNextStartElement() )
            {
                QString name = xml_reader.name().toString();
                
                if( name == "scene" )
                {
                    return xml_reader.readElementText();
                }
            }
        }
    }
    
    return "";
}
