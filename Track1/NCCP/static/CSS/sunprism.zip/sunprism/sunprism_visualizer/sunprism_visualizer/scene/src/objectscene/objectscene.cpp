/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "objectscene.h"
#include "object.h"


ObjectScene::ObjectScene() : Scene()
{
    sourceScenarioObject = NULL;
    travelSpeed = 0.0;
    traveledTime = 0.0;
}


QString ObjectScene::getName()
{
    return "objectscene";
}


ScenarioObject* ObjectScene::createSceneObject(QString object_type_name)
{
    ScenarioObject *scene_object;
    
    if( object_type_name == "object" )
    {
        scene_object = new Object(this);
    }
    else
    {
        scene_object = new ScenarioObject(this);
    }
    
    return scene_object;
}


void ObjectScene::updateScene(double delta_time)
{
    Scene::updateScene(delta_time);
    
    if( simulationMode )
    {
        if( sourceScenarioObject != NULL )
        {
            traveledTime += delta_time;
            
            // get total length of path. find which line, and add delta move

            int num_point = pathPointsArray.size() / 3;
            
            if( num_point > 1 )
            {
                float travel_distance = traveledTime * travelSpeed;

                float path_distance = 0.0;
                
                float point1[3];
                point1[0] = pathPointsArray.at(0);
                point1[1] = pathPointsArray.at(1);
                point1[2] = pathPointsArray.at(2);
            
                int i = 1;
                while( path_distance < travel_distance && i < num_point )
                {
                    float point2[3];
                    point2[0] = pathPointsArray.at(i * 3);
                    point2[1] = pathPointsArray.at(i * 3 + 1);
                    point2[2] = pathPointsArray.at(i * 3 + 2);
                        
                    float distance = sqrt((point2[0] - point1[0])*(point2[0] - point1[0]) +
                                          (point2[1] - point1[1])*(point2[1] - point1[1]) +
                                          (point2[2] - point1[2])*(point2[2] - point1[2]) );
                    
                    if( (path_distance + distance) >= travel_distance )
                    {
                        float interpolation = (travel_distance - path_distance) / distance;
                        
                        float new_point[3];
                        new_point[0] = point1[0] + (point2[0] - point1[0]) * interpolation;
                        new_point[1] = point1[1] + (point2[1] - point1[1]) * interpolation;
                        new_point[2] = point1[2] + (point2[2] - point1[2]) * interpolation;
                        
                        sourceScenarioObject->setTranslation(new_point[0], new_point[1], new_point[2]);
                    }
                    
                    path_distance += distance;
                    
                    point1[0] = point2[0];
                    point1[1] = point2[1];
                    point1[2] = point2[2];
                    
                    ++i;
                }
            }
        }        
    }    
}


void ObjectScene::processCommand(QString command_string)
{
    QStringList parameter_list = command_string.split(":");
        
    QString command_mode = parameter_list[0];
    QString command = parameter_list[1];
    
    // if command_mode is scenario_object, the command string is:
    //   scenario_object:command:scenario_object_id:command_type:additional_parameters...
    if( command_mode == "scenario_object" )
    {
        QString scenario_object_id = parameter_list[2];
        
        ScenarioObject *scenario_object = findScenarioObject(scenario_object_id);
        
        if( scenario_object != NULL )
        {
            scenario_object->processCommand(command, parameter_list.mid(3));
        }
        else
        {
            cerr<<"unit cannot be found..."<<endl;
        }
    }
    else if( command_mode == "scene" )
    {
        if( command == "Start simulation" )
        {
            startSimulation();
        }
        else if( command == "Stop simulation" )
        {
            stopSimulation();
        }
    }    
}

void ObjectScene::startSimulation()
{
    ScenarioObject *source_scenario_object = NULL;
    
    QMap<QString, ScenarioObject*>::const_iterator scenario_object_iterator = scenarioObjectList.constBegin();
    
    while( scenario_object_iterator != scenarioObjectList.constEnd() )
    {
        ScenarioObject *scenario_object = scenario_object_iterator.value();
        
        if( scenario_object->getFieldValueList()->value("object_id") == "source_object" )
        {
            source_scenario_object = scenario_object;
        }
        
        ++scenario_object_iterator;  
    }

    if( source_scenario_object != NULL )
    {                 
        sourceScenarioObject = source_scenario_object;
        
        pathPointsArray.clear();
            
        QString a_star_path_string = sourceScenarioObject->getFieldValueList()->value("a_star_path");
        QStringList path_point_string_list = a_star_path_string.split(",");
     
        for( int i = 0; i < path_point_string_list.size(); ++i )
        {
            QStringList point_string_list = path_point_string_list.at(i).split(":");
         
            if( point_string_list.size() == 3 )
            {
                for( int j = 0; j < 3; ++j )
                {
                    pathPointsArray.append(point_string_list.at(j).toFloat());
                }
            }
        }
        
        travelSpeed = sourceScenarioObject->getFieldValueList()->value("speed").toFloat();
        
        traveledTime = 0.0;
        
        simulationMode = true;
    }
}


void ObjectScene::stopSimulation()
{
    simulationMode = false;
}


Q_EXPORT_PLUGIN2(objectscene, ObjectScene);

