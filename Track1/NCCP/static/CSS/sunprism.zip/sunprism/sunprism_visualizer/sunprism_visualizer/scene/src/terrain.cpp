/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include <QGLWidget>

#include "terrain.h"


Terrain::Terrain()
{
    mapRow = 0;
    mapCol = NULL;
    mapElev = NULL;
    x_res = 30.0;
    z_res = 30.0;
    
    useTexture = false;
}


int Terrain::load(const char *fname)
{
    FILE *fp;
    char block[1024];
    char buf[32];
    int index;
    float elev_unit = 1.0;	//in meter

    if((fp = fopen(fname, "r")) == NULL){
        fprintf(stderr, "Error %s: File not found\n", fname);
        return 404;	//file not found
    }

    /* Get number of profiles */
    fread(block, 1, 1024, fp);

    /* Get elevation unit */
    memcpy(buf, block+535, 5);
    buf[5] = 0;
    int elev_unit_type = atoi(buf);

    /* change to meter unit */
    if(elev_unit_type == 1){
        elev_unit = 0.3048;	/* 1 ft to m */
    }else if(elev_unit_type == 2){
        elev_unit = 1.0;
    }

    /* Get x and z resolution */
    memcpy(buf, block+816, 12);
    buf[12] = 0;
    x_res = atof(buf);

    memcpy(buf, block+828, 12);
    buf[12] = 0;
    z_res = atof(buf);


    /* Get number of row */
    memcpy(buf, block+858, 6);
    buf[6] = 0;
    mapRow = atoi(buf);
    
    fprintf(stderr, "x_res = %f, z_res = %f\n", x_res, z_res);
    fprintf(stderr, "mapRow = %d\n", mapRow);

    this->mapCol = (int*) malloc(mapRow*sizeof(int));
    this->mapElev = (float**) malloc(mapRow*sizeof(float*));

    /* Type B record of DEM file */
    for(int i=0; i<mapRow; i++){

        fread(block, 1, 1024, fp);

        /* Ignor remove enter at the end of line if there is */
        if(block[0] == 10){
            fseek(fp, -1023, SEEK_CUR);
            fread(block, 1, 1024, fp);
        }

        memcpy(buf, block+12, 6);
        buf[6] = 0;
        mapCol[i] = atoi(buf);
        //		fprintf(stderr, "buf=%s, mapCol[%d]=%d\n", buf, i, mapCol[i]);
        mapElev[i] = (float*) malloc(mapCol[i]*sizeof(float));

        /* read elevation data */
        index = 144;	//block pointer
        for(int j=0; j<this->mapCol[i]; j++){

            /* read elevation data in the first block */
            if(index >= 1019){

                fread(block, 1, 1024, fp);

                /* Ignor remove enter at the end of line if there is */
                if(block[0] == 10){
                    fseek(fp, -1023, SEEK_CUR);
                    fread(block, 1, 1024, fp);
                }
                index = 0;
            }

            memcpy(buf, block+index, 6);
            buf[6] = 0;
            this->mapElev[i][j] = (float) atoi(buf) * elev_unit;

            index += 6;	//increase block pointer
        }
    }

    return 0;
}


int Terrain::loadTexture(const char *fname)
{
    x_res = 30.0;

    z_res = 30.0;

    QImage image;
    QImage textureImage;
    
    image.load(fname);
    
    printf("image.width() = %d, image.height() = %d\n", image.width(), image.height());
    
    textureImage = QGLWidget::convertToGLFormat( image );
    
    printf("textureImage.width() = %d, textureImage.height() = %d\n", textureImage.width(), textureImage.height());

    
    mapRow = textureImage.height() / z_res;

    this->mapCol = (int*) malloc(mapRow*sizeof(int));

    this->mapElev = (float**) malloc(mapRow*sizeof(float*));

    for(int i=0; i<mapRow; i++)
    {
        mapCol[i] = textureImage.width() / x_res;
        
        mapElev[i] = (float*) malloc(mapCol[i]*sizeof(float));

        for(int j=0; j<this->mapCol[i]; j++)
        {
            this->mapElev[i][j] = 0.0;
        }
    }

    useTexture = true;
    
    return 0;
}


float Terrain::elev(float xPos, float zPos)
{

    float elev = 0.0;
    float x = xPos / x_res;
    float z = zPos / z_res;
    int i = (int) floor(x);
    int j = (int) floor(z);
    float fracX = x - (float) i;
    float fracZ = z - (float) j;

    //fprintf(stderr, "xPos = %f, zPos = %f, i = %d, j = %d, mapRow = %d, mapCol[j] = %d\n", xPos, zPos, i, j, mapRow, mapCol[j]);
    
    if( (i >= 0)&&(i < mapRow-2)&&
        (j >= 0)&&(j < mapCol[j]-2) )
    {
        float elevX1 = mapElev[i+1][j] - mapElev[i][j];
        float elevX2 = mapElev[i+1][j+1] - mapElev[i][j+1];
        elev = (elevX2 - elevX1) * fracX * fracZ + mapElev[i][j];
    }
    else // fallback for out of range
    {
        if( i < 0 )
        {
            i = 0;
        }
        else if( i > (mapRow-1) )
        {
            i = mapRow-1;
        }
        
        if( j < 0 )
        {
            j = 0;
        }
        else if( j > (mapCol[j]-1) )
        {
            j = mapCol[j]-1;
        }
        
        elev = mapElev[i][j];
    }
    
    //fprintf(stderr, "mapElev[i][j] = %f\n", mapElev[i][j]);
    //fprintf(stderr, "elev = %f\n", elev);
    
    return elev;
}


float Terrain::slope(float x0, float z0, float x1, float z1)
{

    float flatDist = sqrt( sqr(x1-x0) + sqr(z1-z0) );
    float elevDist = elev(x1, z1) - elev(x0, z0);

    return elevDist / flatDist;
}


void Terrain::draw(int contextID)
{
    //fprintf(stderr, "Terrain::draw()\n");
    
    bool isLeftTurn = true; //indicate if row counter is working from left or right
    int li = 1;	//left row counter start from zero row and then increase
    int ri = mapRow - 2;	//right row counter start from max row and then decrease
    GLfloat norm[3];

    if( gl_list_num.count(contextID) <= 0 || gl_list_num[contextID] <= 0 )
    {
        fprintf(stderr, "contextID: %d\n", contextID);
        
        gl_list_num[contextID] = glGenLists(1);
        glNewList(gl_list_num[contextID], GL_COMPILE);
        
        if( useTexture )
        {
            glEnable(GL_TEXTURE_2D);
            
            //glBindTexture( GL_TEXTURE_2D, wd->texture[0] );
        }
        //else
        {
#if 0
            // DEM file issue at the edge
            int trim_edge = 50;
            
            for( int i = 1; i < mapRow-2; i++ )
            {
                glBegin(GL_TRIANGLE_STRIP);
                
                for( int j = 1; j < mapCol[i]-1-trim_edge; j++ )
                {
                    /* draw vertex 0 */
                    normalVec(i, j, norm);
                    glNormal3fv(norm);
                    glTexCoord2d(i/float(mapRow), j/float(mapCol[i]-1));
                    glVertex3f(x_res * i, mapElev[i][j], -z_res * j);
    
                    /* draw vertex 1 */
                    normalVec(i+1, j, norm);
                    glNormal3fv(norm);
                    glTexCoord2d((i+1)/float(mapRow), j/float(mapCol[i+1]-1));
                    glVertex3f(x_res * (i+1), mapElev[i+1][j], -z_res * j);
                }

                glEnd();
            } 
#endif

#if 1           
            while( li != ri )
            {	//drawing should be finished at the middle
    
                if( isLeftTurn )
                {
                    glBegin(GL_TRIANGLE_STRIP);
                    for( int j=1; j<mapCol[li]-2; j++ )
                    {
                        /* test sea level */
                        float elev = 0;
                        for(int ii=-1; ii<2; ii++)
                        {
                            for(int jj=-1; jj<2; jj++)
                            {
                                elev += mapElev[li+ii][j+jj];
                            }
                        }
                        
                        if( elev <= 0 )
                        {
                            glColor3f(0.5, 0.5, 1.0);
                        }
                        else
                        {
                            glColor3f(1.0, 1.0, 1.0);
                        }
    
                        /* draw vertex 0 */
                        normalVec(li, j, norm);
                        glNormal3fv(norm);
                        glTexCoord2d(li/float(mapRow), j/float(mapCol[li]));
                        glVertex3f(x_res * li, mapElev[li][j], -z_res * j);
    
                        /* draw vertex 1 */
                        normalVec(li+1, j, norm);
                        glNormal3fv(norm);
                        glTexCoord2d((li+1)/float(mapRow), j/float(mapCol[li+1]));
                        glVertex3f(x_res * (li+1), mapElev[li+1][j], -z_res * j);
                    }

                    glEnd();
    
                    li++;
                }
                else
                {
                    glBegin(GL_TRIANGLE_STRIP);
                    for( int j=mapCol[ri]-2; j>1; j-- )
                    {
    
                        /* test sea level */
                        float elev = 0;
                        for(int ii=-1; ii<2; ii++)
                        {
                            for(int jj=-1; jj<2; jj++)
                            {
                                elev += mapElev[ri+ii][j+jj];
                            }
                        }
                        
                        if( elev <= 0 )
                        {
                            glColor3f(0.5, 0.5, 1.0);
                        }
                        else
                        {
                            glColor3f(1.0, 1.0, 1.0);
                        }
    
                        /* draw vertex 0 */
                        normalVec(ri, j, norm);
                        glNormal3fv(norm);
                        glTexCoord2d(ri/float(mapRow), j/float(mapCol[ri]));
                        glVertex3f(x_res * (float) ri, mapElev[ri][j], -z_res * j);
    
                        /* draw vertex 1 */
                        glNormal3fv(normalVec(ri-1, j));
                        normalVec(ri-1, j, norm);
                        glNormal3fv(norm);
                        glTexCoord2d((ri-1)/float(mapRow), j/float(mapCol[ri-1]));
                        glVertex3f(x_res * (float) (ri-1), mapElev[ri-1][j], -z_res * j);
                    }
                    
                    glEnd();
    
                    ri--;
                }
    
                isLeftTurn = !isLeftTurn;
            }
#endif
        }

        if( useTexture )
        {
            glDisable(GL_TEXTURE_2D);
        }
        
        glEndList();
        
        glCallList(gl_list_num[contextID]);
    }
    else
    {
        glCallList(gl_list_num[contextID]);
    }
}


GLfloat *Terrain::normalVec(int x, int z)
{
    GLfloat norm[3];
    norm[0] = 15 * (mapElev[x-1][z] - mapElev[x+1][z]);
    norm[1] = 900;
    norm[2] = 15 * (mapElev[x][z+1] - mapElev[x][z-1]);

    float length = sqrt(norm[0]*norm[0] + norm[1]*norm[1] + norm[2]*norm[2]);
    norm[0] /= length;
    norm[1] /= length;
    norm[2] /= length;

    return norm;
}


void Terrain::normalVec(int x, int z, float norm[])
{
    norm[0] = 15 * (mapElev[x-1][z] - mapElev[x+1][z]);
    norm[1] = 900;
    norm[2] = 15 * (mapElev[x][z+1] - mapElev[x][z-1]);

    float length = sqrt(norm[0]*norm[0] + norm[1]*norm[1] + norm[2]*norm[2]);
    norm[0] /= length;
    norm[1] /= length;
    norm[2] /= length;
}


void Terrain::normalVec(int x, int z, float &ret_x, float &ret_y, float &ret_z)
{
    ret_x = 15 * (mapElev[x-1][z] - mapElev[x+1][z]);
    ret_y = 900;
    ret_z = 15 * (mapElev[x][z+1] - mapElev[x][z-1]);

    float length = sqrt(ret_x*ret_x + ret_y*ret_y + ret_z*ret_z);
    ret_x /= length;
    ret_y /= length;
    ret_z /= length;
}


float Terrain::getCenterX(void) {
    int centerX = mapRow >> 1;	//divide by 2
    return centerX * x_res;
}


float Terrain::getCenterZ(void) {
    int centerX = mapRow >> 1;	//divide by 2
    int centerZ = mapCol[centerX] >> 1;
    return centerX * x_res;
}
