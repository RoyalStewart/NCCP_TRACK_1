/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#ifndef SCENE_H
#define SCENE_H

#include <QObject>
#include <QtGui>
#include <QtOpenGL>

#include "sceneinterface.h"
#include "scenedefinition.h"
#include "scenarioobject.h"
#include "scenarioobjecttype.h"
#include "environmentfactor.h"
#include "terrain.h"


class Scene : public QObject, public SceneInterface
{
Q_OBJECT
    Q_INTERFACES(SceneInterface)
    
public:
    Scene();
    
    virtual QString getName();
    
    virtual QObject* getQObject();
    
    virtual void readSceneDefinition();
    
    bool readScene(QIODevice *device);
    
    QString errorString() const;
    
    void readScenario();
    void readScenarioObject();
    
    virtual ScenarioObject* createSceneObject(QString object_type_name);
    
    virtual void initializeScene();
    
    virtual void drawScene();
    virtual void drawCommand(bool selection_mode = false);
    
    virtual void setSimulationMode(bool simulation_mode);
    
    virtual void setKeyboardModifiers(Qt::KeyboardModifiers keyboard_modifiers);
    virtual void setKeyState(Qt::Key key, bool state);
    virtual void setButtonState(QString button, bool state);
    
    virtual void setWandPosition(float x, float y, float z);
    
    virtual void updateScene(double delta_time);
    
    virtual void moveViewPosition(float x, float y, float z);
    virtual void rotateViewDirection(float x, float y, float z);
    
    virtual void updatePointedScenarioObject();
        
    GLboolean getGLBoolean(GLenum parameter); 
    void setGLBoolean(GLenum parameter, GLboolean value); 
    
    void updateSelectedScenarioObject();
    
    void updateDisplayState();

    virtual ScenarioObject* getSelectedScenarioObject();

    void updateCommandPosition();

    void updateCommand();
    
    virtual void processCommand(QString command_string);
    
    ScenarioObject* findScenarioObject(QString name);

signals:
    void sceneSelectionChanged();
    
#if 0
public:
    QMap<QString, QString>* getScenarioInfoList();
    QMap<QString, ScenarioObjectType*>* getScenarioObjectTypeList();
    QMap<QString, EnvironmentFactor*>* getEnvironmentFactorList();
    QMap<QString, ScenarioObject*>* getScenarioObjectList();
    
    void clearScenarioInfoList();
    void clearScenarioObjectTypeList();
    void clearEnvironmentFactorList();
    void clearScenarioObjectList();
    
    ScenarioObject* findScenarioObject(QString name);
    
    void updateScenarioObjectList(QMap<QString, ScenarioObject*> *source_scenario_object_list);
    
    QString getNewScenarioObjectID();
    
    void resetGraphicsScene();
    
    QList<ScenarioObject*> selectedItems();
#endif

protected:
    SceneDefinition sceneDefinition;
    
    QMap<QString, QString> scenarioInfoList;

    QMap<QString, ScenarioObjectType*> scenarioObjectTypeList;
    QMap<QString, EnvironmentFactor*> environmentFactorList;
    
    QMap<QString, ScenarioObject*> scenarioObjectList;
    
    QXmlStreamReader xml_reader;
        
    ScenarioObject *scenarioObject;
    
    Terrain terrain;
    
    QImage textureImage;
    QMap<void*, GLuint> glTextureNumMap;
    
    float viewPosition[3];
    float viewDirection[3];
    
    Qt::KeyboardModifiers keyboardModifiers;
    QMap<Qt::Key, bool> keyState;
    QMap<QString, bool> buttonState;
    QMap<QString, bool> buttonReleased;
    
    float wandPosition[3];        
    float wandDirection[3];

    float lastWandPosition[3];        
    float lastWandDirection[3];
    
    float commandPosition[3];
    
    int pointedCommandNum;
    int selectedCommandNum;

    enum WAND_MODE {SELECT_OBJECT, SELECT_COMMAND};
    WAND_MODE wandMode;
    
    ScenarioObject *pointedScenarioObject;
    ScenarioObject *selectedScenarioObject;
    
    bool simulationMode;
    
    QReadWriteLock lock;
};

#endif // SCENE_H
