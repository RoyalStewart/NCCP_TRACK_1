/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "globescene.h"
 
#include <QtOpenGL>
#include <GL/glut.h>


QString GlobeScene::getName()
{
    return "globescene";
}


void GlobeScene::initializeScene()
{
    /* 0 = directional, 1 = location */
    GLfloat	position_0[4] = {1.0, -10.0, 10.0, -10.0},
            ambient_0[4] = {0.5, 0.5, 0.5, 1.0},
            diffuse_0[4] = {0.8, 0.8, 0.8, 1.0},
            specular_0[4] = {0.2, 0.2, 0.2, 1.0};


    GLfloat light_diffuse[] = {1.0, 1.0, 1.0, 1.0};  /* Red diffuse light. */
    GLfloat light_position[] = {1.0, 1.0, 1.0, 0.0};  /* Infinite light location. */

    /* set the polygon shading parameters */
    glShadeModel(GL_SMOOTH);

    glEnable(GL_LIGHTING);

    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient_0);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular_0);
    glEnable(GL_LIGHT0);
    //SO glDisable(GL_LIGHTING);

    //glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    //glEnable(GL_COLOR_MATERIAL);

    /* These two lines cause the vertex colors to be used (otherwise all is grey) */
    glColorMaterial(GL_FRONT, GL_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);
    
    // anti-aliasing
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

#if 0
    GLfloat mat_specular[] = {0.3, 0.3, 0.3, 1.0};
    GLfloat mat_shininess[] = { 10.0 };
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
#endif

    glEnable(GL_NORMALIZE);	/* this is required when calling glScalef() w/ lighting */

    //SO Maybe use the following: see drawing.c
    //glDepthFunc(GL_LEQUAL);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glEnable(GL_MULTISAMPLE);
    //SO glCullFace(GL_BACK);

    /* set the line parameters */
    glLineWidth(2.0);
    
    globeTerrain.load();
    
#if 1
    QString fname = "world_map_resized.png";
    QImage image;
    
    image.load(fname);
    
    
    textureImage = QGLWidget::convertToGLFormat(image);
    
    glEnable(GL_TEXTURE_2D);
    
    GLuint textureNum;
    glGenTextures(1, &textureNum);
	
    glBindTexture(GL_TEXTURE_2D, textureNum);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, textureImage.width(), textureImage.height(), 0, GL_RGBA, GL_UNSIGNED_BYTE, textureImage.bits());
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
    
    glDisable(GL_TEXTURE_2D);
    
    void* current_gl_context = (void*)QGLContext::currentContext();
    glTextureNumMap.insert(current_gl_context, textureNum);
#endif        
}


void GlobeScene::drawScene()
{
    lock.lockForRead();
    
    glEnable(GL_LIGHTING);
    //glEnable(GL_TEXTURE_2D);
    
    glClearColor(0.7, 0.7, 0.9, 0.0);
    glClearDepth(1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();	

    glPushMatrix();
    
    // view transformation
    //glScalef(worldScale, worldScale, worldScale);
    glRotatef(-viewDirection[0], 1.0, 0.0, 0.0);
    glRotatef(-viewDirection[1], 0.0, 1.0, 0.0);
    glRotatef(-viewDirection[2], 0.0, 0.0, 1.0);
    glTranslatef(-viewPosition[0], -viewPosition[1], -viewPosition[2]);
    
    //TODO: determine where the global light position based on map
    // fix light position relative to world (not view location)
    GLfloat	light_position[4] = {0.0, 7000.0, 3000.0, 1.0};
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    
    globeTerrain.draw();

    QMap<QString, ScenarioObject*>::const_iterator scenario_object_iterator = scenarioObjectList.constBegin();
    
    while( scenario_object_iterator != scenarioObjectList.constEnd() )
    {
        ScenarioObject *scenario_object = scenario_object_iterator.value();
        
        scenario_object->draw();
    
        ++scenario_object_iterator;
    }    
    
    glPopMatrix();
    
#if 0
    // draw wand    
    glPushMatrix();
    
    glTranslatef(wandPosition[0], wandPosition[1], wandPosition[2]);
    
    glRotatef(-wandDirection[0], 1.0, 0.0, 0.0);
    glRotatef(-wandDirection[1], 0.0, 1.0, 0.0);
    glRotatef(-wandDirection[2], 0.0, 0.0, 1.0);
    
    glutSolidCone(100, 100, 10, 2);
    
    glPopMatrix();
#endif


#if 1
    // draw wand line    
    glPushMatrix();
    
    glTranslatef(wandPosition[0], wandPosition[1], wandPosition[2]);
    
    glRotatef(-wandDirection[0], 1.0, 0.0, 0.0);
    glRotatef(-wandDirection[1], 0.0, 1.0, 0.0);
    glRotatef(-wandDirection[2], 0.0, 0.0, 1.0);
    
    glTranslatef(0.0, 0.0, -25.0);
    glScalef(0.03, 0.03, 50.0);
    
    glutSolidCube(1.0);
    
    glPopMatrix();
#endif


    if( wandMode == SELECT_COMMAND )
    {
        drawCommand();
    }
    
    
    lock.unlock();
}


Q_EXPORT_PLUGIN2(globescene, GlobeScene);

