/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include <QtOpenGL>
#include <GL/glut.h>

#include "externaldisplay.h"

static const double PI = 3.14159265358979323846264338327950288419717;
#ifndef degree_to_radian
#define degree_to_radian(degree) ((degree) * PI/180.0) 
#endif


ExternalDisplay::ExternalDisplay()
{
}


QString ExternalDisplay::getName()
{
    return "externaldisplay";
}


QString ExternalDisplay::getTitle()
{
    return "External Display";
}


QObject* ExternalDisplay::getQObject()
{
    return this;
}


void ExternalDisplay::openExternalDisplay(SceneInterface *scene_interface)
{
}


// plugin macro can only be used per plugin
// ExternalDisplay is used as a base class for all plugin (it is semi-abstact class)
// thus, macro should be in each plugin subclasses, and not here
//Q_EXPORT_PLUGIN2(defaultscene, ExternalDisplay);

