/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scenarioobject.h"
#include "scene.h"

#include <GL/glut.h>


int ScenarioObject::glListNum = -1;
QMap<void*, int> ScenarioObject::glListNumMap;


ScenarioObject::ScenarioObject(Scene *scene) :
    QObject(scene)
{
    this->scene = scene;
    
    scenarioObjectType = NULL;
    
    translation[0] = 0.0; 
    translation[1] = 0.0;
    translation[2] = 0.0;
    
    scale[0] = 1.0; 
    scale[1] = 1.0;
    scale[2] = 1.0;
    
    velocity[0] = 0.0; 
    velocity[1] = 0.0;
    velocity[2] = 0.0;
    
    float default_bound = 0.5;
    boundingBox[0][0] = -default_bound;
    boundingBox[0][1] = default_bound;
    boundingBox[1][0] = -default_bound;
    boundingBox[1][1] = default_bound;
    boundingBox[2][0] = -default_bound;
    boundingBox[2][1] = default_bound;
    
    displayState = APPEAR;
}


ScenarioObject::~ScenarioObject()
{
}


void ScenarioObject::setScenarioObjectID(QString scenario_object_id)
{
    this->scenarioObjectId = scenario_object_id;
}


QString ScenarioObject::getScenarioObjectID()
{
    return this->scenarioObjectId;
}


void ScenarioObject::setDisplayState(DISPLAY_STATE display_state)
{
    displayState = display_state;
}


ScenarioObject::DISPLAY_STATE ScenarioObject::getDisplayState()
{
    return displayState;
}


void ScenarioObject::copyScenarioObject(ScenarioObject *copy_scenario_object)
{        
    setScenarioObjectID(copy_scenario_object->getScenarioObjectID());
    
    setScenarioObjectType(copy_scenario_object->getScenarioObjectType());
    
    fieldValueList.clear();
    
    QMap<QString, QString> *copy_field_value_list = copy_scenario_object->getFieldValueList();
    
    QMap<QString, QString>::const_iterator copy_field_value_iterator = copy_field_value_list->constBegin();
     
    while( copy_field_value_iterator != copy_field_value_list->constEnd() )
    {
        fieldValueList.insert(copy_field_value_iterator.key(), copy_field_value_iterator.value());
        
        ++copy_field_value_iterator;
    }
}


void ScenarioObject::setScenarioObjectType(ScenarioObjectType* scenario_object_type)
{
    scenarioObjectType = scenario_object_type;
}


ScenarioObjectType* ScenarioObject::getScenarioObjectType()
{
    return scenarioObjectType;
}


QMap<QString, QString>* ScenarioObject::getFieldValueList()
{ 
    return &fieldValueList;
}


void ScenarioObject::setTranslation(float x_translation, float y_translation, float z_translation)
{
    translation[0] = x_translation; 
    translation[1] = y_translation;
    translation[2] = z_translation;
}


float ScenarioObject::getXTranslation()
{
    return translation[0];
}


float ScenarioObject::getYTranslation()
{
    return translation[1];
}


float ScenarioObject::getZTranslation()
{
    return translation[2];
}


void ScenarioObject::setScale(float x_scale, float y_scale, float z_scale)
{
    scale[0] = x_scale; 
    scale[1] = y_scale;
    scale[2] = z_scale;
}


void ScenarioObject::setVelocity(float x_velocity, float y_velocity, float z_velocity)
{
    velocity[0] = x_velocity; 
    velocity[1] = y_velocity;
    velocity[2] = z_velocity;
}


void ScenarioObject::update(double delta_time)
{
    translation[0] += velocity[0]*delta_time; 
    translation[1] += velocity[1]*delta_time; 
    translation[2] += velocity[2]*delta_time; 
}


void ScenarioObject::draw(bool picking)
{
    if( displayState == NONE )
    {
        return;
    }
    
    glPushMatrix();
    
    glTranslatef(translation[0], translation[1], translation[2]);
    
    glScalef(scale[0], scale[1], scale[2]);
    
    //glColor3f(0.0, 0.0, 1.0);
    

    drawSceneObject();
    
    if( !picking )
    {
        if( displayState == HIGHLIGHT ||  displayState == SELECT )
        {
            // get current light position
            GLfloat light_position[4];
            glGetLightfv(GL_LIGHT0, GL_POSITION, light_position);
            
            // fixed light position at eye
            glPushMatrix();
            glLoadIdentity();
            gluLookAt(0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0);
            GLfloat light_position_origin[4] = {0.0, 0.0, 0.0, 1.0};
            glLightfv(GL_LIGHT0, GL_POSITION, light_position_origin);
            glPopMatrix();

            glPushMatrix();
            
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            
            // get current color
            GLfloat color[4];
            glGetFloatv(GL_CURRENT_COLOR, color);
        
            // set highlight or selection color
            if( displayState == HIGHLIGHT )
            {
                glColor4f(1.0, 1.0, 0.0, 0.5);
            }
            else
            {
                glColor4f(0.0, 1.0, 0.0, 0.5);
            }
            
            float bounding_size[3];
            bounding_size[0] = boundingBox[0][1] - boundingBox[0][0];
            bounding_size[1] = boundingBox[1][1] - boundingBox[1][0];
            bounding_size[2] = boundingBox[2][1] - boundingBox[2][0];
            
            // center bounding box
            glTranslatef( boundingBox[0][0] + bounding_size[0]/2, 
                          boundingBox[1][0] + bounding_size[1]/2,
                          boundingBox[2][0] + bounding_size[2]/2 );
            
            glScalef(bounding_size[0] + 1.0/scale[0], bounding_size[1] + 1.0/scale[1], bounding_size[2] + 1.0/scale[2]);
            
            drawSolidCube();

            // restore color
            glColor4fv(color);
                
            glDisable(GL_BLEND);
            
            glPopMatrix();
                
            // restore light position
            // glGetLightfv returned in eye coordinate, so load identity matrix
            glPushMatrix();
            glLoadIdentity();
            glLightfv(GL_LIGHT0, GL_POSITION, light_position);
            glPopMatrix();
        }
    }
    
    glPopMatrix();
}


void ScenarioObject::drawSceneObject()
{
    // draw cube for default
    drawSolidCube();
}


void ScenarioObject::drawSolidCube()
{
    void* current_gl_context = (void*)QGLContext::currentContext();
    
    if( glListNumMap.value(current_gl_context) <= 0 )
    {
        glListNumMap.insert(current_gl_context, glGenLists(1));
        glNewList(glListNumMap.value(current_gl_context), GL_COMPILE);
        
        GLfloat n[6][3] = {  /* Normals for the 6 faces of a cube. */
            {0.0, 0.0, 1.0}, 
            {0.0, 0.0, -1.0}, 
            {-1.0, 0.0, 0.0},
            {1.0, 0.0, 0.0}, 
            {0.0, 1.0, 0.0}, 
            {0.0, -1.0, 0.0} };
        GLint faces[6][4] = {  /* Vertex indices for the 6 faces of a cube. */
            {0, 1, 2, 3}, 
            {7, 6, 5, 4}, 
            {4, 5, 1, 0},
            {3, 2, 6, 7}, 
            {4, 0, 3, 7}, 
            {1, 5, 6, 2} };
        GLfloat v[8][3];  /* Will be filled in with X,Y,Z vertexes. */
        
        GLfloat vertex[8][3] = {
            {-0.5, 0.5, 0.5},
            {-0.5, -0.5, 0.5},
            {0.5, -0.5, 0.5},
            {0.5, 0.5, 0.5},
            
            {-0.5, 0.5, -0.5},
            {-0.5, -0.5, -0.5},
            {0.5, -0.5, -0.5},
            {0.5, 0.5, -0.5} };
            
        for( int i = 0; i < 6; i++ )
        {
            glBegin(GL_QUADS);
            glNormal3fv(&n[i][0]);
            glVertex3fv(&vertex[faces[i][0]][0]);
            glVertex3fv(&vertex[faces[i][1]][0]);
            glVertex3fv(&vertex[faces[i][2]][0]);
            glVertex3fv(&vertex[faces[i][3]][0]);
            glEnd();
        }
        
        glEndList();
        
        glCallList(glListNumMap.value(current_gl_context));
    }
    else
    {
        glCallList(glListNumMap.value(current_gl_context));
    }
}


// this is for per object initialization for bounding box
void ScenarioObject::initialize3dsModel(char *model_filename)
{
    lib3dsFile = lib3ds_file_load(model_filename);
    if( !lib3dsFile )
    {
        printf("Error: Loading %s failed.\n", model_filename);
        exit(1);
    }

    lib3ds_file_eval(lib3dsFile, 0.0);
    
    // TODO: this should be in init 3ds model (and not in render) function
    Lib3dsVector bounding_min, bounding_max;
    lib3ds_file_bounding_box_of_nodes(lib3dsFile, LIB3DS_TRUE, LIB3DS_FALSE, LIB3DS_FALSE, bounding_min, bounding_max);
    float default_bound_factor = 1.0;
    // apply the default rotations (on x-axis, then z-axis)
    boundingBox[0][0] = -bounding_max[0]*default_bound_factor;
    boundingBox[0][1] = -bounding_min[0]*default_bound_factor;
    boundingBox[1][0] = bounding_min[2]*default_bound_factor;
    boundingBox[1][1] = bounding_max[2]*default_bound_factor;
    boundingBox[2][0] = bounding_min[1]*default_bound_factor;
    boundingBox[2][1] = bounding_max[1]*default_bound_factor;
}
    

// make sure this is called inside glNewList(glListNum, GL_COMPILE)
void ScenarioObject::render3dsModel(char *model_filename)
{
    lib3dsFile = lib3ds_file_load(model_filename);
    if( !lib3dsFile )
    {
        printf("Error: Loading %s failed.\n", model_filename);
        exit(1);
    }

    lib3ds_file_eval(lib3dsFile, 0.0);
    
    // default model transformation
    glPushMatrix();
    
    
    glRotatef(-90, 1.0, 0.0, 0.0);
    glRotatef(180.0, 0.0, 0.0, 1.0);
    
    Lib3dsNode *p;
    for( p = lib3dsFile->nodes; p != 0; p = p->next )
    {
        renderNode(p);
    }

    glPopMatrix();
}


void ScenarioObject::renderNode(Lib3dsNode *node) {

    ASSERT(file);

    Lib3dsNode *p;
    for( p = node->childs; p != 0; p = p->next )
    {
        renderNode(p);
    }

    if( node->type == LIB3DS_OBJECT_NODE )
    {
        Lib3dsMesh *mesh;

        if( strcmp(node->name,"$$$DUMMY") == 0 )
        {
            return;
        }

        mesh = lib3ds_file_mesh_by_name(lib3dsFile, node->data.object.morph);
        if( mesh == NULL )
        {
            mesh = lib3ds_file_mesh_by_name(lib3dsFile, node->name);
        }

        ASSERT(mesh);
        if( !mesh )
        {
            return;
        }

        unsigned p;
        Lib3dsVector *normalL = new Lib3dsVector[3*mesh->faces];
        lib3ds_mesh_calculate_normals(mesh, normalL);

        for( p = 0; p < mesh->faces; ++p )
        {
            Lib3dsFace *f=&mesh->faceL[p];

            glBegin(GL_TRIANGLES);
            glNormal3fv(f->normal);
            for( int i = 0; i < 3; ++i )
            {
                glNormal3fv(normalL[3*p+i]);
                glVertex3fv(mesh->pointL[f->points[i]].pos);
            }
            
            glEnd();
        }

        delete [] normalL;
    }
}


void ScenarioObject::processCommand(QString command, QStringList parameter_list)
{
    cerr<<"Unit::command()"<<endl;
    cerr<<"command: "<<qPrintable(command)<<endl;
    
    if( command == "forward" )
    {
        setVelocity(0.0, 0.0, -10.0);
    }
}

