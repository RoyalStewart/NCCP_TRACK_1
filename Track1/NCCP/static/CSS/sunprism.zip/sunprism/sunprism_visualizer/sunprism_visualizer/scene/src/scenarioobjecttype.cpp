/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include <QtOpenGL>

#include "scenarioobjecttype.h"


ScenarioObjectType::ScenarioObjectType()
{
    strcpy(name, "unnamed");
    propName.clear();
    propInit.clear();
    propMax.clear();
    propMin.clear();
    cmdName.clear();
    cmdType.clear();
    //model = NULL;
    
    glListNum = -1;
}


void ScenarioObjectType::setName(const char *name)
{
    strcpy(this->name, name);
}


void ScenarioObjectType::addProperty(void)
{
    char * strPtr = new char[32];
    strPtr[0] = 0;
    propName.push_back(strPtr);
    propInit.push_back(0.0);
    propMax.push_back(0.0);
    propMin.push_back(0.0);
}


void ScenarioObjectType::setPropName(const char *name)
{
    assert(!propName.empty());
    strcpy(propName.back(), name);
}


void ScenarioObjectType::setPropInit(float initVal)
{
    assert(!propInit.empty());
    propInit.back() = initVal;
}


void ScenarioObjectType::setPropMax(float maxVal)
{
    assert(!propMax.empty());
    propMax.back() = maxVal;
}


void ScenarioObjectType::setPropMin(float minVal)
{
    assert(!propMin.empty());
    propMin.back() = minVal;
}


char* ScenarioObjectType::getName(void)
{
    return name;
}


int ScenarioObjectType::getPropSize(void)
{
    return propName.size();
}


char* ScenarioObjectType::getPropName(unsigned int index)
{
    if( index >= propName.size() )
    {
        return NULL;
    }
    else
    {
        return propName[index];
    }
}


float ScenarioObjectType::getPropInit(unsigned int index)
{
    if( index >= propInit.size() )
    {
        return NULL;
    }
    else
    {
        return propInit[index];
    }
}


float ScenarioObjectType::getPropMax(unsigned int index)
{
    if( index >= propMax.size() )
    {
        return NULL;
    }
    else
    {
        return propMax[index];
    }
}


float ScenarioObjectType::getPropMin(unsigned int index)
{
    if( index >= propMin.size() )
    {
        return NULL;
    }
    else
    {
        return propMin[index];
    }
}


void ScenarioObjectType::addCmd(void)
{
    char *strPtr = new char[32];
    cmdName.push_back(strPtr);
    cmdType.push_back(0);
}


void ScenarioObjectType::setCmdName(const char *name)
{
    assert(!cmdName.empty());
    char *commandName = new char[64];
    strcpy(commandName, name);
    cmdName.back() = commandName;
}


void ScenarioObjectType::setCmdType(int type)
{
    assert(!cmdType.empty());
    cmdType.back() = type;
}


int ScenarioObjectType::getCmdSize(void) 
{
    return cmdName.size();
}


char* ScenarioObjectType::getCmdName(unsigned int index) 
{
    assert(index < cmdName.size());
    return cmdName[index];
}


int ScenarioObjectType::getCmdType(unsigned int index) 
{
    assert(index < cmdType.size());
    return cmdType[index];
}


void ScenarioObjectType::draw()
{
    if( glListNum < 0 )
    {
        glListNum = glGenLists(1);
        glNewList(glListNum, GL_COMPILE);

        GLfloat n[6][3] = {  /* Normals for the 6 faces of a cube. */
            {0.0, 0.0, 1.0}, 
            {0.0, 0.0, -1.0}, 
            {-1.0, 0.0, 0.0},
            {1.0, 0.0, 0.0}, 
            {0.0, 1.0, 0.0}, 
            {0.0, -1.0, 0.0} };
        GLint faces[6][4] = {  /* Vertex indices for the 6 faces of a cube. */
            {0, 1, 2, 3}, 
            {7, 6, 5, 4}, 
            {4, 5, 1, 0},
            {3, 2, 6, 7}, 
            {4, 0, 3, 7}, 
            {1, 5, 6, 2} };
        GLfloat v[8][3];  /* Will be filled in with X,Y,Z vertexes. */
        
        GLfloat vertex[8][3] = {
            {-0.5, 0.5, 0.5},
            {-0.5, -0.5, 0.5},
            {0.5, -0.5, 0.5},
            {0.5, 0.5, 0.5},
            
            {-0.5, 0.5, -0.5},
            {-0.5, -0.5, -0.5},
            {0.5, -0.5, -0.5},
            {0.5, 0.5, -0.5} };
            
        for( int i = 0; i < 6; i++ )
        {
            glBegin(GL_QUADS);
            glNormal3fv(&n[i][0]);
            glVertex3fv(&vertex[faces[i][0]][0]);
            glVertex3fv(&vertex[faces[i][1]][0]);
            glVertex3fv(&vertex[faces[i][2]][0]);
            glVertex3fv(&vertex[faces[i][3]][0]);
            glEnd();
        }
        
        glEndList();
        
        glCallList(glListNum);
    }
    else
    {
        glCallList(glListNum);
    }
}


QVector<Command*>* ScenarioObjectType::getCommandVector()
{ 
    return &commandVector;
}


void ScenarioObjectType::clearCommandVector()
{
    commandVector.clear();
}

