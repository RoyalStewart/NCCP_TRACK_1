/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include <QtGui>
//#include <QtOpenGL>

#include "glwidget.h"


GlWidget::GlWidget(QWidget *parent) :
    QGLWidget(parent), glWidgetRenderer(this), glWidgetUpdater(this)
{
    setFocusPolicy(Qt::StrongFocus);
    
    setMouseTracking(true);
    
    scene = NULL;
    
    setAutoBufferSwap(false);
	
    resize(600, 600);
}


void GlWidget::setScene(SceneInterface *scene)
{
    this->scene = scene;
}


void GlWidget::initializeScene()
{
    if( scene != NULL )
    {
        scene->initializeScene();
    }
}


void GlWidget::resizeScene(int width, int height)
{
    int side = qMax(width, height);
    glViewport((width - side) / 2, (height - side) / 2, side, side);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
    side = 1.0;
    glFrustum(-side, side, -side, side, 1.0, 100000.0); // TODO: far-value should be determined based on map size
    
    glMatrixMode(GL_MODELVIEW);
    
    lock.lockForWrite();
    
    glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
    glGetDoublev(GL_PROJECTION_MATRIX, projection);
    glGetIntegerv(GL_VIEWPORT, viewport);
    
    lock.unlock();
}


void GlWidget::drawScene()
{
    if( scene != NULL )
    {
        scene->drawScene();
    }
    else
    {
        glClearColor(1.0, 1.0, 1.0, 0.0);
        glClearDepth(1.0);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
}


void GlWidget::updateScene(double delta_time)
{
    if( scene != NULL )
    {
        scene->updateScene(delta_time);
    }
}


void GlWidget::startRendering()
{
	glWidgetRenderer.start();
}
	

void GlWidget::stopRendering()
{
	glWidgetRenderer.stop();
	glWidgetRenderer.wait();
}


void GlWidget::startUpdating()
{
	glWidgetUpdater.start();
}
	

void GlWidget::stopUpdating()
{
	glWidgetUpdater.stop();
	glWidgetUpdater.wait();
}


void GlWidget::resizeEvent(QResizeEvent *event)
{
	glWidgetRenderer.resizeViewport(event->size());
	glWidgetUpdater.resizeViewport(event->size());
}


void GlWidget::paintEvent(QPaintEvent *event)
{
	// Handled by the GLThread.
}


void GlWidget::closeEvent(QCloseEvent *event)
{
	stopRendering();
	stopUpdating();
	QGLWidget::closeEvent(event);
	deleteLater();
}


void GlWidget::keyPressEvent(QKeyEvent *event)
{   
    if( scene != NULL )
    {
        switch( event->key() )
        {
            case Qt::Key_Up:
            case Qt::Key_Down:
            case Qt::Key_Left:
            case Qt::Key_Right:
            case Qt::Key_R:
                scene->setKeyboardModifiers(event->modifiers());
                
                scene->setKeyState((Qt::Key)event->key(), true);
                
                break;
                
            default:
                QGLWidget::keyPressEvent(event);
                break;
        }
    }
}


void GlWidget::keyReleaseEvent(QKeyEvent *event)
{   
    if( scene != NULL )
    {
        switch( event->key() )
        {
            case Qt::Key_Up:
            case Qt::Key_Down:
            case Qt::Key_Left:
            case Qt::Key_Right:
            case Qt::Key_R:
                scene->setKeyboardModifiers(event->modifiers());
                
                scene->setKeyState((Qt::Key)event->key(), false);
                
                break;
                
            default:
                QGLWidget::keyPressEvent(event);
                break;
        }
    }
}


void GlWidget::mousePressEvent(QMouseEvent *event)
{
    if( scene != NULL )
    {
        lastPos = event->pos();
     
        if( event->button() == Qt::LeftButton )
        {
            scene->setButtonState("button3", true);
        }
        if( event->button() == Qt::RightButton )
        {
            scene->setButtonState("button1", true);
        }
    }
}


void GlWidget::mouseReleaseEvent(QMouseEvent *event)
{
    if( scene != NULL )
    {
        if( event->button() == Qt::LeftButton )
        {
            scene->setButtonState("button3", false);
        }
        if( event->button() == Qt::RightButton )
        {
            scene->setButtonState("button1", false);
        }
    }
}

        
void GlWidget::mouseMoveEvent(QMouseEvent *event)
{
    if( scene != NULL )
    {
        int x = event->pos().x();
        int y = event->pos().y();
        
        glWidgetUpdater.updateWandPosition(x, y);
    }
    
#if 0
    int dx = event->x() - lastPos.x();
    int dy = event->y() - lastPos.y();

    if( event->buttons() & Qt::LeftButton )
    {
        int x_angle = viewRotation[0] + 8 * dy;
        int y_angle = viewRotation[1] + 8 * dx;
        int z_angle = viewRotation[2];
        
        setRotation(x_angle, y_angle, z_angle);
    }
    else if( event->buttons() & Qt::RightButton )
    {
        int x_angle = viewRotation[0] + 8 * dy;
        int y_angle = viewRotation[1];
        int z_angle = viewRotation[2] + 8 * dx;
        
        setRotation(x_angle, y_angle, z_angle);
    }
    
    lastPos = event->pos();
#endif
}


void GlWidget::updateWandPosition(int x, int y)
{
    lock.lockForRead();
    
    GLfloat window_x, window_y, window_z;
    GLdouble world_x, world_y, world_z;
 
    window_x = (float)x;
    window_y = (float)viewport[3] - (float)y;
    glReadPixels(x, int(window_y), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &window_z);
 
    gluUnProject(window_x, window_y, 0, modelview, projection, viewport, &world_x, &world_y, &world_z);
   
    lock.unlock();
    
    scene->setWandPosition(world_x, world_y, world_z);
    
    scene->updatePointedScenarioObject();
}
        

void GlWidget::wheelEvent(QWheelEvent *event)
{    
    //QGraphicsScene::wheelEvent(event);
    //if (event->isAccepted())
    //    return;
#if 0
    // wheel scroll forward gives positive delta
    // and backward gives negative delta
    float delta_scale = 1.0 + event->delta() / 120 / 10.0; 
    
    scale(delta_scale, delta_scale, delta_scale);
    
    event->accept();
    
    updateGL();
#endif
}


void GlWidget::lockMutex()
{
    mutex.lock();
}


void GlWidget::unlockMutex()
{
    mutex.unlock();
}

