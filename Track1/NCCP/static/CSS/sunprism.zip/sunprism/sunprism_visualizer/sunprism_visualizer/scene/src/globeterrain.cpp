/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "globeterrain.h"

#include <QDataStream>
#include <QtOpenGL>

#define GLOBE_MAX_ROW 6000
#define GLOBE_COLUMN 10800


GlobeTerrain::GlobeTerrain()
{
    elevationData = new qint16[GLOBE_MAX_ROW*GLOBE_COLUMN];
}


GlobeTerrain::~GlobeTerrain()
{
    delete [] elevationData;
}


int GlobeTerrain::load()
{
    QFile file("../../data/globe/elevation_map/g10g");
    if( file.open(QIODevice::ReadOnly) )
    {
        QDataStream data_stream( &file );
        data_stream.setByteOrder( QDataStream::LittleEndian ); 
        
        int row = 0;
        int col = 0;
        
        while( !data_stream.atEnd() )
        {
            data_stream >> elevationData[(row*GLOBE_COLUMN)+col];
            
            if( elevationData[(row*GLOBE_COLUMN)+col] == -500 )
            {
                elevationData[(row*GLOBE_COLUMN)+col] = 0;
            }
            
            
            ++col;
            
            if( col == GLOBE_COLUMN )
            {
                ++row;
                col = 0;
            }
        }
        
        elevationNumRow = row - 1;
        elevationNumCol = GLOBE_COLUMN;
    }
}


void GlobeTerrain::draw()
{
    static QMap<void*, int> glListNumMap;
    
    void* current_gl_context = (void*)QGLContext::currentContext();
    
    if( glListNumMap.value(current_gl_context) <= 0 )
    {
        glListNumMap.insert(current_gl_context, glGenLists(1));
        glNewList(glListNumMap.value(current_gl_context), GL_COMPILE);
    
        int startW = 0;
        int startL = 0;
        int xOffset = 0;
        int yOffset = 0;
        int zOffset = 0;
        GLfloat normal[3];

        int skip = 1;
        for( int i = 1 ; i < elevationNumRow-1; i=i+skip )
        {
            glBegin(GL_TRIANGLE_STRIP);
            
            for( int j = 1; j < elevationNumCol-1; j=j+skip )
            {
                normalAt(i+skip, j, normal);
                glNormal3fv(normal);
                
                glVertex3f(
                    (j),
                    elevationData[(i+skip)*elevationNumCol + (j)]/1000.0,
                    -(i+skip));	
                
                normalAt(i, j, normal);
                glNormal3fv(normal);
                
                glVertex3f(
                    (j),
                    elevationData[(i)*elevationNumCol + (j)]/1000.0,
                    -(i));	
            }
            glEnd();
        }

        glEndList();
        
        glCallList(glListNumMap.value(current_gl_context));
    }
    else
    {
        glCallList(glListNumMap.value(current_gl_context));
    }
}


void GlobeTerrain::normalAt(int x, int z, float normal[])
{
    normal[0] = 15 * (elevationData[(x-1)*elevationNumCol + (z)] - elevationData[(x+1)*elevationNumCol + (z)]);
    normal[1] = 900;
    normal[2] = 15 * (elevationData[(x)*elevationNumCol + (z+1)] - elevationData[(x)*elevationNumCol + (z-1)]);

    float length = sqrt(normal[0]*normal[0] + normal[1]*normal[1] + normal[2]*normal[2]);
    normal[0] /= length;
    normal[1] /= length;
    normal[2] /= length;
}

