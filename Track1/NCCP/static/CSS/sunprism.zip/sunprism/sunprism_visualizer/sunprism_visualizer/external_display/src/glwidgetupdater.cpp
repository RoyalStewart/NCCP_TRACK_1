/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "glwidgetupdater.h"
#include <QTime>

#include <QtGui>
#include <QtOpenGL>
#include <QColor>

#include "glwidget.h"


GlWidgetUpdater::GlWidgetUpdater(GlWidget *gl_widget) 
	: QThread(), glWidget(gl_widget)
{
	loopUpdate = true;
	doResizeViewport = false;
	doUpdateWandPosition = false;
}


void GlWidgetUpdater::stop()
{
	loopUpdate = false;
}


void GlWidgetUpdater::resizeViewport(const QSize &size)
{
    mutex.lock();
    
	width = size.width();
	height = size.height();
	doResizeViewport = true;
	
	mutex.unlock();
}    


void GlWidgetUpdater::updateWandPosition(int screen_x, int screen_y)
{
    mutex.lock();
    
	screenX = screen_x;
	screenY = screen_y;
	doUpdateWandPosition = true;
	
	mutex.unlock();
}    


void GlWidgetUpdater::run()
{
	glWidget->makeCurrent();
	
	glWidget->initializeScene();

    // millisecond to sleep between each updateing
    int sleep_ms = 1 / 30 * 1000; // 30 frames per second
    
    QTime last_update_time = QTime::currentTime();
	
    while( loopUpdate )
	{
		if( doResizeViewport ) 
		{
			mutex.lock();

			glWidget->resizeScene(width, height);
            
			doResizeViewport = false;
            
            mutex.unlock();
		}
				
		if( doUpdateWandPosition ) 
		{
			mutex.lock();

            glWidget->lockMutex();
            glWidget->makeCurrent();
		
			glWidget->updateWandPosition(screenX, screenY);
                  
            doUpdateWandPosition = false;
            
            glWidget->doneCurrent();
            glWidget->unlockMutex();
		
            mutex.unlock();
		}
		
        QTime current_time = QTime::currentTime();
        double delta_time = last_update_time.msecsTo(current_time)/1000.0;
        
        last_update_time = current_time;
    
		glWidget->lockMutex();
		glWidget->makeCurrent();
		
        glWidget->updateScene(delta_time);
		
        //glWidget->swapBuffers();  

		glWidget->doneCurrent();
		glWidget->unlockMutex();
	
		msleep(sleep_ms);
	}
		
	glWidget->doneCurrent();
}

