/********************************************************************************
** Form generated from reading UI file 'sunprismvisualizermainwindow.ui'
**
** Created: Tue Oct 23 18:53:33 2012
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUNPRISMVISUALIZERMAINWINDOW_H
#define UI_SUNPRISMVISUALIZERMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QSplitter>
#include <QtGui/QStatusBar>
#include <QtGui/QTableWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QToolBar>
#include <QtGui/QTreeWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "glwidget.h"

QT_BEGIN_NAMESPACE

class Ui_SunprismVisualizerMainWindow
{
public:
    QAction *toolbarActionOpen;
    QAction *menuActionClose;
    QAction *toolbarActionSave;
    QAction *toolbarActionSaveAs;
    QAction *menuActionExit;
    QAction *menuActionCut;
    QAction *menuActionCopy;
    QAction *menuActionPaste;
    QAction *menuActionFind;
    QAction *toolbarActionZoomIn;
    QAction *toolbarActionZoomOut;
    QAction *toolbarActionFullScreen;
    QAction *menuActionAbout;
    QAction *menuActionSetConnection;
    QAction *menuActionZoomIn;
    QAction *menuActionZoomOut;
    QAction *menuActionFullScreen;
    QAction *menuActionOpen;
    QAction *menuActionSave;
    QAction *menuActionSaveAs;
    QAction *toolbarActionRecord;
    QAction *toolbarActionPlay;
    QAction *menuActionLoadPlayback;
    QAction *menuActionSavePlayback;
    QAction *toolbarActionSpeedUp;
    QAction *toolbarActionSpeedDown;
    QAction *menuActionNormalSpeed;
    QAction *menuActionAddUnit;
    QAction *menuActionEditUnit;
    QAction *menuActionDeleteUnit;
    QAction *menuActionFindUnit;
    QAction *menuActionRecordPause;
    QAction *toolbarActionStop;
    QAction *menuActionRecordStop;
    QAction *menuActionSpeedUp;
    QAction *menuActionSpeedDown;
    QAction *menuActionEditFactor;
    QAction *menuActionSetDefault;
    QAction *menuActionNew;
    QAction *menuActionUndo;
    QAction *menuActionRedo;
    QAction *menuActionSelectAll;
    QAction *menuActionSpeech;
    QAction *menuActionToolbar;
    QAction *menuActionOperationTips;
    QAction *menuActionInstallationInstructions;
    QAction *menuActionSetupMode;
    QAction *menuActionRunMode;
    QAction *menuActionExecutionRun;
    QAction *menuActionExecutionPause;
    QAction *menuActionExecutionStop;
    QAction *menuActionWarning;
    QAction *menuActionRecordStart;
    QAction *menuActionPlayStart;
    QAction *menuActionPlayPause;
    QAction *menuActionPlayStop;
    QAction *menuActionSetSamplingFrequency;
    QAction *menuActionGrid;
    QAction *menuActionStatusBar;
    QAction *menuActionRun;
    QAction *menuActionStop;
    QAction *menuActionPause;
    QAction *toolbarActionNew;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout_2;
    QSplitter *splitter_2;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *modelFilterEdit;
    QTreeWidget *scenarioObjectTree;
    QSplitter *splitter;
    QFrame *sceneViewFrame;
    QHBoxLayout *horizontalLayout_3;
    GlWidget *scenarioView;
    QTextEdit *outputText;
    QTableWidget *propertyTable;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuEdit;
    QMenu *menuCommunication;
    QMenu *menuTools;
    QMenu *menuPlayback;
    QMenu *menuRecord;
    QMenu *menuPlay;
    QMenu *menuSettings;
    QMenu *menuHelp;
    QMenu *menuIntervention;
    QMenu *menuScenario;
    QMenu *menuEnvironment;
    QMenu *menuMode;
    QMenu *menuExecution;
    QMenu *menuView;
    QMenu *menuExternalDisplay;
    QToolBar *mainToolbar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *SunprismVisualizerMainWindow)
    {
        if (SunprismVisualizerMainWindow->objectName().isEmpty())
            SunprismVisualizerMainWindow->setObjectName(QString::fromUtf8("SunprismVisualizerMainWindow"));
        SunprismVisualizerMainWindow->resize(816, 710);
        QIcon icon;
        icon.addFile(QString::fromUtf8("image/sunprism.png"), QSize(), QIcon::Normal, QIcon::Off);
        SunprismVisualizerMainWindow->setWindowIcon(icon);
        toolbarActionOpen = new QAction(SunprismVisualizerMainWindow);
        toolbarActionOpen->setObjectName(QString::fromUtf8("toolbarActionOpen"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("image/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionOpen->setIcon(icon1);
        menuActionClose = new QAction(SunprismVisualizerMainWindow);
        menuActionClose->setObjectName(QString::fromUtf8("menuActionClose"));
        toolbarActionSave = new QAction(SunprismVisualizerMainWindow);
        toolbarActionSave->setObjectName(QString::fromUtf8("toolbarActionSave"));
        toolbarActionSave->setEnabled(true);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("image/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionSave->setIcon(icon2);
        toolbarActionSaveAs = new QAction(SunprismVisualizerMainWindow);
        toolbarActionSaveAs->setObjectName(QString::fromUtf8("toolbarActionSaveAs"));
        toolbarActionSaveAs->setEnabled(true);
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("image/saveAs.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionSaveAs->setIcon(icon3);
        menuActionExit = new QAction(SunprismVisualizerMainWindow);
        menuActionExit->setObjectName(QString::fromUtf8("menuActionExit"));
        menuActionCut = new QAction(SunprismVisualizerMainWindow);
        menuActionCut->setObjectName(QString::fromUtf8("menuActionCut"));
        menuActionCopy = new QAction(SunprismVisualizerMainWindow);
        menuActionCopy->setObjectName(QString::fromUtf8("menuActionCopy"));
        menuActionPaste = new QAction(SunprismVisualizerMainWindow);
        menuActionPaste->setObjectName(QString::fromUtf8("menuActionPaste"));
        menuActionFind = new QAction(SunprismVisualizerMainWindow);
        menuActionFind->setObjectName(QString::fromUtf8("menuActionFind"));
        toolbarActionZoomIn = new QAction(SunprismVisualizerMainWindow);
        toolbarActionZoomIn->setObjectName(QString::fromUtf8("toolbarActionZoomIn"));
        toolbarActionZoomIn->setEnabled(true);
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("image/zoomIn.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionZoomIn->setIcon(icon4);
        toolbarActionZoomOut = new QAction(SunprismVisualizerMainWindow);
        toolbarActionZoomOut->setObjectName(QString::fromUtf8("toolbarActionZoomOut"));
        toolbarActionZoomOut->setEnabled(true);
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("image/zoomOut.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionZoomOut->setIcon(icon5);
        toolbarActionFullScreen = new QAction(SunprismVisualizerMainWindow);
        toolbarActionFullScreen->setObjectName(QString::fromUtf8("toolbarActionFullScreen"));
        toolbarActionFullScreen->setEnabled(true);
        QIcon icon6;
        icon6.addFile(QString::fromUtf8("image/fullScreen.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionFullScreen->setIcon(icon6);
        menuActionAbout = new QAction(SunprismVisualizerMainWindow);
        menuActionAbout->setObjectName(QString::fromUtf8("menuActionAbout"));
        menuActionSetConnection = new QAction(SunprismVisualizerMainWindow);
        menuActionSetConnection->setObjectName(QString::fromUtf8("menuActionSetConnection"));
        menuActionZoomIn = new QAction(SunprismVisualizerMainWindow);
        menuActionZoomIn->setObjectName(QString::fromUtf8("menuActionZoomIn"));
        menuActionZoomOut = new QAction(SunprismVisualizerMainWindow);
        menuActionZoomOut->setObjectName(QString::fromUtf8("menuActionZoomOut"));
        menuActionFullScreen = new QAction(SunprismVisualizerMainWindow);
        menuActionFullScreen->setObjectName(QString::fromUtf8("menuActionFullScreen"));
        menuActionFullScreen->setCheckable(true);
        menuActionOpen = new QAction(SunprismVisualizerMainWindow);
        menuActionOpen->setObjectName(QString::fromUtf8("menuActionOpen"));
        menuActionSave = new QAction(SunprismVisualizerMainWindow);
        menuActionSave->setObjectName(QString::fromUtf8("menuActionSave"));
        menuActionSaveAs = new QAction(SunprismVisualizerMainWindow);
        menuActionSaveAs->setObjectName(QString::fromUtf8("menuActionSaveAs"));
        toolbarActionRecord = new QAction(SunprismVisualizerMainWindow);
        toolbarActionRecord->setObjectName(QString::fromUtf8("toolbarActionRecord"));
        toolbarActionRecord->setEnabled(true);
        QIcon icon7;
        icon7.addFile(QString::fromUtf8("image/record.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionRecord->setIcon(icon7);
        toolbarActionPlay = new QAction(SunprismVisualizerMainWindow);
        toolbarActionPlay->setObjectName(QString::fromUtf8("toolbarActionPlay"));
        toolbarActionPlay->setEnabled(true);
        QIcon icon8;
        icon8.addFile(QString::fromUtf8("image/play.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionPlay->setIcon(icon8);
        menuActionLoadPlayback = new QAction(SunprismVisualizerMainWindow);
        menuActionLoadPlayback->setObjectName(QString::fromUtf8("menuActionLoadPlayback"));
        menuActionSavePlayback = new QAction(SunprismVisualizerMainWindow);
        menuActionSavePlayback->setObjectName(QString::fromUtf8("menuActionSavePlayback"));
        toolbarActionSpeedUp = new QAction(SunprismVisualizerMainWindow);
        toolbarActionSpeedUp->setObjectName(QString::fromUtf8("toolbarActionSpeedUp"));
        toolbarActionSpeedUp->setEnabled(true);
        QIcon icon9;
        icon9.addFile(QString::fromUtf8("image/speedUp.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionSpeedUp->setIcon(icon9);
        toolbarActionSpeedDown = new QAction(SunprismVisualizerMainWindow);
        toolbarActionSpeedDown->setObjectName(QString::fromUtf8("toolbarActionSpeedDown"));
        toolbarActionSpeedDown->setEnabled(true);
        QIcon icon10;
        icon10.addFile(QString::fromUtf8("image/speedDown.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionSpeedDown->setIcon(icon10);
        menuActionNormalSpeed = new QAction(SunprismVisualizerMainWindow);
        menuActionNormalSpeed->setObjectName(QString::fromUtf8("menuActionNormalSpeed"));
        menuActionAddUnit = new QAction(SunprismVisualizerMainWindow);
        menuActionAddUnit->setObjectName(QString::fromUtf8("menuActionAddUnit"));
        menuActionEditUnit = new QAction(SunprismVisualizerMainWindow);
        menuActionEditUnit->setObjectName(QString::fromUtf8("menuActionEditUnit"));
        menuActionDeleteUnit = new QAction(SunprismVisualizerMainWindow);
        menuActionDeleteUnit->setObjectName(QString::fromUtf8("menuActionDeleteUnit"));
        menuActionFindUnit = new QAction(SunprismVisualizerMainWindow);
        menuActionFindUnit->setObjectName(QString::fromUtf8("menuActionFindUnit"));
        menuActionRecordPause = new QAction(SunprismVisualizerMainWindow);
        menuActionRecordPause->setObjectName(QString::fromUtf8("menuActionRecordPause"));
        toolbarActionStop = new QAction(SunprismVisualizerMainWindow);
        toolbarActionStop->setObjectName(QString::fromUtf8("toolbarActionStop"));
        toolbarActionStop->setEnabled(true);
        QIcon icon11;
        icon11.addFile(QString::fromUtf8("image/stop.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionStop->setIcon(icon11);
        menuActionRecordStop = new QAction(SunprismVisualizerMainWindow);
        menuActionRecordStop->setObjectName(QString::fromUtf8("menuActionRecordStop"));
        menuActionSpeedUp = new QAction(SunprismVisualizerMainWindow);
        menuActionSpeedUp->setObjectName(QString::fromUtf8("menuActionSpeedUp"));
        menuActionSpeedDown = new QAction(SunprismVisualizerMainWindow);
        menuActionSpeedDown->setObjectName(QString::fromUtf8("menuActionSpeedDown"));
        menuActionEditFactor = new QAction(SunprismVisualizerMainWindow);
        menuActionEditFactor->setObjectName(QString::fromUtf8("menuActionEditFactor"));
        menuActionSetDefault = new QAction(SunprismVisualizerMainWindow);
        menuActionSetDefault->setObjectName(QString::fromUtf8("menuActionSetDefault"));
        menuActionNew = new QAction(SunprismVisualizerMainWindow);
        menuActionNew->setObjectName(QString::fromUtf8("menuActionNew"));
        menuActionUndo = new QAction(SunprismVisualizerMainWindow);
        menuActionUndo->setObjectName(QString::fromUtf8("menuActionUndo"));
        menuActionRedo = new QAction(SunprismVisualizerMainWindow);
        menuActionRedo->setObjectName(QString::fromUtf8("menuActionRedo"));
        menuActionSelectAll = new QAction(SunprismVisualizerMainWindow);
        menuActionSelectAll->setObjectName(QString::fromUtf8("menuActionSelectAll"));
        menuActionSpeech = new QAction(SunprismVisualizerMainWindow);
        menuActionSpeech->setObjectName(QString::fromUtf8("menuActionSpeech"));
        menuActionToolbar = new QAction(SunprismVisualizerMainWindow);
        menuActionToolbar->setObjectName(QString::fromUtf8("menuActionToolbar"));
        menuActionToolbar->setCheckable(true);
        menuActionToolbar->setChecked(true);
        menuActionOperationTips = new QAction(SunprismVisualizerMainWindow);
        menuActionOperationTips->setObjectName(QString::fromUtf8("menuActionOperationTips"));
        menuActionInstallationInstructions = new QAction(SunprismVisualizerMainWindow);
        menuActionInstallationInstructions->setObjectName(QString::fromUtf8("menuActionInstallationInstructions"));
        menuActionSetupMode = new QAction(SunprismVisualizerMainWindow);
        menuActionSetupMode->setObjectName(QString::fromUtf8("menuActionSetupMode"));
        menuActionSetupMode->setCheckable(true);
        menuActionSetupMode->setChecked(true);
        menuActionRunMode = new QAction(SunprismVisualizerMainWindow);
        menuActionRunMode->setObjectName(QString::fromUtf8("menuActionRunMode"));
        menuActionRunMode->setCheckable(true);
        menuActionExecutionRun = new QAction(SunprismVisualizerMainWindow);
        menuActionExecutionRun->setObjectName(QString::fromUtf8("menuActionExecutionRun"));
        menuActionExecutionPause = new QAction(SunprismVisualizerMainWindow);
        menuActionExecutionPause->setObjectName(QString::fromUtf8("menuActionExecutionPause"));
        menuActionExecutionStop = new QAction(SunprismVisualizerMainWindow);
        menuActionExecutionStop->setObjectName(QString::fromUtf8("menuActionExecutionStop"));
        menuActionWarning = new QAction(SunprismVisualizerMainWindow);
        menuActionWarning->setObjectName(QString::fromUtf8("menuActionWarning"));
        menuActionWarning->setCheckable(true);
        menuActionWarning->setChecked(true);
        menuActionRecordStart = new QAction(SunprismVisualizerMainWindow);
        menuActionRecordStart->setObjectName(QString::fromUtf8("menuActionRecordStart"));
        menuActionPlayStart = new QAction(SunprismVisualizerMainWindow);
        menuActionPlayStart->setObjectName(QString::fromUtf8("menuActionPlayStart"));
        menuActionPlayPause = new QAction(SunprismVisualizerMainWindow);
        menuActionPlayPause->setObjectName(QString::fromUtf8("menuActionPlayPause"));
        menuActionPlayStop = new QAction(SunprismVisualizerMainWindow);
        menuActionPlayStop->setObjectName(QString::fromUtf8("menuActionPlayStop"));
        menuActionSetSamplingFrequency = new QAction(SunprismVisualizerMainWindow);
        menuActionSetSamplingFrequency->setObjectName(QString::fromUtf8("menuActionSetSamplingFrequency"));
        menuActionGrid = new QAction(SunprismVisualizerMainWindow);
        menuActionGrid->setObjectName(QString::fromUtf8("menuActionGrid"));
        menuActionGrid->setCheckable(true);
        menuActionGrid->setChecked(true);
        menuActionStatusBar = new QAction(SunprismVisualizerMainWindow);
        menuActionStatusBar->setObjectName(QString::fromUtf8("menuActionStatusBar"));
        menuActionStatusBar->setCheckable(true);
        menuActionStatusBar->setChecked(true);
        menuActionRun = new QAction(SunprismVisualizerMainWindow);
        menuActionRun->setObjectName(QString::fromUtf8("menuActionRun"));
        menuActionStop = new QAction(SunprismVisualizerMainWindow);
        menuActionStop->setObjectName(QString::fromUtf8("menuActionStop"));
        menuActionPause = new QAction(SunprismVisualizerMainWindow);
        menuActionPause->setObjectName(QString::fromUtf8("menuActionPause"));
        toolbarActionNew = new QAction(SunprismVisualizerMainWindow);
        toolbarActionNew->setObjectName(QString::fromUtf8("toolbarActionNew"));
        toolbarActionNew->setEnabled(true);
        QIcon icon12;
        icon12.addFile(QString::fromUtf8("image/document-new-6.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionNew->setIcon(icon12);
        centralWidget = new QWidget(SunprismVisualizerMainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout_2 = new QHBoxLayout(centralWidget);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        splitter_2 = new QSplitter(centralWidget);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        widget = new QWidget(splitter_2);
        widget->setObjectName(QString::fromUtf8("widget"));
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy);
        widget->setMinimumSize(QSize(150, 0));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(-1);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy1);
        widget_2->setMinimumSize(QSize(150, 0));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy2);

        horizontalLayout->addWidget(label);

        modelFilterEdit = new QLineEdit(widget_2);
        modelFilterEdit->setObjectName(QString::fromUtf8("modelFilterEdit"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Minimum);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(modelFilterEdit->sizePolicy().hasHeightForWidth());
        modelFilterEdit->setSizePolicy(sizePolicy3);
        modelFilterEdit->setMinimumSize(QSize(50, 0));

        horizontalLayout->addWidget(modelFilterEdit);


        verticalLayout->addWidget(widget_2);

        scenarioObjectTree = new QTreeWidget(widget);
        scenarioObjectTree->setObjectName(QString::fromUtf8("scenarioObjectTree"));
        scenarioObjectTree->setMinimumSize(QSize(150, 100));
        scenarioObjectTree->setLineWidth(1);
        scenarioObjectTree->setDragEnabled(true);
        scenarioObjectTree->setIconSize(QSize(32, 32));
        scenarioObjectTree->setRootIsDecorated(false);
        scenarioObjectTree->setUniformRowHeights(false);
        scenarioObjectTree->setAnimated(false);

        verticalLayout->addWidget(scenarioObjectTree);

        splitter_2->addWidget(widget);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy4.setHorizontalStretch(1);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(splitter->sizePolicy().hasHeightForWidth());
        splitter->setSizePolicy(sizePolicy4);
        splitter->setOrientation(Qt::Vertical);
        sceneViewFrame = new QFrame(splitter);
        sceneViewFrame->setObjectName(QString::fromUtf8("sceneViewFrame"));
        QSizePolicy sizePolicy5(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(sceneViewFrame->sizePolicy().hasHeightForWidth());
        sceneViewFrame->setSizePolicy(sizePolicy5);
        sceneViewFrame->setMinimumSize(QSize(300, 400));
        sceneViewFrame->setAutoFillBackground(true);
        sceneViewFrame->setFrameShape(QFrame::StyledPanel);
        sceneViewFrame->setFrameShadow(QFrame::Sunken);
        horizontalLayout_3 = new QHBoxLayout(sceneViewFrame);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(2, 2, 2, 2);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        scenarioView = new GlWidget(sceneViewFrame);
        scenarioView->setObjectName(QString::fromUtf8("scenarioView"));
        QSizePolicy sizePolicy6(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(scenarioView->sizePolicy().hasHeightForWidth());
        scenarioView->setSizePolicy(sizePolicy6);
        scenarioView->setAutoFillBackground(false);

        horizontalLayout_3->addWidget(scenarioView);

        splitter->addWidget(sceneViewFrame);
        outputText = new QTextEdit(splitter);
        outputText->setObjectName(QString::fromUtf8("outputText"));
        sizePolicy5.setHeightForWidth(outputText->sizePolicy().hasHeightForWidth());
        outputText->setSizePolicy(sizePolicy5);
        outputText->setMinimumSize(QSize(0, 50));
        splitter->addWidget(outputText);
        splitter_2->addWidget(splitter);
        propertyTable = new QTableWidget(splitter_2);
        if (propertyTable->columnCount() < 2)
            propertyTable->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        propertyTable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        propertyTable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        propertyTable->setObjectName(QString::fromUtf8("propertyTable"));
        sizePolicy5.setHeightForWidth(propertyTable->sizePolicy().hasHeightForWidth());
        propertyTable->setSizePolicy(sizePolicy5);
        propertyTable->setMinimumSize(QSize(250, 200));
        propertyTable->setAutoFillBackground(false);
        propertyTable->setFrameShape(QFrame::StyledPanel);
        propertyTable->setFrameShadow(QFrame::Sunken);
        propertyTable->setLineWidth(1);
        propertyTable->setAutoScrollMargin(14);
        propertyTable->setAlternatingRowColors(false);
        propertyTable->setShowGrid(true);
        propertyTable->setGridStyle(Qt::SolidLine);
        propertyTable->setCornerButtonEnabled(true);
        propertyTable->setRowCount(0);
        propertyTable->setColumnCount(2);
        splitter_2->addWidget(propertyTable);
        propertyTable->horizontalHeader()->setVisible(false);
        propertyTable->horizontalHeader()->setCascadingSectionResizes(false);
        propertyTable->horizontalHeader()->setHighlightSections(false);
        propertyTable->horizontalHeader()->setMinimumSectionSize(30);
        propertyTable->horizontalHeader()->setStretchLastSection(true);
        propertyTable->verticalHeader()->setVisible(false);
        propertyTable->verticalHeader()->setCascadingSectionResizes(false);
        propertyTable->verticalHeader()->setDefaultSectionSize(23);
        propertyTable->verticalHeader()->setMinimumSectionSize(19);
        propertyTable->verticalHeader()->setProperty("showSortIndicator", QVariant(false));
        propertyTable->verticalHeader()->setStretchLastSection(false);

        horizontalLayout_2->addWidget(splitter_2);

        SunprismVisualizerMainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(SunprismVisualizerMainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 816, 21));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuEdit = new QMenu(menuBar);
        menuEdit->setObjectName(QString::fromUtf8("menuEdit"));
        menuCommunication = new QMenu(menuBar);
        menuCommunication->setObjectName(QString::fromUtf8("menuCommunication"));
        menuTools = new QMenu(menuBar);
        menuTools->setObjectName(QString::fromUtf8("menuTools"));
        menuPlayback = new QMenu(menuBar);
        menuPlayback->setObjectName(QString::fromUtf8("menuPlayback"));
        menuRecord = new QMenu(menuPlayback);
        menuRecord->setObjectName(QString::fromUtf8("menuRecord"));
        menuPlay = new QMenu(menuPlayback);
        menuPlay->setObjectName(QString::fromUtf8("menuPlay"));
        menuSettings = new QMenu(menuPlayback);
        menuSettings->setObjectName(QString::fromUtf8("menuSettings"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        menuIntervention = new QMenu(menuBar);
        menuIntervention->setObjectName(QString::fromUtf8("menuIntervention"));
        menuScenario = new QMenu(menuIntervention);
        menuScenario->setObjectName(QString::fromUtf8("menuScenario"));
        menuEnvironment = new QMenu(menuIntervention);
        menuEnvironment->setObjectName(QString::fromUtf8("menuEnvironment"));
        menuMode = new QMenu(menuIntervention);
        menuMode->setObjectName(QString::fromUtf8("menuMode"));
        menuExecution = new QMenu(menuIntervention);
        menuExecution->setObjectName(QString::fromUtf8("menuExecution"));
        menuView = new QMenu(menuBar);
        menuView->setObjectName(QString::fromUtf8("menuView"));
        menuExternalDisplay = new QMenu(menuView);
        menuExternalDisplay->setObjectName(QString::fromUtf8("menuExternalDisplay"));
        SunprismVisualizerMainWindow->setMenuBar(menuBar);
        mainToolbar = new QToolBar(SunprismVisualizerMainWindow);
        mainToolbar->setObjectName(QString::fromUtf8("mainToolbar"));
        mainToolbar->setIconSize(QSize(35, 35));
        SunprismVisualizerMainWindow->addToolBar(Qt::TopToolBarArea, mainToolbar);
        statusBar = new QStatusBar(SunprismVisualizerMainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        SunprismVisualizerMainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuEdit->menuAction());
        menuBar->addAction(menuView->menuAction());
        menuBar->addAction(menuCommunication->menuAction());
        menuBar->addAction(menuIntervention->menuAction());
        menuBar->addAction(menuTools->menuAction());
        menuBar->addAction(menuPlayback->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuFile->addAction(menuActionNew);
        menuFile->addAction(menuActionOpen);
        menuFile->addAction(menuActionSave);
        menuFile->addAction(menuActionSaveAs);
        menuFile->addSeparator();
        menuFile->addAction(menuActionClose);
        menuFile->addSeparator();
        menuFile->addAction(menuActionExit);
        menuEdit->addAction(menuActionUndo);
        menuEdit->addAction(menuActionRedo);
        menuEdit->addSeparator();
        menuEdit->addAction(menuActionCut);
        menuEdit->addAction(menuActionCopy);
        menuEdit->addAction(menuActionPaste);
        menuEdit->addSeparator();
        menuEdit->addAction(menuActionSelectAll);
        menuEdit->addSeparator();
        menuEdit->addAction(menuActionFind);
        menuEdit->addSeparator();
        menuEdit->addAction(menuActionSpeech);
        menuCommunication->addAction(menuActionSetConnection);
        menuTools->addSeparator();
        menuTools->addAction(menuActionWarning);
        menuTools->addSeparator();
        menuPlayback->addAction(menuActionLoadPlayback);
        menuPlayback->addAction(menuActionSavePlayback);
        menuPlayback->addSeparator();
        menuPlayback->addAction(menuRecord->menuAction());
        menuPlayback->addSeparator();
        menuPlayback->addAction(menuPlay->menuAction());
        menuPlayback->addSeparator();
        menuPlayback->addAction(menuSettings->menuAction());
        menuRecord->addAction(menuActionRecordStart);
        menuRecord->addAction(menuActionRecordPause);
        menuRecord->addAction(menuActionRecordStop);
        menuPlay->addAction(menuActionPlayStart);
        menuPlay->addAction(menuActionPlayPause);
        menuPlay->addAction(menuActionPlayStop);
        menuSettings->addAction(menuActionSetSamplingFrequency);
        menuSettings->addSeparator();
        menuSettings->addAction(menuActionSpeedUp);
        menuSettings->addAction(menuActionSpeedDown);
        menuSettings->addAction(menuActionNormalSpeed);
        menuHelp->addAction(menuActionAbout);
        menuHelp->addAction(menuActionOperationTips);
        menuHelp->addAction(menuActionInstallationInstructions);
        menuIntervention->addAction(menuMode->menuAction());
        menuIntervention->addAction(menuScenario->menuAction());
        menuIntervention->addAction(menuEnvironment->menuAction());
        menuIntervention->addAction(menuExecution->menuAction());
        menuScenario->addAction(menuActionAddUnit);
        menuScenario->addAction(menuActionEditUnit);
        menuScenario->addAction(menuActionDeleteUnit);
        menuScenario->addSeparator();
        menuScenario->addAction(menuActionFindUnit);
        menuEnvironment->addAction(menuActionEditFactor);
        menuEnvironment->addSeparator();
        menuEnvironment->addAction(menuActionSetDefault);
        menuMode->addAction(menuActionSetupMode);
        menuMode->addAction(menuActionRunMode);
        menuExecution->addAction(menuActionExecutionRun);
        menuExecution->addAction(menuActionExecutionPause);
        menuExecution->addAction(menuActionExecutionStop);
        menuView->addAction(menuActionZoomIn);
        menuView->addAction(menuActionZoomOut);
        menuView->addSeparator();
        menuView->addAction(menuActionFullScreen);
        menuView->addSeparator();
        menuView->addAction(menuActionToolbar);
        menuView->addAction(menuActionGrid);
        menuView->addAction(menuActionStatusBar);
        menuView->addSeparator();
        menuView->addAction(menuExternalDisplay->menuAction());
        mainToolbar->addAction(toolbarActionNew);
        mainToolbar->addAction(toolbarActionOpen);
        mainToolbar->addAction(toolbarActionSave);
        mainToolbar->addAction(toolbarActionSaveAs);
        mainToolbar->addSeparator();
        mainToolbar->addAction(toolbarActionFullScreen);
        mainToolbar->addAction(toolbarActionZoomIn);
        mainToolbar->addAction(toolbarActionZoomOut);
        mainToolbar->addSeparator();
        mainToolbar->addAction(toolbarActionRecord);
        mainToolbar->addAction(toolbarActionStop);
        mainToolbar->addAction(toolbarActionSpeedDown);
        mainToolbar->addAction(toolbarActionPlay);
        mainToolbar->addAction(toolbarActionSpeedUp);

        retranslateUi(SunprismVisualizerMainWindow);

        QMetaObject::connectSlotsByName(SunprismVisualizerMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *SunprismVisualizerMainWindow)
    {
        SunprismVisualizerMainWindow->setWindowTitle(QApplication::translate("SunprismVisualizerMainWindow", "SUNPRISM Visualizer", 0, QApplication::UnicodeUTF8));
        toolbarActionOpen->setText(QApplication::translate("SunprismVisualizerMainWindow", "Open", 0, QApplication::UnicodeUTF8));
        menuActionClose->setText(QApplication::translate("SunprismVisualizerMainWindow", "Close", 0, QApplication::UnicodeUTF8));
        menuActionClose->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+W", 0, QApplication::UnicodeUTF8));
        toolbarActionSave->setText(QApplication::translate("SunprismVisualizerMainWindow", "Save", 0, QApplication::UnicodeUTF8));
        toolbarActionSaveAs->setText(QApplication::translate("SunprismVisualizerMainWindow", "Save as...", 0, QApplication::UnicodeUTF8));
        menuActionExit->setText(QApplication::translate("SunprismVisualizerMainWindow", "Exit", 0, QApplication::UnicodeUTF8));
        menuActionExit->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+Q", 0, QApplication::UnicodeUTF8));
        menuActionCut->setText(QApplication::translate("SunprismVisualizerMainWindow", "Cut", 0, QApplication::UnicodeUTF8));
        menuActionCut->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+X", 0, QApplication::UnicodeUTF8));
        menuActionCopy->setText(QApplication::translate("SunprismVisualizerMainWindow", "Copy", 0, QApplication::UnicodeUTF8));
        menuActionCopy->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+C", 0, QApplication::UnicodeUTF8));
        menuActionPaste->setText(QApplication::translate("SunprismVisualizerMainWindow", "Paste", 0, QApplication::UnicodeUTF8));
        menuActionPaste->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+V", 0, QApplication::UnicodeUTF8));
        menuActionFind->setText(QApplication::translate("SunprismVisualizerMainWindow", "Find", 0, QApplication::UnicodeUTF8));
        menuActionFind->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+F", 0, QApplication::UnicodeUTF8));
        toolbarActionZoomIn->setText(QApplication::translate("SunprismVisualizerMainWindow", "Zoom In", 0, QApplication::UnicodeUTF8));
        toolbarActionZoomOut->setText(QApplication::translate("SunprismVisualizerMainWindow", "Zoom Out", 0, QApplication::UnicodeUTF8));
        toolbarActionFullScreen->setText(QApplication::translate("SunprismVisualizerMainWindow", "Full Screen", 0, QApplication::UnicodeUTF8));
        menuActionAbout->setText(QApplication::translate("SunprismVisualizerMainWindow", "About", 0, QApplication::UnicodeUTF8));
        menuActionSetConnection->setText(QApplication::translate("SunprismVisualizerMainWindow", "Set Connection", 0, QApplication::UnicodeUTF8));
        menuActionZoomIn->setText(QApplication::translate("SunprismVisualizerMainWindow", "Zoom In", 0, QApplication::UnicodeUTF8));
        menuActionZoomIn->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl++", 0, QApplication::UnicodeUTF8));
        menuActionZoomOut->setText(QApplication::translate("SunprismVisualizerMainWindow", "Zoom Out", 0, QApplication::UnicodeUTF8));
        menuActionZoomOut->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+-", 0, QApplication::UnicodeUTF8));
        menuActionFullScreen->setText(QApplication::translate("SunprismVisualizerMainWindow", "Full Screen", 0, QApplication::UnicodeUTF8));
        menuActionFullScreen->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "F11", 0, QApplication::UnicodeUTF8));
        menuActionOpen->setText(QApplication::translate("SunprismVisualizerMainWindow", "Open", 0, QApplication::UnicodeUTF8));
        menuActionOpen->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+O", 0, QApplication::UnicodeUTF8));
        menuActionSave->setText(QApplication::translate("SunprismVisualizerMainWindow", "Save", 0, QApplication::UnicodeUTF8));
        menuActionSave->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+S", 0, QApplication::UnicodeUTF8));
        menuActionSaveAs->setText(QApplication::translate("SunprismVisualizerMainWindow", "Save As...", 0, QApplication::UnicodeUTF8));
        menuActionSaveAs->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+Shift+S", 0, QApplication::UnicodeUTF8));
        toolbarActionRecord->setText(QApplication::translate("SunprismVisualizerMainWindow", "Record", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        toolbarActionRecord->setToolTip(QApplication::translate("SunprismVisualizerMainWindow", "Record", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        toolbarActionPlay->setText(QApplication::translate("SunprismVisualizerMainWindow", "Play", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        toolbarActionPlay->setToolTip(QApplication::translate("SunprismVisualizerMainWindow", "Play", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        menuActionLoadPlayback->setText(QApplication::translate("SunprismVisualizerMainWindow", "Load Playback", 0, QApplication::UnicodeUTF8));
        menuActionSavePlayback->setText(QApplication::translate("SunprismVisualizerMainWindow", "Save Playback", 0, QApplication::UnicodeUTF8));
        toolbarActionSpeedUp->setText(QApplication::translate("SunprismVisualizerMainWindow", "Speed Up", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        toolbarActionSpeedUp->setToolTip(QApplication::translate("SunprismVisualizerMainWindow", "Speed Up", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        toolbarActionSpeedDown->setText(QApplication::translate("SunprismVisualizerMainWindow", "Speed Down", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        toolbarActionSpeedDown->setToolTip(QApplication::translate("SunprismVisualizerMainWindow", "Speed Down", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        menuActionNormalSpeed->setText(QApplication::translate("SunprismVisualizerMainWindow", "Normal Speed", 0, QApplication::UnicodeUTF8));
        menuActionAddUnit->setText(QApplication::translate("SunprismVisualizerMainWindow", "Add Scene Object", 0, QApplication::UnicodeUTF8));
        menuActionAddUnit->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ins", 0, QApplication::UnicodeUTF8));
        menuActionEditUnit->setText(QApplication::translate("SunprismVisualizerMainWindow", "Edit Scene Object", 0, QApplication::UnicodeUTF8));
        menuActionDeleteUnit->setText(QApplication::translate("SunprismVisualizerMainWindow", "Delete Scene Object", 0, QApplication::UnicodeUTF8));
        menuActionDeleteUnit->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Del", 0, QApplication::UnicodeUTF8));
        menuActionFindUnit->setText(QApplication::translate("SunprismVisualizerMainWindow", "Find Unit", 0, QApplication::UnicodeUTF8));
        menuActionFindUnit->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+F", 0, QApplication::UnicodeUTF8));
        menuActionRecordPause->setText(QApplication::translate("SunprismVisualizerMainWindow", "Pause", 0, QApplication::UnicodeUTF8));
        toolbarActionStop->setText(QApplication::translate("SunprismVisualizerMainWindow", "Stop", 0, QApplication::UnicodeUTF8));
        menuActionRecordStop->setText(QApplication::translate("SunprismVisualizerMainWindow", "Stop", 0, QApplication::UnicodeUTF8));
        menuActionSpeedUp->setText(QApplication::translate("SunprismVisualizerMainWindow", "Playback Speed Up", 0, QApplication::UnicodeUTF8));
        menuActionSpeedDown->setText(QApplication::translate("SunprismVisualizerMainWindow", "Playback Speed Down", 0, QApplication::UnicodeUTF8));
        menuActionEditFactor->setText(QApplication::translate("SunprismVisualizerMainWindow", "Edit Factor", 0, QApplication::UnicodeUTF8));
        menuActionSetDefault->setText(QApplication::translate("SunprismVisualizerMainWindow", "Set Default", 0, QApplication::UnicodeUTF8));
        menuActionNew->setText(QApplication::translate("SunprismVisualizerMainWindow", "New", 0, QApplication::UnicodeUTF8));
        menuActionNew->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+N", 0, QApplication::UnicodeUTF8));
        menuActionUndo->setText(QApplication::translate("SunprismVisualizerMainWindow", "Undo", 0, QApplication::UnicodeUTF8));
        menuActionUndo->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+Z", 0, QApplication::UnicodeUTF8));
        menuActionRedo->setText(QApplication::translate("SunprismVisualizerMainWindow", "Redo", 0, QApplication::UnicodeUTF8));
        menuActionRedo->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+Y", 0, QApplication::UnicodeUTF8));
        menuActionSelectAll->setText(QApplication::translate("SunprismVisualizerMainWindow", "Select All", 0, QApplication::UnicodeUTF8));
        menuActionSelectAll->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+A", 0, QApplication::UnicodeUTF8));
        menuActionSpeech->setText(QApplication::translate("SunprismVisualizerMainWindow", "Speech", 0, QApplication::UnicodeUTF8));
        menuActionToolbar->setText(QApplication::translate("SunprismVisualizerMainWindow", "Toolbar", 0, QApplication::UnicodeUTF8));
        menuActionToolbar->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+Alt+T", 0, QApplication::UnicodeUTF8));
        menuActionOperationTips->setText(QApplication::translate("SunprismVisualizerMainWindow", "Operation Tips", 0, QApplication::UnicodeUTF8));
        menuActionInstallationInstructions->setText(QApplication::translate("SunprismVisualizerMainWindow", "Installation Instructions", 0, QApplication::UnicodeUTF8));
        menuActionSetupMode->setText(QApplication::translate("SunprismVisualizerMainWindow", "Setup Mode", 0, QApplication::UnicodeUTF8));
        menuActionRunMode->setText(QApplication::translate("SunprismVisualizerMainWindow", "Run Mode", 0, QApplication::UnicodeUTF8));
        menuActionExecutionRun->setText(QApplication::translate("SunprismVisualizerMainWindow", "Run", 0, QApplication::UnicodeUTF8));
        menuActionExecutionRun->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+R", 0, QApplication::UnicodeUTF8));
        menuActionExecutionPause->setText(QApplication::translate("SunprismVisualizerMainWindow", "Pause", 0, QApplication::UnicodeUTF8));
        menuActionExecutionStop->setText(QApplication::translate("SunprismVisualizerMainWindow", "Stop", 0, QApplication::UnicodeUTF8));
        menuActionWarning->setText(QApplication::translate("SunprismVisualizerMainWindow", "Warnings", 0, QApplication::UnicodeUTF8));
        menuActionRecordStart->setText(QApplication::translate("SunprismVisualizerMainWindow", "Start", 0, QApplication::UnicodeUTF8));
        menuActionPlayStart->setText(QApplication::translate("SunprismVisualizerMainWindow", "Start", 0, QApplication::UnicodeUTF8));
        menuActionPlayPause->setText(QApplication::translate("SunprismVisualizerMainWindow", "Pause", 0, QApplication::UnicodeUTF8));
        menuActionPlayStop->setText(QApplication::translate("SunprismVisualizerMainWindow", "Stop", 0, QApplication::UnicodeUTF8));
        menuActionSetSamplingFrequency->setText(QApplication::translate("SunprismVisualizerMainWindow", "Set Sampling Frequency", 0, QApplication::UnicodeUTF8));
        menuActionGrid->setText(QApplication::translate("SunprismVisualizerMainWindow", "Grid", 0, QApplication::UnicodeUTF8));
        menuActionGrid->setShortcut(QApplication::translate("SunprismVisualizerMainWindow", "Ctrl+L", 0, QApplication::UnicodeUTF8));
        menuActionStatusBar->setText(QApplication::translate("SunprismVisualizerMainWindow", "Status Bar", 0, QApplication::UnicodeUTF8));
        menuActionRun->setText(QApplication::translate("SunprismVisualizerMainWindow", "Run", 0, QApplication::UnicodeUTF8));
        menuActionStop->setText(QApplication::translate("SunprismVisualizerMainWindow", "Stop", 0, QApplication::UnicodeUTF8));
        menuActionPause->setText(QApplication::translate("SunprismVisualizerMainWindow", "Pause", 0, QApplication::UnicodeUTF8));
        toolbarActionNew->setText(QApplication::translate("SunprismVisualizerMainWindow", "New", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        toolbarActionNew->setToolTip(QApplication::translate("SunprismVisualizerMainWindow", "New", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label->setText(QApplication::translate("SunprismVisualizerMainWindow", "Filter", 0, QApplication::UnicodeUTF8));
        QTreeWidgetItem *___qtreewidgetitem = scenarioObjectTree->headerItem();
        ___qtreewidgetitem->setText(0, QApplication::translate("SunprismVisualizerMainWindow", "Scene Objects", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = propertyTable->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("SunprismVisualizerMainWindow", "Field", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = propertyTable->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("SunprismVisualizerMainWindow", "Value", 0, QApplication::UnicodeUTF8));
        menuFile->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "&File", 0, QApplication::UnicodeUTF8));
        menuEdit->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "&Edit", 0, QApplication::UnicodeUTF8));
        menuCommunication->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "&Communication", 0, QApplication::UnicodeUTF8));
        menuTools->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "&Tools", 0, QApplication::UnicodeUTF8));
        menuPlayback->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "&Playback", 0, QApplication::UnicodeUTF8));
        menuRecord->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "Record", 0, QApplication::UnicodeUTF8));
        menuPlay->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "Play", 0, QApplication::UnicodeUTF8));
        menuSettings->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "Settings", 0, QApplication::UnicodeUTF8));
        menuHelp->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "&Help", 0, QApplication::UnicodeUTF8));
        menuIntervention->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "&Intervention", 0, QApplication::UnicodeUTF8));
        menuScenario->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "Scene", 0, QApplication::UnicodeUTF8));
        menuEnvironment->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "Environment", 0, QApplication::UnicodeUTF8));
        menuMode->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "Mode", 0, QApplication::UnicodeUTF8));
        menuExecution->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "Execution", 0, QApplication::UnicodeUTF8));
        menuView->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "&View", 0, QApplication::UnicodeUTF8));
        menuExternalDisplay->setTitle(QApplication::translate("SunprismVisualizerMainWindow", "External Display", 0, QApplication::UnicodeUTF8));
        mainToolbar->setWindowTitle(QApplication::translate("SunprismVisualizerMainWindow", "main Toolbar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class SunprismVisualizerMainWindow: public Ui_SunprismVisualizerMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUNPRISMVISUALIZERMAINWINDOW_H
