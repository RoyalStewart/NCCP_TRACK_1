/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#ifndef TERRAIN_H
#define TERRAIN_H

#define sqr(x) (x*x)

#include <QImage>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <GL/gl.h>
#include <map>


class Terrain
{
public:
    Terrain();
    int load(const char *fname); //return 0 if success
    int loadTexture(const char *fname); //return 0 if success

    float elev(float x, float y);
    float slope(float x1, float z1, float x0, float z0);;

    void draw(int contextID = 1);
    GLfloat *normalVec(int x_coor, int z_coor);
    void normalVec(int x, int z, float norm[]);
    void normalVec(int x, int z, float &ret_x, float &ret_y, float &ret_z);

    float getCenterX(void);
    float getCenterZ(void);

private:
    float x_res;
    float z_res;
    int mapRow;
    int *mapCol;
    float **mapElev;
    std::map<int, int> gl_list_num;
    
    //QImage textureImage;
    //GLuint texture[1];
    bool useTexture;
};

#endif // TERRAIN_H
