/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "sunprismvisualizermainwindow.h"

#include "scenedefinitionreader.h"

#include "ui_sunprismvisualizermainwindow.h"
 
#include <QGLWidget>


SunprismVisualizerMainWindow::SunprismVisualizerMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SunprismVisualizerMainWindow)
{
    // TODO: this is quick solution to ensure image and other path-dependent loading
    // it should change the loading to use the application path, and utilize "resource" registeration
    QDir::setCurrent(QCoreApplication::applicationDirPath());
    
    ui->setupUi(this);

    ui->scenarioView->setVisible(false);
    
    loadScenes();
	
    // debug
    if( !sceneList.isEmpty() )
    {
        qDebug()<< "sceneList loaded";
        
        QMap<QString, SceneInterface*>::const_iterator scene_iterator = sceneList.constBegin();
         
        while( scene_iterator != sceneList.constEnd() )
        {
            qDebug() << scene_iterator.key();
            ++scene_iterator;
        }
    }

    currentScene = NULL;

	loadExternalDisplays();
    
	// debug
    if( !externalDisplayList.isEmpty() )
    {
        qDebug()<< "externalDisplayList loaded";
        
        QMap<QString, ExternalDisplayInterface*>::const_iterator external_display_iterator = externalDisplayList.constBegin();
         
        while( external_display_iterator != externalDisplayList.constEnd() )
        {
            ++external_display_iterator;
        }
    }
    
    playbackScale = 1.0;

    recordingDirectory.setPath("temp_history");
    if( !recordingDirectory.exists() )
    {
        QDir().mkdir(recordingDirectory.path());  
    }
    
    QFileInfoList file_list = recordingDirectory.entryInfoList(QDir::Files);
    
    for(int i = 0; i < file_list.size(); i++)
    {
        recordingDirectory.remove(file_list.at(i).fileName());
    }
    
    playbackDirectory.setPath(recordingDirectory.path());
    
    simulationRecorded = false;
    
    ui->outputText->hide();
    
    connect(ui->menuActionNew, SIGNAL(triggered()),
            this, SLOT(newScenario()));
    connect(ui->toolbarActionNew, SIGNAL(triggered()),
            this, SLOT(newScenario()));

    connect(ui->menuActionOpen, SIGNAL(triggered()),
            this, SLOT(openScenario()));
    connect(ui->toolbarActionOpen, SIGNAL(triggered()),
            this, SLOT(openScenario()));
      
    connect(ui->menuActionSave, SIGNAL(triggered()),
            this, SLOT(saveScenario()));
    connect(ui->toolbarActionSave, SIGNAL(triggered()),
            this, SLOT(saveScenario()));
    
    connect(ui->menuActionSaveAs, SIGNAL(triggered()),
            this, SLOT(saveScenarioAs()));
    connect(ui->toolbarActionSaveAs, SIGNAL(triggered()),
            this, SLOT(saveScenarioAs()));

    connect(ui->menuActionClose, SIGNAL(triggered()),
            this, SLOT(closeScenario()));
    
    connect(ui->menuActionExit, SIGNAL(triggered()),
            this, SLOT(close()));
    
    connect(ui->menuActionZoomIn, SIGNAL(triggered()),
            this, SLOT(zoomIn()));
    connect(ui->toolbarActionZoomIn, SIGNAL(triggered()),
            this, SLOT(zoomIn()));
    
    connect(ui->menuActionZoomOut, SIGNAL(triggered()),
            this, SLOT(zoomOut()));
    connect(ui->toolbarActionZoomOut, SIGNAL(triggered()),
            this, SLOT(zoomOut()));
    
    connect(ui->menuActionFullScreen, SIGNAL(triggered()),
            this, SLOT(toggleFullScreen()));
    connect(ui->toolbarActionFullScreen, SIGNAL(triggered()),
            this, SLOT(toggleFullScreen()));
    
    connect(ui->menuActionToolbar, SIGNAL(toggled(bool)),
            ui->mainToolbar, SLOT(setVisible(bool)));
    
    connect(ui->menuActionStatusBar, SIGNAL(toggled(bool)),
            ui->statusBar, SLOT(setVisible(bool)));
    
    /*
    connect(ui->menuActionSetConnection, SIGNAL(triggered()),
            this, SLOT(setConnectionSettings()));
    
    connect(ui->menuActionAddUnit, SIGNAL(triggered()),
            this, SLOT(addUnit()));
    connect(ui->toolbarActionAddUnit, SIGNAL(triggered()),
            this, SLOT(addUnit()));
    
    connect(ui->menuActionDeleteUnit, SIGNAL(triggered()),
            this, SLOT(deleteUnit()));
    connect(ui->toolbarActionDeleteUnit, SIGNAL(triggered()),
            this, SLOT(deleteUnit()));
    */
    
    connect(ui->menuActionSetupMode, SIGNAL(triggered()),
            this, SLOT(setRunMode()));
    connect(ui->menuActionRunMode, SIGNAL(triggered()),
            this, SLOT(setRunMode()));
    
    connect(ui->menuActionExecutionRun, SIGNAL(triggered()),
            this, SLOT(runScenario()));
    
    connect(ui->menuActionExecutionPause, SIGNAL(triggered()),
            this, SLOT(pauseScenario()));
    
    connect(ui->menuActionExecutionStop, SIGNAL(triggered()),
            this, SLOT(stopScenario()));
    
    /*
    connect(ui->menuActionTimer, SIGNAL(toggled(bool)),
            this, SLOT(showTimer(bool)));
    connect(ui->toolbarActionTimer, SIGNAL(triggered()),
            this, SLOT(showTimer()));
    */
    
    connect(ui->menuActionLoadPlayback, SIGNAL(triggered()),
            this, SLOT(loadPlayback()));

    connect(ui->menuActionSavePlayback, SIGNAL(triggered()),
            this, SLOT(savePlayback()));

    connect(ui->menuActionRecordStart, SIGNAL(triggered()),
            this, SLOT(startRecording()));

    connect(ui->menuActionRecordPause, SIGNAL(triggered()),
            this, SLOT(stopRecording()));

    connect(ui->menuActionRecordStop, SIGNAL(triggered()),
            this, SLOT(stopRecording()));

    connect(ui->toolbarActionRecord, SIGNAL(triggered()),
            this, SLOT(toggleRecording()));
    
    connect(ui->menuActionPlayStart, SIGNAL(triggered()),
            this, SLOT(startPlaying()));

    connect(ui->menuActionPlayPause, SIGNAL(triggered()),
            this, SLOT(pausePlaying()));

    connect(ui->menuActionPlayStop, SIGNAL(triggered()),
            this, SLOT(stopPlaying()));
    connect(ui->toolbarActionStop, SIGNAL(triggered()),
            this, SLOT(stopPlaying()));

    connect(ui->toolbarActionPlay, SIGNAL(triggered()),
            this, SLOT(togglePlaying()));
    
    /*
    connect(ui->pushButtonRunScenario, SIGNAL(clicked()),
            this, SLOT(toggleRunMode()));
    
    connect(ui->pushButtonUpdateUnit, SIGNAL(clicked()),
            this, SLOT(updateUnit()));
    */
    
    connect(ui->menuActionSpeedUp, SIGNAL(triggered()),
            this, SLOT(decreasePlaybackScale()));
    connect(ui->toolbarActionSpeedUp, SIGNAL(triggered()),
            this, SLOT(decreasePlaybackScale()));

    connect(ui->menuActionSpeedDown, SIGNAL(triggered()),
            this, SLOT(increasePlaybackScale()));
    connect(ui->toolbarActionSpeedDown, SIGNAL(triggered()),
            this, SLOT(increasePlaybackScale()));

    connect(ui->menuActionNormalSpeed, SIGNAL(triggered()),
            this, SLOT(resetPlaybackScale()));
    
    /*
    connect(ui->scenarioView, SIGNAL(unitMoved(Unit*)),
            this, SLOT(unitMoved(Unit*)));
    
    connect(ui->scenarioView, SIGNAL(pickCanceled()),
            this, SLOT(cancelCommand()));
    
    connect(ui->scenarioView, SIGNAL(locationPicked(QPointF)),
            this, SLOT(locationPicked(QPointF)));
    
    connect(ui->scenarioView, SIGNAL(targetPicked(QGraphicsItem *)),
            this, SLOT(targetPicked(QGraphicsItem *)));
    */
    
    connect(ui->scenarioView, SIGNAL(sceneSelectionChanged()),
            this, SLOT(sceneSelectionChanged()));
    //connect(&scenarioScene, SIGNAL(selectionChanged()),
    //        this, SLOT(scenarioSceneSelectionChanged()));
    
    connect(ui->propertyTable, SIGNAL(itemChanged(QTableWidgetItem*)),
            this, SLOT(propertyTableItemChanged(QTableWidgetItem*)));

    /*    
    connect(tcpSocket, SIGNAL(connected()), this, SLOT(sendRequest()));
    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(readServerResponse()));
    //connect(tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)),
    //        this, SLOT(displayError(QAbstractSocket::SocketError)));
    */
    
    updateScenarioTimer = new QTimer(this);
    connect(updateScenarioTimer, SIGNAL(timeout()), this, SLOT(updateScenario()));
    //updateScenarioTimer->setInterval(refreshFrequency);
    updateScenarioTimer->setInterval(100);
    updateScenarioTimer->setInterval(0);

    
    updatePlaybackTimer = new QTimer(this);
    connect(updatePlaybackTimer, SIGNAL(timeout()), this, SLOT(updatePlaybackScenario()));    
    updatePlaybackTimer->setSingleShot(true);
    
    // initialize as closed
    closeScenario();
}


SunprismVisualizerMainWindow::~SunprismVisualizerMainWindow()
{
    delete ui;
}


void SunprismVisualizerMainWindow::loadScenes()
{
    QDir scene_directory(qApp->applicationDirPath());
    scene_directory.cd("scene");

    foreach( QString fileName, scene_directory.entryList(QDir::Files) )
    {
        QPluginLoader pluginLoader(scene_directory.absoluteFilePath(fileName));
        QObject *plugin = pluginLoader.instance();

        if( plugin )
        {
            SceneInterface *scene_interface = qobject_cast<SceneInterface *>(plugin);
    
            if( scene_interface )
            {
                scene_interface->readSceneDefinition();
                
                sceneList.insert(scene_interface->getName(), scene_interface);
            }
        }
    }
}


void SunprismVisualizerMainWindow::loadExternalDisplays()
{
    QDir external_display_directory(qApp->applicationDirPath());
    external_display_directory.cd("external_display");

    foreach( QString fileName, external_display_directory.entryList(QDir::Files) )
    {
        QPluginLoader pluginLoader(external_display_directory.absoluteFilePath(fileName));
        QObject *plugin = pluginLoader.instance();

        if( plugin )
        {
            ExternalDisplayInterface *external_display_interface = qobject_cast<ExternalDisplayInterface *>(plugin);

            if( external_display_interface )
            {
                externalDisplayList.insert(external_display_interface->getName(), external_display_interface);
                
                QAction *menuActionExternalDisplay;
                menuActionExternalDisplay = new QAction(external_display_interface->getTitle(), plugin);
                ui->menuExternalDisplay->addAction(menuActionExternalDisplay);
                connect(menuActionExternalDisplay, SIGNAL(triggered()), this, SLOT(openExternalDisplay()));
            }
        }
    }
}

 
void SunprismVisualizerMainWindow::setBasicOperationsEnabled(bool enable)
{
    ui->menuActionSave->setEnabled(enable);
    ui->toolbarActionSave->setEnabled(enable);

    ui->menuActionSaveAs->setEnabled(enable);
    ui->toolbarActionSaveAs->setEnabled(enable);

    ui->menuActionClose->setEnabled(enable);

    ui->menuActionZoomIn->setEnabled(enable);
    ui->toolbarActionZoomIn->setEnabled(enable);

    ui->menuActionZoomOut->setEnabled(enable);
    ui->toolbarActionZoomOut->setEnabled(enable);
    
    ui->menuActionRunMode->setEnabled(enable);

    /*
    ui->menuActionAddUnit->setEnabled(enable);
    ui->toolbarActionAddUnit->setEnabled(enable);

    ui->menuActionEditUnit->setEnabled(enable);
    ui->toolbarActionEditUnit->setEnabled(enable);
    
    ui->menuActionDeleteUnit->setEnabled(enable);
    ui->toolbarActionDeleteUnit->setEnabled(enable);

    ui->menuActionFindUnit->setEnabled(enable);
    ui->toolbarActionFindUnit->setEnabled(enable);
                                      
    ui->pushButtonUpdateUnit->setEnabled(enable);
    */
    
    ui->menuExternalDisplay->setEnabled(enable && !ui->menuExternalDisplay->actions().isEmpty());
}


void SunprismVisualizerMainWindow::openScenario()
{
    QString filename =
            QFileDialog::getOpenFileName( this, tr("Open Sunprism Visualization File"),
                                          QDir::currentPath(),
                                          tr("PVS Files (*.pvs)") );
            
    if( filename.isEmpty() )
    {
        return;
    }
    
    currentScenarioFile.setFileName(filename);
    if( !currentScenarioFile.open(QFile::ReadOnly | QFile::Text) )
    {
        QMessageBox::warning( this, tr("Sunprism Visualization Reader"),
                              tr("Cannot read file %1:\n%2.")
                              .arg(currentScenarioFile.fileName())
                              .arg(currentScenarioFile.errorString()) );
        return;
    }

    closeScenario();
    
#if 0
    SceneDefinitionReader scene_definition_reader(&sceneDefinition);
        
    if( !scene_definition_reader.read(&currentScenarioFile) )
    {
       QMessageBox::warning(this, tr("Scene Definition Reader"),
                       tr("Parse error in file %1:\n\n%2")
                       .arg(currentScenarioFile.fileName())
                       .arg(currentScenarioFile.errorString()));
    
       return;
    }

    QString scene_name = sceneDefinition.getSceneInfoList()->value("name");
#endif

    QString scene_name = SceneDefinitionReader::readScenarioSceneName(&currentScenarioFile);    
    
    currentScene = sceneList.value(scene_name);
    
    if( currentScene )
    {
        // reset the file
        currentScenarioFile.seek(0);
        
        if( !currentScene->readScene(&currentScenarioFile) )
        {
            QMessageBox::warning(this, tr("Sunprism Visualization Reader"),
                                 tr("Parse error in file %1:\n\n%2")
                                 .arg(currentScenarioFile.fileName())
                                 .arg(currentScene->errorString()));
        }
        else
        {
            statusBar()->showMessage(tr("Sunprism Visualization file loaded"), 2000);
    
            // TODO: DISABLED
            //scenarioScene->assignID();
            
            //treeUnitsUpdate();
            
            //ui->treeUnits->expandAll();
            
            // Update scenarioView
            resetScenarioView();
            
            ui->scenarioView->setFocus(Qt::MouseFocusReason);
            
            stopScenario();
            
            setBasicOperationsEnabled(true);
        }
    }
    
    currentScenarioFile.close();
}


void SunprismVisualizerMainWindow::closeScenario()
{
    stopScenario();
    
    simulationRecorded = false;
    
    stopPlaying();
    
    initializeScenarioView();
    
    updatePropertyTable();
    
    setBasicOperationsEnabled(false);
    
    // disable recording simulation
    ui->menuActionRecordStart->setEnabled(false);
    ui->toolbarActionRecord->setEnabled(false);
    
    // disable recording simulation
    ui->menuActionRecordStart->setEnabled(false);
    ui->toolbarActionRecord->setEnabled(false);
}


void SunprismVisualizerMainWindow::initializeScenarioView()
{
    if( currentScene )
    {
        connect(ui->scenarioView, SIGNAL(sceneSelectionChanged()),
                this, SLOT(sceneSelectionChanged()));
        ui->scenarioView->setScene(NULL);
        
        ui->scenarioView->setVisible(false);
        
        currentScene = NULL; 
    }
}


void SunprismVisualizerMainWindow::resetScenarioView()
{
    resetGraphicsScene();
    
    ui->scenarioView->setScene(currentScene);
    
    connect(currentScene->getQObject(), SIGNAL(sceneSelectionChanged()),
            this, SLOT(sceneSelectionChanged()));
    
#if 0 // 02/29/12
    ui->scenarioView->updateGL();

    lastMoveTime = QTime::currentTime();
    updateScenarioTimer->start();
#endif
#if 1 // 03/28/12
    lastMoveTime = QTime::currentTime();
    //updateScenarioTimer->start();
#endif   

    ui->scenarioView->setVisible(true);
        
    ui->scenarioView->startRendering();
    
    ui->scenarioView->startUpdating();
}


void SunprismVisualizerMainWindow::resetGraphicsScene()
{
}


void SunprismVisualizerMainWindow::zoomIn()
{
#if 0 // 02/29/12
    ui->scenarioView->scale(1.1, 1.1, 1.1);
#endif
}


void SunprismVisualizerMainWindow::zoomOut()
{
#if 0 // 02/29/12
    ui->scenarioView->scale(0.9, 0.9, 0.9);
#endif
}


void SunprismVisualizerMainWindow::toggleFullScreen()
{
    if( !isFullScreen() )
    {
        showFullScreen();
    }
    else
    {
        showNormal();
    }
    
    ui->menuActionFullScreen->setChecked(isFullScreen());
}


void SunprismVisualizerMainWindow::sceneSelectionChanged()
{
    updatePropertyTable();
}


void SunprismVisualizerMainWindow::updatePropertyTable()
{
    if( !currentScene )
    {
        return;
    }
    
    ScenarioObject *selected_scenario_object =  currentScene->getSelectedScenarioObject();

    if( selected_scenario_object != NULL )
    {
        QMap<QString, QString> *field_value_list = selected_scenario_object->getFieldValueList();
        
        QMap<QString, QString>::const_iterator field_value_iterator = field_value_list->constBegin();
         
        ui->propertyTable->horizontalHeader()->show();
        ui->propertyTable->setRowCount(field_value_list->size());
        
        int row_count = 0;
     
        // TODO: find alternative way to define fieldValueList
        // currently it uses QMap, which sorts the map by keys
        // it needs to be sorted in the order read, or some other mean
        // below is just a quick cheat to put "name" field at the top
        QTableWidgetItem *field_item = new QTableWidgetItem("name");
        ui->propertyTable->setItem(row_count, 0, field_item);

        field_item->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);
        field_item->setBackground(QBrush(QColor(209, 235, 241, 255)));
        QFont font(field_item->font());
        font.setBold(true);
        field_item->setFont(font);
        
        QTableWidgetItem *value_item = new QTableWidgetItem(field_value_list->value("name"));
        ui->propertyTable->setItem(row_count, 1, value_item);
        
        //++row_count;
        
        while( field_value_iterator != field_value_list->constEnd() )
        {
            //if( field_value_iterator.key() != "name" )
            {
                QTableWidgetItem *field_item = new QTableWidgetItem(field_value_iterator.key());
                ui->propertyTable->setItem(row_count, 0, field_item);

                field_item->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);
                field_item->setBackground(QBrush(QColor(209, 235, 241, 255)));
                QFont font(field_item->font());
                font.setBold(true);
                field_item->setFont(font);
                
                QTableWidgetItem *value_item = new QTableWidgetItem(field_value_iterator.value());
                ui->propertyTable->setItem(row_count, 1, value_item);
        
                ++row_count;
            }
            
            ++field_value_iterator;
        }
    }
    else
    {
        ui->propertyTable->horizontalHeader()->hide();
        ui->propertyTable->setRowCount(0);
    }
}


void SunprismVisualizerMainWindow::propertyTableItemChanged(QTableWidgetItem *item)
{
    if( !currentScene )
    {
        return;
    }
    
#if 0
    if( item->column() == 1 )
    {
        if( currentScene->selectedItems().size() == 1 )
        {
            QTableWidgetItem *field_item = ui->propertyTable->item(item->row(), 0);
        
            ScenarioObject *selected_model_instance = (ScenarioObject*)currentScene->selectedItems().first();
            
            QMap<QString, QString> *field_value_list = selected_model_instance->getFieldValueList();
            
            field_value_list->insert(field_item->text(), item->text());
        }
    }
#endif
}


void SunprismVisualizerMainWindow::toggleRunMode()
{
    if( simulationState != RUNNING )
    {
        runScenario();
    }
    else
    {
        pauseScenario();
    }
}


void SunprismVisualizerMainWindow::setRunMode()
{
    if( simulationState != RUNNING && ui->menuActionRunMode->isChecked() )
    {
        runScenario();
    }
    else
    {
        pauseScenario();
    }
}


void SunprismVisualizerMainWindow::runScenario()
{
    if( simulationState == PAUSED )
    {
        lastMoveTime = QTime::currentTime();
    }
    else if( simulationState == NOT_RUNNING )
    {
        simulationTime = 0.0;
        lastMoveTime = QTime::currentTime();
    }
    
    setScenarioRunningMode();
    
#if 0 // 03/28/12
    updateScenarioTimer->start();
#endif 
}


void SunprismVisualizerMainWindow::updateScenario()
{
    QTime current_time = QTime::currentTime();
    double delta_time = lastMoveTime.msecsTo(current_time)/1000.0;
    
    lastMoveTime = current_time;

#if 0 // 02/29/12    
    ui->scenarioView->updateScenarioScene(delta_time);
#endif
#if 1 // 03/28/12
    ui->scenarioView->updateScene(delta_time);
#endif 

    simulationTime += delta_time;
}


void SunprismVisualizerMainWindow::setScenarioRunningMode()
{
    simulationState = RUNNING;
#if 0 // 02/29/12
    ui->scenarioView->setSimulationMode(true);
#endif
#if 1 // 03/28/12
    currentScene->setSimulationMode(true);
#endif 

    //ui->pushButtonUpdateUnit->setEnabled(true);

    setScenarioExecutionOperationMode();
}


void SunprismVisualizerMainWindow::pauseScenario()
{
#if 0
    updateScenarioTimer->stop();
#endif

    simulationState = PAUSED;

    /*
    request = "pause_scenario";
    data = "";
    
    connectToServer();
    */
    
    setScenarioExecutionOperationMode();
}


void SunprismVisualizerMainWindow::stopScenario()
{
#if 0
    updateScenarioTimer->stop();
#endif

    simulationState = NOT_RUNNING;
    
    /*
    request = "stop_scenario";
    data = "";
    
    connectToServer();
    */
    
    setScenarioExecutionOperationMode();
    
    stopRecording();
}


void SunprismVisualizerMainWindow::setScenarioExecutionOperationMode()
{
    if( simulationState == PAUSED )
    {
        ui->menuActionExecutionRun->setText("Resume");
        // ui->pushButtonRunScenario->setText("Resume");
    }
    else if( simulationState == RUNNING )
    {
        // ui->pushButtonRunScenario->setText("Pause");
    }
    else
    {
        ui->menuActionExecutionRun->setText("Run");
        // ui->pushButtonRunScenario->setText("Run");
    }
    
    // ui->pushButtonRunScenario->setEnabled(true);
    ui->menuActionExecutionRun->setEnabled(simulationState != RUNNING);
    
    ui->menuActionExecutionPause->setEnabled(simulationState == RUNNING);
    ui->menuActionExecutionStop->setEnabled(simulationState == RUNNING || simulationState == PAUSED);
    
    ui->menuActionSetupMode->setChecked(simulationState != RUNNING);
    ui->menuActionRunMode->setChecked(simulationState == RUNNING);
}


void SunprismVisualizerMainWindow::toggleRecording()
{
    if( recordSimulation )
    {
        stopRecording();
    }
    else
    {
        startRecording();
    }
}


void SunprismVisualizerMainWindow::startRecording()
{
    recordSimulation = true;
    simulationRecorded = false;
    
    QFileInfoList file_list = recordingDirectory.entryInfoList(QDir::Files);
    
    // remove all files in recording directory
    for(int i = 0; i < file_list.size(); i++)
    {
        recordingDirectory.remove(file_list.at(i).fileName());
    }        
    
    playbackDirectory.setPath(recordingDirectory.path());
    
    setPlaybackOperationMode();
}


void SunprismVisualizerMainWindow::stopRecording()
{
    recordSimulation = false;
    
    QFileInfoList file_list = playbackDirectory.entryInfoList(QDir::Files);
    
    if( file_list.size() > 0 )
    {
        simulationRecorded = true;
    }
    
    setPlaybackOperationMode();
}


void SunprismVisualizerMainWindow::togglePlaying()
{
    if( playRecording )
    {
        pausePlaying();
    }
    else
    {
        startPlaying();
    }
}


void SunprismVisualizerMainWindow::startPlaying()
{
    setScenarioPlaybackMode();
    
    updatePlaybackFileList();

    if( !playbackPaused )
    {
        playbackFileListIterator = playbackFileListMap.constBegin();
    }
    
    // start playback if there is any file
    if( playbackFileListIterator != playbackFileListMap.constEnd() )
    { 
        playRecording = true;
        playbackPaused = false;
    
        setPlaybackOperationMode();
     
        //stopScenario();
        
        updatePlaybackScenario();
    }
    else
    {
        stopPlaying();
    }
}


void SunprismVisualizerMainWindow::updatePlaybackFileList()
{
    QFileInfoList file_list = playbackDirectory.entryInfoList(QDir::Files);
    
    playbackFileListMap.clear();
    
    // add filename (including path) to the map with simulation time    
    for(int i = 0; i < file_list.size(); i++)
    {
        // base_name indicates the simulation time (i.e. 2_5 is 2.5 seconds)
        //QString base_name = file_list.at(i).baseName();
        //base_name.replace(QString("_"), QString("."));
         
        QString base_name = file_list.at(i).completeBaseName();
        playbackFileListMap.insert(base_name.toFloat(), file_list.at(i).filePath());
    }        
}


void SunprismVisualizerMainWindow::setScenarioPlaybackMode()
{
    // reset scenario running mode
    stopScenario();
    
    // disable running scenario     
    // ui->pushButtonRunScenario->setEnabled(false);  
    ui->menuActionExecutionRun->setEnabled(false);
    
    // TODO: DISABLED
    /*
    // item is only selectable (no drag move) and no command during playback
    for( unsigned int i = 0; i < scenario.getUnitList()->size(); i++ )
    {
        Unit *unit = scenario.getUnitList()->value(i);

        // change to simulation mode
        unit->setFlags(QGraphicsItem::ItemIsSelectable);
        unit->setCommandEnabled(false);
    }
    */
}


void SunprismVisualizerMainWindow::updatePlaybackScenario()
{
    // do nothing if not play recording (i.e. paused)
    if( !playRecording )
    {
        return;
    }
        
    // if there is more file, read and update unit list
    if( playbackFileListIterator != playbackFileListMap.constEnd() )
    {
        QFile file(playbackFileListIterator.value());
        
        if ( !file.open(QIODevice::ReadOnly | QIODevice::Text) )
        {
            // error. stop playing and return
            stopPlaying();
            
            return;
        }
        
        
#if 0 // NEED TO SWITCH TO INTERFACE        
        ScenarioReader scenario_reader(&scenarioScene);
        scenario_reader.setScenarioObjectTypeList(scenarioScene.getScenarioObjectTypeList());
        scenario_reader.read(&file);
#endif

#if 0 // 02/29/12
        ui->scenarioView->updateGL();
#endif
        //ui->scenarioView->setScene(&scenarioScene);
        //resetScenarioView();
            
        float current_simulation_time = playbackFileListIterator.key();
        float next_simulation_time;
        
        int delta_time = 0.0;
        int min_delta_time = 100;
        int num_skip_file = 0;
        
        while( delta_time < min_delta_time && (playbackFileListIterator + num_skip_file + 1) != playbackFileListMap.constEnd() )
        {
            num_skip_file++;
            
            next_simulation_time = (playbackFileListIterator + num_skip_file).key();

            delta_time = (next_simulation_time - current_simulation_time) * 1000;
            
            delta_time = delta_time * playbackScale;
        }

        if( num_skip_file >= 1)
        {
            if( (playbackFileListIterator + num_skip_file) == playbackFileListMap.constEnd() )
            {
                num_skip_file--;
                
                next_simulation_time = (playbackFileListIterator + num_skip_file).key();
    
                delta_time = (next_simulation_time - current_simulation_time) * 1000;
                
                delta_time = delta_time * playbackScale;
            }

            playbackFileListIterator = playbackFileListIterator + num_skip_file;
            
            //QTimer::singleShot(delta_time, this, SLOT(updatePlaybackScenario()));
            
            updatePlaybackTimer->setInterval(delta_time);
            updatePlaybackTimer->start();
            
            return;
        }
    }
 
    // if it reaches the end of file list, or plaback mode is off, stop playing
    stopPlaying();
}
    

void SunprismVisualizerMainWindow::pausePlaying()
{
    playRecording = false;
    playbackPaused = true;
    
    setPlaybackOperationMode();
}


void SunprismVisualizerMainWindow::stopPlaying()
{
    playRecording = false;
    playbackPaused = false;
    
    setPlaybackOperationMode();
    
    // reset scenario running mode
    stopScenario();
}


void SunprismVisualizerMainWindow::setPlaybackOperationMode()
{
    if( playbackPaused )
    {
        ui->toolbarActionPlay->setIcon(QIcon("image/play.png"));
        ui->toolbarActionPlay->setText("Resume");
        ui->menuActionPlayStart->setText("Resume");
    }
    else if( playRecording )
    {
        ui->toolbarActionPlay->setIcon(QIcon("image/pause.png"));
        ui->toolbarActionPlay->setText("Pause");
    }
    else
    {
        ui->toolbarActionPlay->setIcon(QIcon("image/play.png"));
        ui->toolbarActionPlay->setText("Start");
        ui->menuActionPlayStart->setText("Start");
    }
    
    ui->menuActionRecordStart->setEnabled(!playRecording && !recordSimulation);
    
    //ui->menuActionRecordPause->setEnabled(!playRecording && recordSimulation);
    ui->menuActionRecordPause->setEnabled(recordSimulation);
    //ui->menuActionRecordStop->setEnabled(!playRecording && recordSimulation);
    ui->menuActionRecordStop->setEnabled(recordSimulation);
    
    ui->toolbarActionRecord->setEnabled(!playRecording && !recordSimulation);
    
    //ui->toolbarActionStop->setEnabled(playRecording || recordSimulation);
    ui->toolbarActionStop->setEnabled(playRecording);

    ui->menuActionPlayStart->setEnabled(!recordSimulation && simulationRecorded && !playRecording);
    
    //ui->menuActionPlayPause->setEnabled(!recordSimulation && simulationRecorded && playRecording);
    //ui->menuActionPlayStop->setEnabled(!recordSimulation && simulationRecorded && playRecording);
    
    //ui->menuActionPlayPause->setEnabled(!recordSimulation && playRecording);
    ui->menuActionPlayPause->setEnabled(playRecording);
    ui->menuActionPlayStop->setEnabled(!recordSimulation && (playRecording || playbackPaused));
    
    ui->toolbarActionPlay->setEnabled(!recordSimulation && simulationRecorded);
    
    ui->toolbarActionSpeedUp->setEnabled(playRecording);
    ui->toolbarActionSpeedDown->setEnabled(playRecording);
    
    ui->menuActionSavePlayback->setEnabled(simulationRecorded);
}


void SunprismVisualizerMainWindow::loadPlayback()
{
    QString directory_name =
            QFileDialog::getExistingDirectory( this, tr("Load Playback Directory"),
                                               QDir::currentPath(),
                                               QFileDialog::ShowDirsOnly );

    if( directory_name.isEmpty() )
    {
        return;
    }
      
    playbackDirectory.setPath(directory_name);
    
    updatePlaybackFileList();

    // start playback if there is any file
    //if( playbackFileListMap.size() > 0 )
    if( playbackFileListMap.constBegin() != playbackFileListMap.constEnd() )
    {
        // this is almost same as openScenario
        
        QFile playback_file(playbackFileListMap.constBegin().value());

        if( !playback_file.open(QFile::ReadOnly | QFile::Text) )
        {
            QMessageBox::warning( this, tr("Sunprism Visualization Reader"),
                                  tr("Cannot read file %1:\n%2.")
                                  .arg(playback_file.fileName())
                                  .arg(playback_file.errorString()) );
            return;
        }
        
        closeScenario();
    
#if 0 // NEED TO SWITCH TO INTERFACE   
        SceneReader scene_reader( scenarioScene.getScenarioObjectTypeList(),
                                  scenarioScene.getEnvironmentFactorList() );
            
        if( !scene_reader.read(&playback_file) )
        {
           QMessageBox::warning(this, tr("Scene Reader"),
                           tr("Parse error in file %1:\n\n%2")
                           .arg(playback_file.fileName())
                           .arg(playback_file.errorString()));
        
           return;
        } 
        
        // reset the file
        playback_file.seek(0);

        ScenarioReader scenario_reader(&scenarioScene);
        scenario_reader.setScenarioObjectTypeList(scenarioScene.getScenarioObjectTypeList());
        
        if( !scenario_reader.read(&playback_file) )
        {
            QMessageBox::warning(this, tr("Sunprism Visualization Reader"),
                                 tr("Parse error in file %1:\n\n%2")
                                 .arg(playback_file.fileName())
                                 .arg(scenario_reader.errorString()));
        }
        else
        {
            statusBar()->showMessage(tr("Sunprism Visualization playback file loaded"), 2000);
            
            // TODO: DISABLED
            /*
            treeUnitsUpdate();
    
            ui->treeUnits->expandAll();
            */
            
            // Update scenarioView
            resetScenarioView();
    
            stopScenario();
                    
            setBasicOperationsEnabled(true);
            
            // disable save, since no filename to save yet
            ui->menuActionSave->setEnabled(false);
            ui->toolbarActionSave->setEnabled(false);
            ui->menuActionSaveAs->setEnabled(false);
            ui->toolbarActionSaveAs->setEnabled(false);
        }
        
        playback_file.close();
#endif

    }
}


void SunprismVisualizerMainWindow::savePlayback()
{
}

    
void SunprismVisualizerMainWindow::decreasePlaybackScale()
{
    playbackScale = playbackScale * 0.5;
    
    updatePlaybackTimer->stop();
    
    updatePlaybackScenario();
}


void SunprismVisualizerMainWindow::increasePlaybackScale()
{
    playbackScale = playbackScale * 2.0;
    
    updatePlaybackTimer->stop();
    
    updatePlaybackScenario();
}


void SunprismVisualizerMainWindow::resetPlaybackScale()
{
    playbackScale = 1.0;
    
    updatePlaybackTimer->stop();
    
    updatePlaybackScenario();
}


void SunprismVisualizerMainWindow::openExternalDisplay()
{
    QAction *action = qobject_cast<QAction *>(sender());
    ExternalDisplayInterface *external_display_interface = qobject_cast<ExternalDisplayInterface *>(action->parent());

    external_display_interface->openExternalDisplay(currentScene);
}

