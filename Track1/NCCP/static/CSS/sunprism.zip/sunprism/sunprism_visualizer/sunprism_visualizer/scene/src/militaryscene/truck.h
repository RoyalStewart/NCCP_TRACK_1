#ifndef TRUCK_H
#define TRUCK_H

#include "scenarioobject.h"


// forward declaration to resolve cross referencing 'include's
class Scene;


class Truck : public ScenarioObject
{
    Q_OBJECT
    
public:
    /* constructor */
    Truck(Scene *scene);
    //ScenarioObject(ScenarioObject *copy_unit);
    ~Truck();

    static int glListNum;
    
protected:
    virtual void drawSceneObject();
};

#endif // TRUCK_H
