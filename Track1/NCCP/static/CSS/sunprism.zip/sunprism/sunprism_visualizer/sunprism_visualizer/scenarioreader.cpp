/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scenarioreader.h"

#include <QtGui>


ScenarioReader::ScenarioReader(ScenarioScene *scenario_scene)
{
    scenarioScene = scenario_scene;
}


void ScenarioReader::setScenarioObjectTypeList(QMap<QString, ScenarioObjectType*> *scenario_object_type_list)
{
    scenarioObjectTypeList = scenario_object_type_list;
}


bool ScenarioReader::read(QIODevice *device)
{
    xml_reader.setDevice(device);

    //computationalModelList->clear();
            
    if( xml_reader.readNextStartElement() )
    {
        if( xml_reader.name() == "scenario" )
        {
            readScenario();
        }
        else
        {
            xml_reader.raiseError(QObject::tr("The file is not an Scenario file."));
        }
    }

    return !xml_reader.error();
}


QString ScenarioReader::errorString() const
{
    return QObject::tr("%1\nLine %2, column %3")
            .arg(xml_reader.errorString())
            .arg(xml_reader.lineNumber())
            .arg(xml_reader.columnNumber());
}


void ScenarioReader::readScenario()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "scenario");
    
    QMap<QString, ScenarioObject*> remove_scenario_object_list = *scenarioScene->getScenarioObjectList();
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "object" )
        {
            ScenarioObject *scenario_object = new ScenarioObject(scenarioScene);
            
            QString scenario_object_id = xml_reader.attributes().value("object_id").toString();
            
            scenarioObject = scenarioScene->getScenarioObjectList()->value(scenario_object_id);

            if( scenarioObject == NULL )
            {
                scenarioObject = new ScenarioObject(scenarioScene);
                scenarioObject->setScenarioObjectID(scenario_object_id);
                
                scenarioScene->getScenarioObjectList()->insert(scenario_object_id, scenarioObject);
            }
            else
            {
                remove_scenario_object_list.remove(scenario_object_id);
            }
            
            QString object_type_name = xml_reader.attributes().value("object_type").toString();
            
            if( scenarioObjectTypeList != NULL )
            {
                ScenarioObjectType *object_type = scenarioObjectTypeList->value(object_type_name);

                scenarioObject->setScenarioObjectType(object_type);
            }
            
            readScenarioObject();
        }
        else
        {
            //xml_reader.skipCurrentElement();
            
            QString value = xml_reader.readElementText();
            
            scenarioScene->getScenarioInfoList()->insert(name, value);
        }
    }

    QMap<QString, ScenarioObject*>::const_iterator remove_iterator = remove_scenario_object_list.constBegin();

    while( remove_iterator != remove_scenario_object_list.constEnd() )
    {
        scenarioScene->getScenarioObjectList()->remove(remove_iterator.key());
        
        delete remove_iterator.value();
        
        ++remove_iterator;
    }    
}
 

void ScenarioReader::readScenarioObject()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "object");
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "translation" )
        {
            QString value_string = xml_reader.readElementText();

            QStringList value_string_list = value_string.split(":");
            if( value_string_list.size() == 3 )                
            {
                scenarioObject->setTranslation(value_string_list[0].toDouble(), value_string_list[1].toDouble(), value_string_list[2].toDouble());
            }
        }
        if( name == "scale" )
        {
            QString value_string = xml_reader.readElementText();

            QStringList value_string_list = value_string.split(":");
            if( value_string_list.size() == 3 )                
            {
                scenarioObject->setScale(value_string_list[0].toDouble(), value_string_list[1].toDouble(), value_string_list[2].toDouble());
            }
        }        
        else
        {
            QString value = xml_reader.readElementText();
            
            scenarioObject->getFieldValueList()->insert(name, value);
        }
    }
}

