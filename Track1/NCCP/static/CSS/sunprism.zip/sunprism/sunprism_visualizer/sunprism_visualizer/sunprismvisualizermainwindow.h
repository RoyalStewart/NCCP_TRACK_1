/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#ifndef SUNPRISMVISUALIZERMAINWINDOW_H
#define SUNPRISMVISUALIZERMAINWINDOW_H

#include <QMainWindow>

#include "sceneinterface.h"
#include "externaldisplayinterface.h"
#include "glwidget.h"

#include "scenedefinition.h"

namespace Ui {
    class SunprismVisualizerMainWindow;
}


class SunprismVisualizerMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit SunprismVisualizerMainWindow(QWidget *parent = 0);
    ~SunprismVisualizerMainWindow();
    
private slots:
    void loadScenes();
    void loadExternalDisplays();
    
    void setBasicOperationsEnabled(bool enable);
    
    //void newScenario();
    void openScenario();
    //void saveScenario();
    //void saveScenarioAs();
    void closeScenario();
    
    void zoomIn();
    void zoomOut();
    void toggleFullScreen();
    
    void initializeScenarioView();
    void resetScenarioView();
    void resetGraphicsScene();
    void sceneSelectionChanged();

    void updatePropertyTable();
    void propertyTableItemChanged(QTableWidgetItem *item);
    
    void toggleRunMode();
    void setRunMode();
    void runScenario();
    void updateScenario();
    void setScenarioRunningMode();
    void pauseScenario();
    void stopScenario();
    
    void setScenarioExecutionOperationMode();
    
    void toggleRecording();
    void startRecording();
    void stopRecording();
    
    void togglePlaying();
    void startPlaying();
    void updatePlaybackFileList();
    void setScenarioPlaybackMode();
    void updatePlaybackScenario();
    void pausePlaying();
    void stopPlaying();
    void setPlaybackOperationMode();
    
    void loadPlayback();
    void savePlayback();
    void decreasePlaybackScale();
    void increasePlaybackScale();
    void resetPlaybackScale();
    
    void openExternalDisplay();
    
private:
    Ui::SunprismVisualizerMainWindow *ui;
    
    QMap<QString, SceneInterface*> sceneList;
    QMap<QString, ExternalDisplayInterface*> externalDisplayList;
    
    QFile currentScenarioFile;
    //ScenarioScene scenarioScene;
    SceneDefinition sceneDefinition;
    
    SceneInterface *currentScene;

    // TODO: DISABLED
    /*
    int unitSelectedIndex;
    
    enum COMMAND_MODE {NO_MODE, LOCATION, TARGET, LOCATIONS};
    COMMAND_MODE commandMode;
    QString currentCommand;
    Unit *commandUnit;
    */

    double simulationTime;
    QTime lastMoveTime;
    QTimer *updateScenarioTimer;

    enum SIMULATION_STATE {NOT_RUNNING, PAUSED, RUNNING};
    SIMULATION_STATE simulationState;
    
    // recording and playback
    bool recordSimulation;
    QDir recordingDirectory;
    QDir playbackDirectory;
    bool simulationRecorded;
    
    bool playRecording;
    bool playbackPaused;
    
    QTimer *updatePlaybackTimer;    
    
    // QMap iterator allows the list to be sorted by key
    QMap<float, QString> playbackFileListMap;
    QMap<float, QString>::const_iterator playbackFileListIterator;
    
    int playbackFileIndex;
    float playbackScale;
    
    GlWidget *glUpdaterWidget;
};

#endif // SUNPRISMVISUALIZERMAINWINDOW_H
