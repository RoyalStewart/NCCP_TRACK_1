/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "GLThread.h"
#include <QTime>

#include <QtGui>
#include <QtOpenGL>
#include <QColor>

#include "GLWidget.h"


GLThread::GLThread(GLWidget *gl) 
	: QThread(), glw(gl)
{
	doRendering = true;
	doResize = false;
	newFrame = false;
	lastFrameTime = 0;
	time.start();
	
	frames = 0;
}

void GLThread::stop()
{
	doRendering = false;
}

void GLThread::resizeViewport(const QSize &size)
{
	QMutexLocker lock(&resizeMutex);
	w = size.width();
	h = size.height();
	doResize = true;
}    

void GLThread::frameReady()
{
}


void GLThread::run()
{
	srand(QTime::currentTime().msec());
	xrot = 0; //rand() % 360;
	yrot = 0; //rand() % 360;
	zrot = 0; //rand() % 360;
	
	xscale = 1;
	yscale = 1;
	zscale = 1;
	
	xscaleInc = 0.1;
	yscaleInc = 0.2;
	zscaleInc = 0.4;
	
	glw->makeCurrent();
	
	QImage texOrig, texGL;
	if ( !texOrig.load( "me2.jpg" ) )
	{
		texOrig = QImage( 16, 16, QImage::Format_RGB32 );
		texOrig.fill( Qt::green );
	}
	
	texGL = QGLWidget::convertToGLFormat( texOrig );
	glGenTextures( 1, &texture[0] );
	glBindTexture( GL_TEXTURE_2D, texture[0] );
	glTexImage2D( GL_TEXTURE_2D, 0, 3, texGL.width(), texGL.height(), 0, GL_RGBA, GL_UNSIGNED_BYTE, texGL.bits() );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	
	QSize textureSize = texGL.size();
	
	
	glEnable(GL_TEXTURE_2D);					// Enable Texture Mapping ( NEW )
	glShadeModel(GL_SMOOTH);					// Enable Smooth Shading
	//glClearColor(0.0f, 0.0f, 1.0f, 1.0f);				// Black Background
	glClearColor(0.1f, 0.1f, 0.2f, 1.0f);
	glClearDepth(1.0f);						// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);					// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);						// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);		// Really Nice Perspective Calculations
	glViewport(0, 0, 320,240);
	
	float opacity = 0.90;
	glColor4f(opacity,opacity,opacity,opacity);			// Full Brightness, 50% Alpha ( NEW )
	//glBlendFunc(GL_SRC_ALPHA,GL_ONE);				// Blending Function For Translucency Based On Source Alpha Value ( NEW )
	glEnable (GL_BLEND); 
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	//glBlendFunc(GL_ONE, GL_ZERO);
	//glDisable(GL_DEPTH_TEST);
	glEnable(GL_LINE_SMOOTH);


	int sleep = 1000/60;
	while (doRendering) 
	{
		
		if (doResize) 
		{
			resizeMutex.lock();
			glViewport(0, 0, w, h);
			doResize = false;
			
			if(h == 0)
				h = 1;
			
			glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
			glLoadIdentity();							// Reset The Projection Matrix
		
			// Calculate The Aspect Ratio Of The Window
			gluPerspective(45.0f,(GLfloat)w/(GLfloat)h,0.1f,100.0f);
		
			glMatrixMode(GL_MODELVIEW);						// Select The Modelview Matrix
			glLoadIdentity();							// Reset The Modelview Matrix
			resizeMutex.unlock();
		}
		
		
		
		// Rendering code goes here
		
 		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear The Screen And The Depth Buffer
		glLoadIdentity();									// Reset The View
		glTranslatef(0.0f,0.0f,-5.0f);
	
 		glRotatef(xrot,1.0f,0.0f,0.0f);
 		glRotatef(yrot,0.0f,1.0f,0.0f);
 		glRotatef(zrot,0.0f,0.0f,1.0f);
	
		//glScalef(xscale, yscale, zscale);
	
		
		glBindTexture(GL_TEXTURE_2D, texture[0]);
		
		glBegin(GL_QUADS);
			// Front Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
			// Back Face
			glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
			// Top Face
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
			// Bottom Face
			glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
			// Right face
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
			glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
			// Left Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
		glEnd();
	
		xrot+=0.3f;
		yrot+=0.2f;
		zrot+=0.4f;
		
        if (!(frames % 100)) 
        {
			QString framesPerSecond;
			framesPerSecond.setNum(frames /(time.elapsed() / 1000.0), 'f', 2);

			time.start();
			frames = 0;
			
			lastFrameTime = time.elapsed();
		}
		
		frames ++;

		glw->swapBuffers();
		msleep(1000/80);
		//msleep(sleep);
	}
}


