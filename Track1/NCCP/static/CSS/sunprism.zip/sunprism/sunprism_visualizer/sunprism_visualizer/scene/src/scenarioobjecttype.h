/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#ifndef SCENARIOOBJECTTYPE_H
#define SCENARIOOBJECTTYPE_H

#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
//#include <GL/gl.h>
//#include <freevr.h>
#include <iostream>
#include <cassert>
//#include "ModelType.h"

#include <QtGui>
#include "command.h"

using namespace std;


class ScenarioObjectType
{
public:
    ScenarioObjectType();
    
    void setName(const char*);

    void addProperty(void);
    void setPropName(const char*);
    void setPropInit(float);
    void setPropMax(float);
    void setPropMin(float);

    void addCmd(void);
    void setCmdName(const char*);
    void setCmdType(int);

    char* getName(void);
    int getPropSize(void);
    char* getPropName(unsigned int);
    float getPropInit(unsigned int);
    float getPropMax(unsigned int);
    float getPropMin(unsigned int);

    int getCmdSize(void);
    char* getCmdName(unsigned int);
    int getCmdType(unsigned int);

    void draw();
    
    QVector<Command*>* getCommandVector();
    void clearCommandVector();

private:
    char name[32];
    vector<char*> propName;
    vector<float> propInit;
    vector<float> propMax;
    vector<float> propMin;
    vector<char*> cmdName;
    vector<int> cmdType;
    
    int glListNum;
    
    QVector<Command*> commandVector;
};

#endif
