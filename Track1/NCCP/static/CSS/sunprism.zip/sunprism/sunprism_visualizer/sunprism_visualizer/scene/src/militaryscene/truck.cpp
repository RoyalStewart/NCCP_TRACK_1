#include "truck.h"


int Truck::glListNum = -1;


Truck::Truck(Scene *scene) :
    ScenarioObject(scene)
{
    initialize3dsModel("scene/model/truck.3ds");
}


Truck::~Truck()
{
}


void Truck::drawSceneObject()
{
    if( glListNum < 0 )
    {
        glListNum = glGenLists(1);
        glNewList(glListNum, GL_COMPILE);

        render3dsModel("scene/model/truck.3ds");
        
        glEndList();
        
        glCallList(glListNum);
    }
    else
    {
        glCallList(glListNum);
    }
}

