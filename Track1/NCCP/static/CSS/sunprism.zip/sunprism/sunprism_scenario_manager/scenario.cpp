/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scenario.h"


Scenario::Scenario() :
    QGraphicsScene()
{
    drawGrid = true;
    gridStep = 50;
    snapToGrid = false;
}


Scenario::~Scenario()
{
}


QVector<DataModelInstance*>* Scenario::getDataModelInstanceList()
{ 
    return &dataModelInstanceList;
}


QVector<ComputationalModelInstance*>* Scenario::getComputationalModelInstanceList()
{ 
    return &computationalModelInstanceList;
}



DataModelInstance* Scenario::findDataModelInstance(QString name)
{ 
    for( int i = 0; i < dataModelInstanceList.size(); i++ )
    {
        DataModelInstance *data_model_instance = dataModelInstanceList[i];

        QMap<QString, QString> *field_value_list = data_model_instance->getFieldValueList();
        
        if( field_value_list->value("name") == name )
        {
            return data_model_instance;
        }
    }
    
    return NULL;
}


void Scenario::clearModelInstanceList()
{
    dataModelInstanceList.clear();
    computationalModelInstanceList.clear();
}
    

void Scenario::setDrawGrid(bool draw_grid)
{
    drawGrid = draw_grid;
}


bool Scenario::getDrawGrid()
{
    return drawGrid;
}


void Scenario::setGridStep(int grid_step)
{
    gridStep = grid_step;
}


int Scenario::getGridStep()
{
    return gridStep;
}


void Scenario::setSnapToGrid(bool snap_to_grid)
{
    snapToGrid = snap_to_grid;
}


bool Scenario::getSnapToGrid()
{
    return snapToGrid;
}


void Scenario::resetGraphicsScene()
{
    clear();
    
    setSceneRect(0, 0, 2000, 2000);

    for( int i = 0; i < dataModelInstanceList.size(); i++ )
    {
        DataModelInstance *data_model_instance = dataModelInstanceList[i];

        QMap<QString, QString> *field_value_list = data_model_instance->getFieldValueList();
        
        QMap<QString, QString>::const_iterator field_value_iterator = field_value_list->constBegin();
         
        while (field_value_iterator != field_value_list->constEnd())
        {
            ++field_value_iterator;
        }
        
        addItem(data_model_instance);
        
        data_model_instance->setPos(field_value_list->value("x").toDouble(), field_value_list->value("y").toDouble());        
    }            
    
    for( int i = 0; i < computationalModelInstanceList.size(); i++ )
    {
        ComputationalModelInstance *computational_model_instance = computationalModelInstanceList[i];

        QMap<QString, QString> *field_value_list =  computational_model_instance->getFieldValueList();
        
        QMap<QString, QString>::const_iterator field_value_iterator = field_value_list->constBegin();
         
        while (field_value_iterator != field_value_list->constEnd())
        {
            ++field_value_iterator;
        }
        
        addItem(computational_model_instance);
        
        computational_model_instance->setPos(field_value_list->value("x").toDouble(), field_value_list->value("y").toDouble());
    }
}

QRectF Scenario::visibleItemsBoundingRect() const
{
    QRectF boundingRect;

    foreach( QGraphicsItem *item, items() )
    {
        if( item->isVisible() )
        {
            boundingRect |= item->sceneBoundingRect();
        }
    }
    
    return boundingRect;
}


void Scenario::drawBackground(QPainter *painter, const QRectF &rect)
{  
    if( drawGrid )
    {
        qreal grid_left = int(rect.left()) - (int(rect.left()) % gridStep);
        qreal grid_top = int(rect.top()) - (int(rect.top()) % gridStep);
         
        QVarLengthArray<QLineF> grid_lines;
        
        // get all vertical lines
        for( qreal x = grid_left; x < rect.right(); x += gridStep )
        {
            grid_lines.append(QLineF(x, rect.top(), x, rect.bottom()));
        }
         
        // get all horizontal lines
        for( qreal y = grid_top; y < rect.bottom(); y += gridStep )
        {
            grid_lines.append(QLineF(rect.left(), y, rect.right(), y));
        }
        
        // disable antialias, then restore after drawing grid lines
        bool is_anti_alias = painter->renderHints() & QPainter::Antialiasing;
        painter->setRenderHint(QPainter::Antialiasing, false);
    
        painter->setPen(QPen(QColor(191, 191, 191), 0));
        painter->drawLines(grid_lines.data(), grid_lines.size());     
    
        painter->setRenderHint(QPainter::Antialiasing, is_anti_alias);
    }
}

