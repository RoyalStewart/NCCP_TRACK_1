/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "progressindicator.h"

static const double PI = 3.14159265358979323846264338327950288419717;


ProgressIndicator::ProgressIndicator() :
    QGraphicsItem()
{
    radius = 75;
    angle = 0;
    text = "";
    mode = 0;
}


ProgressIndicator::~ProgressIndicator()
{
}


void ProgressIndicator::setText(QString text)
{
    this->text = text;
    update();
}

    
void ProgressIndicator::setAngle(int angle)
{
    this->angle = angle;
    update();
}


void ProgressIndicator::setMode(int mode)
{
    this->mode = mode;
    update();
}


QRectF ProgressIndicator::boundingRect() const
{     
    QRectF bounding_rectangle = QRectF(-radius/2, -radius/2, radius, radius);
 
    return bounding_rectangle;
}


QPainterPath ProgressIndicator::shape() const
{
    QPainterPath path;

    path.addRect(-radius/2, -radius/2, radius, radius);
    
    return path;
}


void ProgressIndicator::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{   
    QRectF bounding_rect = boundingRect();
    
    qreal outer_width = 15;
    qreal inner_radius = radius - outer_width;
    
    if( mode == 0 )
    {
        int start_angle = (-angle + 90 - 45) * 16;
        int span_angle = 45 * 16;
        
        QPointF radial_center;
        radial_center.setX(cos((angle-90)*(PI/180)) * (radius-outer_width/2)/2);
        radial_center.setY(sin((angle-90)*(PI/180)) * (radius-outer_width/2)/2);
        QRadialGradient radial_gradient1(radial_center, 50);
        radial_gradient1.setColorAt(0, Qt::green);
        radial_gradient1.setColorAt(1, Qt::blue);
        painter->setBrush(radial_gradient1);   
        painter->drawEllipse(QRectF(-radius/2, -radius/2, radius, radius));
        
        painter->setBrush(Qt::white);   
        painter->drawEllipse(QRectF(-inner_radius/2, -inner_radius/2, inner_radius, inner_radius));
    }
    else
    {
        painter->setBrush(Qt::yellow);
        painter->drawEllipse(QRectF(-radius/2, -radius/2, radius, radius));
        
        painter->setBrush(Qt::white);   
        painter->drawEllipse(QRectF(-inner_radius/2, -inner_radius/2, inner_radius, inner_radius));
    }
    
    
    painter->drawText(bounding_rect, Qt::AlignCenter, text);
}
