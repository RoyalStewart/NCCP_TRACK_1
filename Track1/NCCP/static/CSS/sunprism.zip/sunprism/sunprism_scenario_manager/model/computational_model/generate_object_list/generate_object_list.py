# Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
# obo University of Nevada, Reno
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#  * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

import os
import shutil
from collections import defaultdict
import math
import random


class MovingObject:

    def __init__(self):
        self.position = [0.0, 0.0, 0.0]
        self.radius = 10.0
        self.velocity = [0.0, 0.0, 0.0]
        self.speed = 0.0
        
        
class Generate_object_list:

    def __init__(self):
        self.fieldValueList = {}
        self.inputDataModelList = {}
        self.outputDataModelList = {}
    
    
    def run(self):
        
        source_position_string = (self.fieldValueList["source_position"]).split(':')
        
        source_object = MovingObject()
        
        source_object.position[0] = float(source_position_string[0])
        source_object.position[1] = float(source_position_string[1])
        source_object.position[2] = float(source_position_string[2])
    
        source_object.radius = float(self.fieldValueList["source_radius"])
        source_object.speed = float(self.fieldValueList["source_speed"])
        
        
        destination_position_string = (self.fieldValueList["destination"]).split(':')
        
        destination_object = MovingObject()
        
        destination_object.position[0] = float(destination_position_string[0])
        destination_object.position[1] = float(destination_position_string[1])
        destination_object.position[2] = float(destination_position_string[2])
    
    
        num_enemy = int(self.fieldValueList["num_enemy"])
        
        
        random_radius = math.sqrt( math.pow(destination_object.position[0] - source_object.position[0], 2) + \
                                   math.pow(destination_object.position[1] - source_object.position[1], 2) + \
                                   math.pow(destination_object.position[2] - source_object.position[2], 2) ) / 2
        
        random_center = [ (destination_object.position[0] - source_object.position[0])/2, \
                          (destination_object.position[1] - source_object.position[1])/2, \
                          (destination_object.position[2] - source_object.position[2])/2 ]
        
                              
        max_difference = max( abs(destination_object.position[0] - source_object.position[0]), \
                              abs(destination_object.position[1] - source_object.position[1]), \
                              abs(destination_object.position[2] - source_object.position[2]) )
        
        
        enemy_object_list = []
        
        enemy_radius = 10.0
        enemy_speed = 0.0
        enemy_velocity = [10.0, 0.0, 0.0]
        
        for i in range(num_enemy):
            enemy_object = MovingObject()
            
            #x = random_center[0] + random.triangular(-random_radius, random_radius)
            #y = random_center[1] + random.triangular(-random_radius, random_radius)
            #z = random_center[2] + random.triangular(-random_radius, random_radius)
        
            #x = random_center[0] + random.gauss(random_radius, math.sqrt(random_radius*4)) - random_radius
            #y = random_center[1] + random.gauss(random_radius, math.sqrt(random_radius*4)) - random_radius
            #z = random_center[2] + random.gauss(random_radius, math.sqrt(random_radius*4)) - random_radius
            x = random_center[0] + random.gauss(random_radius, random_radius/4) - random_radius
            y = random_center[1] + random.gauss(random_radius, random_radius/4) - random_radius
            z = random_center[2] + random.gauss(random_radius, random_radius/4) - random_radius
        
            enemy_object.position[0] = x
            enemy_object.position[1] = y
            enemy_object.position[2] = z
        
            enemy_object.radius = enemy_radius
        
            enemy_object.speed = enemy_speed
            enemy_object.velocity[0] = enemy_velocity[0]
            enemy_object.velocity[1] = enemy_velocity[1]
            enemy_object.velocity[2] = enemy_velocity[2]
            
            enemy_object_list.append(enemy_object)
            

        if "object_list_out" in self.outputDataModelList:
            print "Object_list_to_object_list: object_list_out is present. write object_list_out file"
            
            object_list_out = self.outputDataModelList.get("object_list_out")
            
            object_list_out_filename = object_list_out.fieldValueList.get("filename")
            
            object_list_out_file = open(object_list_out_filename, 'w')
            
            #TODO: write object list
            object_list_out_file.write("x,y,z,radius,velocity_x,velocity_y,velocity_z,speed,object_type\n")
            
            object_list_out_file.write("%f,%f,%f,%f,%f,%f,%f,%f,source\n" % (source_object.position[0], source_object.position[1], source_object.position[2], source_object.radius, source_object.velocity[0], source_object.velocity[1], source_object.velocity[2], source_object.speed))
            object_list_out_file.write("%f,%f,%f,%f,%f,%f,%f,%f,destination\n" % (destination_object.position[0], destination_object.position[1], destination_object.position[2], destination_object.radius, destination_object.velocity[0], destination_object.velocity[1], destination_object.velocity[2], destination_object.speed))
            
            for i in range(len(enemy_object_list)):
                object_list_out_file.write("%f,%f,%f,%f,%f,%f,%f,%f,enemy\n" % (enemy_object_list[i].position[0], enemy_object_list[i].position[1], enemy_object_list[i].position[2], enemy_object_list[i].radius, enemy_object_list[i].velocity[0], enemy_object_list[i].velocity[1], enemy_object_list[i].velocity[2], enemy_object_list[i].speed))
            object_list_out_file.close()
    
