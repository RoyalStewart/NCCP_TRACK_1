# Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
# obo University of Nevada, Reno
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#  * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

import csv
import os


class Gsod:
  
    def __init__(self):
        self.fieldValueList = {}
               
               
    def init(self):
        self.folder_name = self.fieldValueList["folder_name"]
    
        self.loadIshHistoryLookup()
        
        self.loadDataFormatLookup()
 
        #self.year_from = int(self.fieldValueList["year_from"])
        #self.year_to = int(self.fieldValueList["year_to"])
        
        
    def loadIshHistoryLookup(self):
        ish_history_filename = self.folder_name + "ish-history.csv"

        ish_history_file = open(ish_history_filename, 'rt')
        
        csv_reader = csv.DictReader(ish_history_file)
        
        self.ishHistoryLookup = {}
        
        row_count = 0
        
        for row in csv_reader:
            if row.get("LAT") != '' and row.get("LON") != '':
                latitude = int(row.get("LAT"))
                longitude = int(row.get("LON"))
                
                #if -180000 <= longitude <= 180000 and -90000 <= latitude <= 90000:
                sample_range_divider = 1
                if -180000/sample_range_divider <= longitude <= 180000/sample_range_divider and -90000/sample_range_divider <= latitude <= 90000/sample_range_divider:
                    station_id = "%s-%s" % (row.get("USAF"), row.get("WBAN"))
                    self.ishHistoryLookup[station_id] = { "STATION NAME" : row.get("STATION NAME"), 
                                                          "LAT" : latitude, 
                                                          "LON" : longitude }
            
            row_count = row_count + 1
            
        ish_history_file.close()
        
        print "Gsod: ish-history.csv row_count = %d" % row_count
        
        print "Gsod: len(self.ishHistoryLookup) = %d" % len(self.ishHistoryLookup)

        #for station, location in self.ishHistoryLookup.items():
        #   print "%s: %s" % (station, location)


    def loadDataFormatLookup(self):        
        data_format_filename = self.folder_name + "data_format.csv"

        data_format_file = open(data_format_filename, 'rt')
        
        csv_reader = csv.DictReader(data_format_file)
        
        self.dataFormatLookup = {}
        
        for row in csv_reader:
            self.dataFormatLookup[row.get("FIELD")] = row
            
        data_format_file.close()
        
        print "Gsod: len(self.dataFormatLookup) = %d" % len(self.dataFormatLookup)

