# Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
# obo University of Nevada, Reno
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#  * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

import Image as PIL_Image
import csv
import os
import shutil
from collections import defaultdict
import datetime


class Gsod_csv_to_prismvis_graph:

    def __init__(self):
        self.fieldValueList = {}
        self.inputDataModelList = {}
        self.outputDataModelList = {}
    
    
    def run(self):
        gsod_in = self.inputDataModelList["gsod_in"]
        gsod_csv_in = self.inputDataModelList["gsod_csv_in"]
       
        gsod_csv_in_filename = gsod_csv_in.fieldValueList["filename"]

        #max_latitude = max([location.get("LAT") for station_id, location in gsod_in.ishHistoryLookup.items()])
        #min_latitude = min([location.get("LAT") for station_id, location in gsod_in.ishHistoryLookup.items()])

        #print "max_latitude = " + str(max_latitude)
        #print "min_latitude = " + str(min_latitude)
        
        #max_longitude = max([location.get("LON") for station_id, location in gsod_in.ishHistoryLookup.items()])
        #min_longitude = min([location.get("LON") for station_id, location in gsod_in.ishHistoryLookup.items()])

        #print "max_longitude = " + str(max_longitude)
        #print "min_longitude = " + str(min_longitude)
        
        #diff_latitude = float(max_latitude - min_latitude)
        #diff_longitude = float(max_longitude - min_longitude)

        #print "diff_latitude = " + str(diff_latitude)
        #print "diff_longitude = " + str(diff_longitude)

        element_type = self.fieldValueList["element_type"]

        gsod_csv_in_file = open(gsod_csv_in_filename, 'rt')
        
        csv_reader = csv.DictReader(gsod_csv_in_file)
        
        element_lookup = defaultdict(lambda : defaultdict(float))
        
        min_date = "99999999"
        max_date = "00000000"
        
        for row in csv_reader:
            station_id = "%s-%s" % (row.get("STN---"), row.get("WBAN"))
            
            #initialize station data lookup
            #if station_id not in data_lookup:
            #    data_lookup[station_id] = {[]}
               
            #year, month, date
            date = "%s%s" % (row.get("YEAR"), row.get("MODA"))
            
            element = float(row.get(element_type))
            if element == 99.99:
                element = 0.0
                
            element_lookup[station_id][date] = element
            
            if date < min_date:
                min_date = date
                
            if date > max_date:
                max_date = date
                
            #print "station_id: %s, date: %s, element: %f" % (station_id, date, element)
        
        min_date = datetime.date(int(min_date[0:4]), int(min_date[4:6]), int(min_date[6:8]))
        max_date = datetime.date(int(max_date[0:4]), int(max_date[4:6]), int(max_date[6:8]))
        
        print "min_date: %s, max_date: %s" % (min_date.strftime("%Y%m%d"), max_date.strftime("%Y%m%d"))    
    
        
        snapshot_element_lookup = defaultdict(lambda : defaultdict(float))
        
        day_increment = int(self.fieldValueList["day_increment"])
        
        snapshot_date_list = []
        for day_count in range(day_increment-1, (max_date - min_date).days, day_increment):
          snapshot_date = min_date + datetime.timedelta(days=day_count)
          
          snapshot_date_list.append(snapshot_date.strftime("%Y%m%d"))
            
        print "snapshot_date_list"
        print snapshot_date_list
        
        max_snapshot_element = 0.0
        
        for station_id, element_data_lookup in element_lookup.items():
            #print "station_id: %s, data_count: %d" % (station_id, len(element_data_lookup))
    
            day_counter = 1
            snapshot_element = 0.0
            
            #for date in range(min_date, max_date+1):
            for day_count in range((max_date - min_date).days):
                date = min_date + datetime.timedelta(days=day_count)
                date_string = date.strftime("%Y%m%d")
                  
                snapshot_element += element_data_lookup.get(date_string, 0.0)

                #if day_counter % day_increment == 0:
                if date_string in snapshot_date_list:
                    #print "date: %s, snapshot_element: %f" % (date_string, snapshot_element)
                    
                    snapshot_element_lookup[station_id][date_string] = snapshot_element
                    
                    max_snapshot_element = max(max_snapshot_element, snapshot_element)
                    
                    snapshot_element = 0.0
                    
                #day_counter += 1

        print "max_snapshot_element: %f" % (max_snapshot_element)


        if "prismvis_out" in self.outputDataModelList:
            print "Gsod_to_prismvis: prismvis_out is present. write prismvis file of stations' locations"
            
            prismvis_out = self.outputDataModelList.get("prismvis_out")
            
            prismvis_filename = prismvis_out.fieldValueList.get("filename")
                
            prismvis_file = open(prismvis_filename, 'w')
            
            prismvis_file.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            prismvis_file.write('<scenario>\n')
            prismvis_file.write('<scene>defaultscene</scene>\n')
            
            for snapshot_date in snapshot_date_list:
              
                for station_id, snapshot_element_data_lookup in snapshot_element_lookup.items():
                    location = gsod_in.ishHistoryLookup.get(station_id)
                    
                    #print location
                    
                    snapshot_year = int(snapshot_date[0:4])
                    
                    date = datetime.date(int(snapshot_date[0:4]), int(snapshot_date[4:6]), int(snapshot_date[6:8]))
                    days_of_year = (date - datetime.date(snapshot_year, 1, 1)).days
                      
                    height = snapshot_element_data_lookup[snapshot_date]
                    
                    vis_x = days_of_year
                    vis_z = snapshot_year - max_date.year
                    
                    translation = "%d:%f:%d" % (vis_x, height/2.0, vis_z)
                    scale = "%f:%f:%f" % (1.0, height, 1.0)
                    
                    prismvis_file.write('<object object_type="box" object_id="%s-%s">\n' % (station_id, snapshot_date))
                    prismvis_file.write('<name>%s-%s</name>\n' % (station_id, snapshot_date))
                    prismvis_file.write('<translation>%s</translation>\n' % translation)
                    prismvis_file.write('<scale>%s</scale>\n' % scale)
                    prismvis_file.write('<height>%f</height>\n' % height)
                    prismvis_file.write('</object>\n')
    
            prismvis_file.write('</scenario>\n')
            
            prismvis_file.close()
            
