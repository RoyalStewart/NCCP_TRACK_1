# Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
# obo University of Nevada, Reno
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#  * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

import os
import csv
import shutil
from collections import defaultdict


class MovingObject:

    def __init__(self):
        self.position = [0.0, 0.0, 0.0]
        self.radius = 1.0
        self.velocity = [0.0, 0.0, 0.0]
        self.speed = 0.0
        
        
class A_star_path_to_prismvis:

    def __init__(self):
        self.fieldValueList = {}
        self.inputDataModelList = {}
        self.outputDataModelList = {}
    
    
    def run(self):
        object_list_in = self.inputDataModelList["object_list_in"]
        a_star_path_in = self.inputDataModelList["a_star_path_in"]
       
        object_list_in_filename = object_list_in.fieldValueList["filename"]
        a_star_path_in_filename = a_star_path_in.fieldValueList["filename"]

        object_list_in_file = open(object_list_in_filename, 'rt')
        
        csv_reader = csv.DictReader(object_list_in_file)
        
        source_object = MovingObject()
        destination = MovingObject()
        enemy_object_list = []
        
        for row in csv_reader:             
            x = float(row.get("x"))
            y = float(row.get("y"))
            z = float(row.get("z"))
            radius = float(row.get("radius"))
            #speed = float(row.get("speed"))             
            velocity_x = float(row.get("velocity_x"))
            velocity_y = float(row.get("velocity_y"))
            velocity_z = float(row.get("velocity_z"))
            object_type = row.get("object_type")
            print "x = %f, y = %f, z = %f, radius = %f, object_type = %s" % (x, y, z, radius, object_type)
            #print "x = %f, y = %f, radius = %f, speed = %f, object_type = %s" % (x, y, radius, speed, object_type)
            
            if object_type == "source":
                source_object.position = [x, y, z]
                source_object.radius = radius
                source_object.velocity = [velocity_x, velocity_y, velocity_z]
                
            if object_type == "destination":
                destination.position = [x, y, z]
                destination.velocity = [velocity_x, velocity_y, velocity_z]
                
            if object_type == "enemy":
                enemy_object = MovingObject()
                enemy_object.position = [x, y, z]
                enemy_object.radius = radius
                enemy_object.velocity = [velocity_x, velocity_y, velocity_z]
                
                enemy_object_list.append(enemy_object)

        object_list_in_file.close()

        print "\nsource_object"
        print "position = [%f, %f, %f], radius = %f" % (source_object.position[0], source_object.position[1], source_object.position[2], source_object.radius)
        #print "position = [%f, %f], radius = %f, speed = %f" % (source_object.position[0], source_object.position[1], source_object.speed, source_object.radius)
        
        print "\ndestination"
        print "position = [%f, %f, %f]" % (destination.position[0], destination.position[1], destination.position[2])
        
        print "\nenemy_object_list"
        for enemy_object in enemy_object_list:
            print "position = [%f, %f, %f], radius = %f" % (enemy_object.position[0], enemy_object.position[1], enemy_object.position[2], enemy_object.radius)
            #print "position = [%f, %f], radius = %f, speed = %f" % (enemy_object.position[0], enemy_object.position[1], enemy_object.speed, enemy_object.radius)
            
        self.source_object = source_object
        self.destination = destination
        self.enemy_object_list = enemy_object_list
        
        
        a_star_path_in_file = open(a_star_path_in_filename, 'rt')
        
        csv_reader = csv.DictReader(a_star_path_in_file)
        
        a_star_path = []
        
        for row in csv_reader:            
            x = float(row.get("x"))
            y = float(row.get("y"))
            z = float(row.get("z"))
            print "x = %f, y = %f, z = %f" % (x, y, z)
                
            a_star_path.append([x, y, z])

        a_star_path_in_file.close()

        print "\na_star_path"
        print a_star_path


        if "prismvis_out" in self.outputDataModelList:
            print "A_star_path_to_prismvis: prismvis_out is present. write prismvis file"
            
            prismvis_out = self.outputDataModelList.get("prismvis_out")

            prismvis_out_filename = prismvis_out.fieldValueList.get("filename")
        
            prismvis_out_file = open(prismvis_out_filename, 'w')
            
            prismvis_out_file.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            prismvis_out_file.write("<scenario>\n")
            prismvis_out_file.write('<scene>objectscene</scene>\n')
    
            prismvis_out_file.write('<object object_type="object" object_id="source_object">\n')
            prismvis_out_file.write('<name>source_object</name>\n')
            prismvis_out_file.write('<translation>%f:%f:%f</translation>\n' % (self.source_object.position[0], self.source_object.position[1], self.source_object.position[2]))
            prismvis_out_file.write('<radius>%f</radius>\n' % self.source_object.radius)
            #prismvis_out_file.write('<speed>%f</speed>\n' % self.source_object.speed)
            prismvis_out_file.write('<speed>%f</speed>\n' % 10.0)
            prismvis_out_file.write('<velocity>%f:%f:%f</velocity>\n' % (self.source_object.velocity[0], self.source_object.velocity[1], self.source_object.velocity[2]))
                                              
            point_string_list = []
            for point in a_star_path:
                point_string_list.append('%f:%f:%f' % (point[0], point[1], point[2]))
                
            prismvis_out_file.write('<a_star_path>%s</a_star_path>\n' % ','.join(point_string_list))
            
            prismvis_out_file.write('</object>\n')
            
            for i in range(len(enemy_object_list)):
                prismvis_out_file.write('<object object_type="object" object_id="enemy_object_%d">\n' % (i+1))
                prismvis_out_file.write('<name>enemy_object_%d</name>\n' % (i+1))
                prismvis_out_file.write('<translation>%f:%f:%f</translation>\n' % (enemy_object_list[i].position[0], enemy_object_list[i].position[1], enemy_object_list[i].position[2]))
                prismvis_out_file.write('<radius>%f</radius>\n' % enemy_object_list[i].radius)
                prismvis_out_file.write('<velocity>%f:%f:%f</velocity>\n' % (enemy_object_list[i].velocity[0], enemy_object_list[i].velocity[1], enemy_object_list[i].velocity[2]))
                prismvis_out_file.write('</object>\n')
                
            prismvis_out_file.write('<object object_type="object" object_id="destination">\n')
            prismvis_out_file.write('<name>destination</name>\n')
            prismvis_out_file.write('<translation>%f:%f:%f</translation>\n' % (self.destination.position[0], self.destination.position[1], self.destination.position[1]))
            prismvis_out_file.write('<radius>%f</radius>\n' % self.destination.radius)
            prismvis_out_file.write('<velocity>%f:%f:%f</velocity>\n' % (self.destination.velocity[0], self.destination.velocity[1], self.destination.velocity[2]))
            prismvis_out_file.write('</object>\n')
            
            prismvis_out_file.write('</scenario>\n')
            prismvis_out_file.close()  
        
