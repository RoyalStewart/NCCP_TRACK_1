# Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
# obo University of Nevada, Reno
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#  * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

import os
import csv
import shutil
from collections import defaultdict
import math


class MovingObject:

    def __init__(self):
        self.position = [0.0, 0.0, 0.0]
        self.radius = 10.0
        self.velocity = [0.0, 0.0, 0.0]
        self.speed = 0.0
        
        
class Object_list_to_a_star_path:

    def __init__(self):
        self.fieldValueList = {}
        self.inputDataModelList = {}
        self.outputDataModelList = {}
    
    
    def run(self):
        object_list_in = self.inputDataModelList["object_list_in"]
      
        object_list_in_filename = object_list_in.fieldValueList["filename"]
        
        object_list_in_file = open(object_list_in_filename, 'rt')
        
        csv_reader = csv.DictReader(object_list_in_file)
        
        source_object = MovingObject()
        destination = MovingObject()
        enemy_object_list = []
        
        for row in csv_reader:             
            x = float(row.get("x"))
            y = float(row.get("y"))
            z = float(row.get("z"))
            radius = float(row.get("radius"))    
            velocity_x = float(row.get("velocity_x"))
            velocity_y = float(row.get("velocity_y"))
            velocity_z = float(row.get("velocity_z"))
            object_type = row.get("object_type")
            print "x = %f, y = %f, z = %f, radius = %f, object_type = %s" % (x, y, z, radius, object_type)
            
            if object_type == "source":
                source_object.position = [x, y, z]
                source_object.radius = radius
                source_object.velocity = [velocity_x, velocity_y, velocity_z]
                source_object.speed = 10.0;
                
            if object_type == "destination":
                destination.position = [x, y, z]
                destination.velocity = [velocity_x, velocity_y, velocity_z]
                
            if object_type == "enemy":
                enemy_object = MovingObject()
                enemy_object.position = [x, y, z]
                enemy_object.radius = radius
                enemy_object.velocity = [velocity_x, velocity_y, velocity_z]
                
                enemy_object_list.append(enemy_object)

        object_list_in_file.close()

        print "\nsource_object"
        print "position = [%f, %f, %f], radius = %f" % (source_object.position[0], source_object.position[1], source_object.position[2], source_object.radius)
            
        print "\ndestination"
        print "position = [%f, %f, %f]" % (destination.position[0], destination.position[1], destination.position[2])
        
        print "\nenemy_object_list"
        for enemy_object in enemy_object_list:
            print "position = [%f, %f, %f], radius = %f" % (enemy_object.position[0], enemy_object.position[1], enemy_object.position[2], enemy_object.radius)
        
        self.source_object = source_object
        self.destination = destination
        self.enemy_object_list = enemy_object_list
        self.a_star_path = []
        
        self.solve_a_star()
        
        print "\nself.a_star_path"
        print self.a_star_path
        
        if "a_star_path_out" in self.outputDataModelList:
            print "Object_list_to_a_star_path: a_star_path_out is present. write a_star_path_out file"
            
            a_star_path_out = self.outputDataModelList.get("a_star_path_out")
            
            a_star_path_out_filename = a_star_path_out.fieldValueList.get("filename")
            
            a_star_path_out_file = open(a_star_path_out_filename, 'w')
            
            a_star_path_out_file.write("x,y,z\n")
            
            for i in range(len(self.a_star_path)):
                a_star_path_out_file.write("%f,%f,%f\n" % (self.a_star_path[i][0], self.a_star_path[i][1], self.a_star_path[i][2]))
                
            a_star_path_out_file.close()
    
        
    def solve_a_star(self):
        print "\nsolve_a_star()"
        
        print "\nself.source_obejct.position = [%f, %f, %f]" % (self.source_object.position[0], self.source_object.position[1], self.source_object.position[2])
        
        candidate_point_list = []

        #slice on y-axis first, then for each slice, slice on x-axis.
        num_y_axis_slice = 1
        num_x_axis_slice = 1
        
        # 0 0 -> 4 points (default polar points)
        # x y -> 4 + x*y*2 (# intersection)
        # 1 1 -> 4 + 1*1*2 = 6 points
        # 1 2 -> 4 + 1*2*2 = 8 points
        # 1 3 -> 4 + 1*3*2 = 10 points
        # 2 1 -> 4 + 2*1*2 = 8 points
        # 2 2 -> 4 + 2*2*2 = 12 points
        # 2 3 -> 4 + 2*3*2 = 16 points
        
        for enemy_object in self.enemy_object_list:
            print enemy_object.position
            
            center = enemy_object.position
            
            #TODO: need to compute minimum radius
            radius = enemy_object.radius + self.source_object.radius * 2

            velocity = enemy_object.velocity

            # append poler points on x-axis and y-axis
            candidate_point_list.append([center[0] + radius, center[1], center[2]], velocity[0], velocity[1], velocity[2])
            candidate_point_list.append([center[0] - radius, center[1], center[2]], velocity[0], velocity[1], velocity[2])
            candidate_point_list.append([center[0], center[1] + radius, center[2]], velocity[0], velocity[1], velocity[2])
            candidate_point_list.append([center[0], center[1] - radius, center[2]], velocity[0], velocity[1], velocity[2])

            for i in range(1, num_x_axis_slice+1):
                x = radius*2 / (num_x_axis_slice+1) * i - radius
                
                for j in range(1, num_y_axis_slice+1):
                    y = radius*2 / (num_y_axis_slice+1) * i - radius
                    
                    # sphere:
                    #   x^2 + y^2 + z^2 = r^2
                    #   z^2 = r^2 - x^2 - y^2
                    #   z = +/- sqrt(r^2 - x^2 - y^2)
                    
                    z = math.sqrt(radius*radius - x*x - y*y)
                    
                    # append front and back
                    candidate_point_list.append([center[0] + x, center[1] + y, center[2] + z, velocity[0], velocity[1], velocity[2]])
                    candidate_point_list.append([center[0] + x, center[1] + y, center[2] - z, velocity[0], velocity[1], velocity[2]])
                
        print candidate_point_list
        
        vertex_list = [[self.source_object.position[0], self.source_object.position[1], self.source_object.position[2], self.source_object.velocity[0], self.source_object.velocity[1], self.source_object.velocity[2]]]
        vertex_list.extend(candidate_point_list)
        vertex_list.append([self.destination.position[0], self.destination.position[1], self.destination.position[2], self.destination.velocity[0], self.destination.velocity[1], self.destination.velocity[2]])
        
        num_vertex = len(vertex_list)
        distance_list = [float("inf")] * num_vertex
        previous_node = [-1] * num_vertex

        distance_list[0] = 0.0
        
        vertex_queue = range(num_vertex)
        vertex_removed = []
        
        while len(vertex_queue) > 0:
            print "\nlen(vertex_queue) = %d" % len(vertex_queue)
            #print "vertex_queue"
            #print vertex_queue
        
            minimum = float("inf")
            index_minimum = -1
            for i in range(len(vertex_queue)):
                distance = distance_list[vertex_queue[i]]
                
                if distance < minimum:
                    minimum = distance
                    index_minimum = i
                
            if index_minimum < 0:
                break
                
            print "index_minimum = %d" % index_minimum
            
            index_u = vertex_queue[index_minimum]
            vertex_queue.remove(index_u)
            vertex_removed.append(index_u)
            
            u = vertex_list[index_u]
            
            print "index_u = %d" % index_u
            #print "u = [%f, %f, %f]" % (u[0], u[1], u[2])
            #print "distance = %f" % distance_list[index_u] 
            #print "previous = %d" % previous_node[index_u] 
            
            #find_neighbor
            neighbor_candidate_list = []
            neighbor_distance_list = []
            for i in range(num_vertex):
                if i not in vertex_removed:
                    v = vertex_list[i]
                  
                    #print "\nv = [%f, %f, %f]" % (v[0], v[1], v[2])
                    
                    # compute time to reach the point
                    # v' = v + d * T
                    #
                    # break down to component
                    # v'x = vx + dx * T
                    # v'y = vy + dy * T
                    # v'z = vz + dz * T
                    #
                    # S * T = |v'|
                    # S * T = sqrt(v'x^2 + v'y^2 + v'z^2)
                    # (S * T)^2 = v'x^2 + v'y^2 + v'z^2
                    # (S * T)^2 = (vx + dx * T)^2 + (vy + dy * T)^2 + (vz + dz * T)^2
                    # S^2 * T^2 = (vx^2 + 2 * vx * dx * T + dx^2 * T^2) + (vy^2 + 2 * vy * dy * T + dy^2 * T^2) + (vz^2 + 2 * vz * dz * T + dz^2 * T^2)
                    # vx^2 + 2 * vx * dx * T + dx^2 * T^2 + vy^2 + 2 * vy * dy * T + dy^2 * T^2 + vz^2 + 2 * vz * dz * T + dz^2 * T^2 - S^2 * T^2 = 0
                    # (dx^2 + dy^2 + dz^2 - S^2) * T^2 + (2 * vx * dx + 2 * vy * dy + 2 * vz * dz) * T + (vx^2 + vy^2 + vz^2) = 0
                    # a = (dx^2 + dy^2 + dz^2 - S^2)
                    # b = (2 * vx * dx + 2 * vy * dy + 2 * vz * dz)
                    # c = (vx^2 + vy^2 + vz^2)
                    # T = (-b +/- sqrt(b^2 - 4 * a * c)) / 2 * a
                    
                    S = self.source_object.speed
                    a = (v[3]*v[3] + v[4]*v[4] + v[5]*v[5] - S*S)
                    b = (2 * v[0] * v[3] + 2 * v[1] * v[4] + 2 * v[2] * v[5])
                    c = (v[0]*v[0] + v[1]*v[1] + v[2]*v[2])
                    
                    sqrt_part = math.sqrt(b*b - 4 * a * c) 
                    T = (-b + sqrt_part) / 2 * a
                    if T < 0:
                        T = (-b - sqrt_part) / 2 * a
                    
                    
                    # TODO:
                    # T is from point u to v
                    # Need to find T from the beginning, adding all duration throughout traversal
                    
                    
                    if T > 0:
                        v = [v[0] + v[3] * T, v[1] + v[4] * T, v[2] + v[5] * T]
                        
                        distance = math.sqrt(pow(u[0] - v[0], 2) + pow(u[1] - v[1], 2) + pow(u[2] - v[2], 2))
                        
                        #print "distance = %f" % distance
                        
                        if distance > 0:
                            intersect = False
                            
                            #need to check travelability
                            #not travelable if the line intersect with any circle
                            for enemy_object in self.enemy_object_list:
                                
                                center = enemy_object.position
                                #radius = enemy_object.radius 
                                radius = enemy_object.radius + self.source_object.radius
                                
                                #print "enemy_center = [%f, %f, %f]" % (center[0], center[1], center[2])
        
                                # |x - c|^2 = r^2
                                # c - center point
                                # r - radius
                                # x - points on the sphere
    
                                # x = o + dl
                                # d - distance along line from starting point
                                # l - direction of line (a unit vector)
                                # o - origin of the line
                                # x - points on the line
                                
                                # d = (l dot (o - c)) +/- sqrt((l dot (o - c))^2 - (o - c) dot (o - c) + r^2)
                                # if value under sqrt < 0, no solution exists
                                # if value under sqrt == 0, line touches (one point)
                                # if value under sqrt > 0, line intersects (two points)
                                
                                # d = (l dot (-c)) +/- sqrt((l dot (-c))^2 - c dot c + radius^2)
    
                                p1 = [center[0], center[1], center[2]]
                                p2 = [u[0], u[1], u[2]]
                                p3 = [v[0], v[1], v[2]]
                            
                                line = [v[0]-u[0], v[1]-u[1], v[2]-u[2]]
                                line_length = math.sqrt(line[0]*line[0] + line[1]*line[1] + line[2]*line[2])
                                
                                l = [line[0]/line_length, line[1]/line_length, line[2]/line_length]
                                c = [center[0]-u[0], center[1]-u[1], center[2]-u[2]]
                                
                                l_dot_minus_c = l[0]*(-c[0]) + l[1]*(-c[1]) + l[2]*(-c[2])
                                under_sqrt = l_dot_minus_c*l_dot_minus_c - (c[0]*c[0] + c[1]*c[1] + c[2]*c[2]) + radius*radius
                               
                                #print "under_sqrt = %f" % (under_sqrt)
                               
                                if under_sqrt >= 0:
                                    d1 = l_dot_minus_c + math.sqrt(under_sqrt)
                                    d2 = l_dot_minus_c - math.sqrt(under_sqrt)
                                    
                                    #print "line circle intersect: d1 = %f, d2 = %f" % (d1, d2)
                                    
                                    if line_length >= d1 or line_length >= d2:
                                        intersect = True
                                          
                            if intersect == False:
                                #print "neighbor_candidate_list.append(%d)" % (i)
                                
                                neighbor_candidate_list.append(i)
                                neighbor_distance_list.append(distance)
                
            #print "\nneighbor_candidate_list"
            #print neighbor_candidate_list
            #print "\nneighbor_distance_list"
            #print neighbor_distance_list
            
            
            num_neighbor_candidate = len(neighbor_candidate_list)
          
            for i in range(num_neighbor_candidate):
                index_v = neighbor_candidate_list[i]
                new_distance = distance_list[index_u] + neighbor_distance_list[i]
                
                #print "new_distance = %f" % new_distance
                
                if new_distance < distance_list[index_v]:
                    #print "new_distance = %f" % new_distance
                    
                    distance_list[index_v] = new_distance
                    previous_node[index_v] = index_u
                    
                #vertex_queue.append(index_v)
            
            
        print "\nprevious_node"
        print previous_node
        
        self.a_star_path = []
        
        path_index = len(previous_node) - 1
        
        while path_index >= 0:
            self.a_star_path.append(vertex_list[path_index])
      
            print "path_index = %d, point = [%f, %f, %f]" % (path_index, vertex_list[path_index][0], vertex_list[path_index][1], vertex_list[path_index][2])
            
            path_index = previous_node[path_index]
        
        self.a_star_path.reverse()
        
        print "\nself.a_star_path"
        print self.a_star_path
        
