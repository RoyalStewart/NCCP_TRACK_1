# Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
# obo University of Nevada, Reno
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#  * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

import suds
from xml.dom import minidom, Node

import Image as PIL_Image
import os
import shutil
from collections import defaultdict
import datetime


class Ndfd_to_prismvis:

    def __init__(self):
        self.fieldValueList = {}
        self.inputDataModelList = {}
        self.outputDataModelList = {}
    
    
    def run(self):
        web_service_in = self.inputDataModelList["web_service_in"]

        url = web_service_in.fieldValueList["url"]
        
        client = suds.client.Client(url, faults=False, timeout=500)
        print client
        
        # US corner points
        # returns list_lat_lon for lower_left lower_right upper_right, upper_left
        result = client.service.CornerPoints("conus")
        
        list_lat_lon_start = result[1].find("<latLonList>") + len("<latLonList>")
        list_lat_lon_end = result[1].find("</latLonList>")
        list_lat_lon_string = result[1][list_lat_lon_start:list_lat_lon_end]
        
        #print list_lat_lon_string
        
        # separate lat_lon list
        list_lat_lon = list_lat_lon_string.split(' ')
        
        # separate latitude longitude pair
        lat_lon_list = list_lat_lon[0].split(',')
            
        latitude = float(lat_lon_list[0])
        longitude = float(lat_lon_list[1])
        
        lower_left_latitude = latitude
        lower_left_longitude = longitude
        upper_right_latitude = latitude
        upper_right_longitude = longitude
        
        for lat_lon in list_lat_lon:
            lat_lon_list = lat_lon.split(',')
            
            latitude = float(lat_lon_list[0])
            longitude = float(lat_lon_list[1])
            
            lower_left_latitude = min(lower_left_latitude, latitude)
            lower_left_longitude = min(lower_left_longitude, longitude)
            upper_right_latitude = max(upper_right_latitude, latitude)
            upper_right_longitude = max(upper_right_longitude, longitude)
        
        print "lower_left_latitude   : %f" % lower_left_latitude
        print "lower_left_longitude  : %f" % lower_left_longitude 
        print "upper_right_latitude  : %f" % upper_right_latitude 
        print "upper_right_longitude : %f" % upper_right_longitude   

        resolution = 100
        
        result = client.service.LatLonListSubgrid(lower_left_latitude, lower_left_longitude, upper_right_latitude, upper_right_longitude, resolution)
        
        print result
        
        list_lat_lon_start = result[1].find("<latLonList>") + len("<latLonList>")
        list_lat_lon_end = result[1].find("</latLonList>")
        list_lat_lon_string = result[1][list_lat_lon_start:list_lat_lon_end]
        
        print list_lat_lon_string
        
        list_lat_lon = list_lat_lon_string.split(' ')
        print "len(list_lat_lon): %d" % len(list_lat_lon)
        
        # NDFD web service restriction
        max_num_lat_lon = 200
        
        len_list_lat_lon = len(list_lat_lon)
        num_request = (len_list_lat_lon / max_num_lat_lon) + 1
        
        print "num_request: %d" % num_request
        
        location_lookup = defaultdict(dict)

        location_value_lookup = defaultdict(dict)

        num_trial = 3
        trial_count = 0
        
        request_num = 0
        
        while request_num < num_request:
            list_lat_lon_start = request_num*max_num_lat_lon
            list_lat_lon_end = min((request_num+1)*max_num_lat_lon, len_list_lat_lon)
            
            sublist_lat_lon_string = " ".join(list_lat_lon[list_lat_lon_start:list_lat_lon_end])
        
            print "list_lat_lon_start: %d" % list_lat_lon_start
            print "list_lat_lon_end: %d" % list_lat_lon_end
            #print "sublist_lat_lon_string: %s" % sublist_lat_lon_string
        
        
            #list_lat_lon = self.fieldValueList["list_lat_lon"]
            product = self.fieldValueList["product"]
            start_time = self.fieldValueList["start_time"]
            end_time = self.fieldValueList["end_time"]
            parameter_type = self.fieldValueList["parameter_type"]
            
            weather_parameters_type = client.factory.create('ns0:weatherParametersType')
            weather_parameters_type[parameter_type] = True
            
            result = client.service.NDFDgenLatLonList(sublist_lat_lon_string, product, start_time, end_time, "e", weather_parameters_type)
            
            if result[0] == 200:
                # reset trial count
                trial_count = 0
                
                xmldoc = minidom.parseString(result[1])
                
                #print xmldoc.toxml()
                
                data_node = xmldoc.getElementsByTagName("data")[0]
                
                #print data_node.toxml()
                
                #location_lookup = defaultdict(dict)
                
                for location_node in data_node.getElementsByTagName("location"):
                    location_key = location_node.getElementsByTagName("location-key")[0].firstChild.data
                    location_key = "request-%d.%s" % (request_num, location_key)
    
                    point = location_node.getElementsByTagName("point")[0]
                    latitude = float(point.attributes['latitude'].value)
                    longitude = float(point.attributes['longitude'].value)
                    
                    #print "location: %s, (%s, %s)" % (location_key, latitude, longitude)
                    
                    location_lookup[location_key] = { "location_key" : location_key, 
                                                      "latitude" : latitude, 
                                                      "longitude" : longitude }
        
                
                #location_value_lookup = defaultdict(dict)
                
                for parameter_node in data_node.getElementsByTagName("parameters"):
                    location_key = parameter_node.attributes['applicable-location'].value
                    location_key = "request-%d.%s" % (request_num, location_key)
                    
                    #print "for location: %s" % (location_key)
                    
                    node = parameter_node.firstChild
                    while node != None:
                      if node.nodeType == Node.ELEMENT_NODE:
                          parameter_type = node.nodeName
                          parameter_name = node.getElementsByTagName("name")[0].firstChild.data
                          
                          parameter_value = 0
                          value_node = node.getElementsByTagName("value")[0].firstChild
                          if value_node != None:
                            parameter_value = value_node.data
                          
                          #print "%s (%s): %s" % (parameter_type, parameter_name, parameter_value)
                          
                          # TODO: assuming only main parameter type with one date
                          # Need to extend for parameter sub-types and for a range of dates
                          location_value_lookup[location_key] = { "date" : start_time,
                                                                  parameter_type : parameter_value }
                          
                      node = node.nextSibling
                  
                request_num += 1
                
            elif trial_count < num_trial:
                # try again if trial count less than num trial 
                print result
                print "trial_count: %d" % trial_count
                
                trial_count += 1
            
            else:
                # trial count exceed num trial. ignore and proceed to next set
                # reset trial count
                trial_count = 0
                request_num += 1
                
                
        #print location_value_lookup
          
        #max_latitude = max([location.get("LAT") for station_id, location in gsod_in.ishHistoryLookup.items()])
        #min_latitude = min([location.get("LAT") for station_id, location in gsod_in.ishHistoryLookup.items()])

        #print "max_latitude = " + str(max_latitude)
        #print "min_latitude = " + str(min_latitude)
        
        #max_longitude = max([location.get("LON") for station_id, location in gsod_in.ishHistoryLookup.items()])
        #min_longitude = min([location.get("LON") for station_id, location in gsod_in.ishHistoryLookup.items()])

        #print "max_longitude = " + str(max_longitude)
        #print "min_longitude = " + str(min_longitude)
        
        #diff_latitude = float(max_latitude - min_latitude)
        #diff_longitude = float(max_longitude - min_longitude)

        #print "diff_latitude = " + str(diff_latitude)
        #print "diff_longitude = " + str(diff_longitude)

        create_station_map = 1
        if create_station_map:
            filename = "station_map.png"
            
            #image_width = 1000
            #image_height = 500
            
            #image = PIL_Image.new ("RGB", (image_width, image_height))
            
            image = PIL_Image.open("world_map_resized.png")
            (image_width, image_height) = image.size
            
            pixel = image.load()
            
            for location_key, location in location_lookup.items():
                #print location.get("LON"), location.get("LAT")
                
                #x = int((location.get("LON") - min_longitude) / diff_longitude * (image_width-1)) 
                #y = int((location.get("LAT") - min_latitude) / diff_latitude * (image_height-1)) 
                
                # adjust range to be positive, also to match with existing map
                longitude = location.get("longitude") + 180.0 - 10.0
                if longitude < 0:
                    360 - longitude
                
                # adjust range to be positive, also to match with existing map
                latitude = location.get("latitude") + 90.0 + 0.5
                if latitude < 0:
                    180 - latitude
                    
                x = int(longitude / 360.0 * (image_width-1))
                y = image_height - int(latitude / 180.0 * (image_height-1))
                
                #print x, y
                
                #if 0 <= x and x < image_width and 0 <= y and y < image_height:
                if 0 <= x < image_width and 0 <= y < image_height:
                    pixel[x, y] = (255, 0, 0)
                
            image.save(filename)
        
        
        location_date_value_lookup = defaultdict(lambda : defaultdict(float))
        
        #min_date = "99999999"
        #max_date = "00000000"
        
        parameter_type = "temperature"
        
        for location_key, value_lookup in location_value_lookup.items():
            
            #year, month, date
            date = value_lookup.get("date")
            
            parameter_value = float(value_lookup.get(parameter_type))
                
            location_date_value_lookup[location_key][date] = parameter_value
            
            #if date < min_date:
            #    min_date = date
            #    
            #if date > max_date:
            #    max_date = date
                
            #print "station_id: %s, date: %s, precipitation: %f" % (station_id, date, precipitation)
        
        #min_date = datetime.date(int(min_date[0:4]), int(min_date[4:6]), int(min_date[6:8]))
        #max_date = datetime.date(int(max_date[0:4]), int(max_date[4:6]), int(max_date[6:8]))
        
        #print "min_date: %s, max_date: %s" % (min_date.strftime("%Y%m%d"), max_date.strftime("%Y%m%d"))    
    
    
        snapshot_date_list = [start_time]
        
        print "snapshot_date_list"
        print snapshot_date_list
        

        max_snapshot_value = 0.0
        
        for location_key, date_value_lookup in location_date_value_lookup.items():
          
            for snapshot_date in snapshot_date_list:
                snapshot_value = date_value_lookup[snapshot_date]
                max_snapshot_value = max(max_snapshot_value, snapshot_value)

        print "max_snapshot_value: %f" % (max_snapshot_value)
        

        if "image_out" in self.outputDataModelList:
            print "Ndfd_to_prismvis: image_out is present. write image file of locations"
            
            image_out = self.outputDataModelList.get("image_out")
            
            filename = image_out.fieldValueList.get("filename")
                
            #image_width = 1000
            #image_height = 500
            
            #image = PIL_Image.new ("RGB", (image_width, image_height))            
            
            image = PIL_Image.open("world_map_resized.png")
            (image_width, image_height) = image.size
            
            pixel = image.load()
            
            for snapshot_date in snapshot_date_list:
                extension_index = filename.rindex(".")
                
                snapshot_filename = "%s.%s.%s" % (filename[:extension_index], snapshot_date, filename[extension_index+1:])
                
                print snapshot_filename
                
                image = PIL_Image.open("world_map_resized.png")
                (image_width, image_height) = image.size
                
                pixel = image.load()
                
                for location_key, date_value_lookup in location_date_value_lookup.items():
                    location = location_lookup.get(location_key)
                    
                    #print location
                    
                    # adjust range to be positive, also to match with existing map
                    longitude = location.get("longitude") + 180.0 - 10.0
                    if longitude < 0:
                        360 - longitude
                    
                    # adjust range to be positive, also to match with existing map
                    latitude = location.get("latitude") + 90.0 + 0.5
                    if latitude < 0:
                        180 - latitude
                        
                    x = int(longitude / 360.0 * (image_width-1))
                    y = image_height - int(latitude / 180.0 * (image_height-1))
                    
                    #print (x, y)
                    
                    if 0 <= x < image_width and 0 <= y < image_height:
                        snapshot_value = date_value_lookup[snapshot_date]
                        
                        # normalize brightness
                        opacity = int(snapshot_value /  max_snapshot_value * 200) + 55
                        pixel[x, y] = (255-opacity, 255-opacity, 255)
                        
                        #print (x, y, opacity)
                    
                image.save(snapshot_filename)            
             
        
        if "prismvis_out" in self.outputDataModelList:
            print "Ndfd_to_prismvis: prismvis_out is present. write prismvis file of locations"
            
            prismvis_out = self.outputDataModelList.get("prismvis_out")
            
            prismvis_filename = prismvis_out.fieldValueList.get("filename")
                
            playback_directory = prismvis_filename + ".playback"
            
            if os.path.exists(playback_directory):
                shutil.rmtree(playback_directory)
            os.mkdir(playback_directory)
            
            # time increment in seconds
            time_increment = 0.25
            playback_time = 0.0
            
            for snapshot_date in snapshot_date_list:
                snapshot_filename = "%s/%f.pvs" % (playback_directory, playback_time)
                playback_time += time_increment
                
                print snapshot_filename
            
                prismvis_file = open(snapshot_filename, 'w')
                
                prismvis_file.write('<?xml version="1.0" encoding="UTF-8"?>\n')
                prismvis_file.write('<scenario>\n')
                prismvis_file.write('<scene>defaultscene</scene>\n')
    
                for location_key, date_value_lookup in location_date_value_lookup.items():
                    location = location_lookup.get(location_key)
                    
                    #print location
                    
                    # adjust range to be positive, also to match with existing map
                    longitude = location.get("longitude") + 180.0 - 10.0
                    if longitude < 0:
                        360 - longitude
                    
                    # adjust range to be positive, also to match with existing map
                    latitude = location.get("latitude") + 90.0 + 0.5
                    if latitude < 0:
                        180 - latitude
                        
                    x = int(longitude / 360.0 * (image_width-1))
                    y = image_height - int(latitude / 180.0 * (image_height-1))
                    
                    #print (x, y)
                    
                    if 0 <= x < image_width and 0 <= y < image_height:
                        height = date_value_lookup[snapshot_date]
                        
                        if height > 0.0:
                            vis_x = x - image_width/2
                            vis_z = y - image_height/2
                            translation = "%d:%f:%d" % (vis_x, height/2.0, vis_z)
                            scale = "%f:%f:%f" % (1.0, height, 1.0)
                            
                            prismvis_file.write('<object object_type="box" object_id="%s">\n' % location_key)
                            prismvis_file.write('<name>%s</name>\n' % location_key)
                            prismvis_file.write('<translation>%s</translation>\n' % translation)
                            prismvis_file.write('<scale>%s</scale>\n' % scale)
                            prismvis_file.write('<height>%f</height>\n' % height)
                            prismvis_file.write('</object>\n')
                    
                prismvis_file.write('</scenario>\n')
                
                prismvis_file.close()  
                         
