# Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
# obo University of Nevada, Reno
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#  * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

import csv
import os
import shutil


class Gsod_to_gsod_csv:

    def __init__(self):
        self.fieldValueList = {}
        self.inputDataModelList = {}
        self.outputDataModelList = {}
    
    
    def run(self):
        self.gsod_in = self.inputDataModelList["gsod_in"]
        gsod_csv_out = self.outputDataModelList["gsod_csv_out"]
        
        year_from = int(self.fieldValueList["year_from"])
        year_to = int(self.fieldValueList["year_to"])
        
        station_name = self.fieldValueList["station_name"]
        
        folder_name = self.gsod_in.fieldValueList["folder_name"]
        output_gsod_csv_filename = gsod_csv_out.fieldValueList["filename"]


        self.output_gsod_csv_file = open(output_gsod_csv_filename, 'w')
        
        # write header
        header_row = []
        
        for field, format in self.gsod_in.dataFormatLookup.items():
            header_row.append(field)

        self.output_gsod_csv_file.write(",".join(header_row) + "\n")
 
        # copy contents
        for year in range(year_from, year_to+1):
            print "read: year %d" % (year)
                        
            gsod_year_folder_name = folder_name + str(year)
            
            if station_name:
              identifier = station_name.split("-")
              
              if len(identifier) == 2:
                  lookup_key = "%s-%s" % (identifier[0], identifier[1])
              
                  if self.gsod_in.ishHistoryLookup.get(lookup_key) != None:
                      gsod_filename = "%s-%s.op" % (station_name, year)
                      
                      print "read file: %s" % gsod_filename

                      self.copyGsodFileContent(gsod_year_folder_name + "/" +gsod_filename)
            else:
              for gsod_filename in os.listdir(gsod_year_folder_name):
                  basename = gsod_filename.split(".")[0]
                  identifier = basename.split("-")
                  
                  if len(identifier) == 3:
                      lookup_key = "%s-%s" % (identifier[0], identifier[1])
                  
                      if self.gsod_in.ishHistoryLookup.get(lookup_key) != None:
                          print "read file: %s" % gsod_filename
  
                          self.copyGsodFileContent(gsod_year_folder_name + "/" +gsod_filename)
          
        self.output_gsod_csv_file.close()
        
        
        if self.outputDataModelList.get("csv_table_out") != None:


    def copyGsodFileContent(self, gsod_filename):
        #print "Gsod: open(\"%s\")" % gsod_filename
        
        try:
          gsod_file = open(gsod_filename, 'rt')
          
          #self.dataFormatLookup = {}
          
          # read and ignore the header
          line = gsod_file.readline()
          #print line
          
          #line = gsod_file.readline()
          for line in gsod_file:
              data_row = []
                  
              for field, format in self.gsod_in.dataFormatLookup.items():
                  position = format.get("POSITION").split("-")
                  start = int(position[0]) - 1 
                  end = int(position[1])
                  
                  #data_row.append("\"" + line[start:end] + "\"")
                  data_row.append(line[start:end])
      
              self.output_gsod_csv_file.write(",".join(data_row) + "\n")
        except IOError as e:
            print "Error opening %s." % gsod_filename


