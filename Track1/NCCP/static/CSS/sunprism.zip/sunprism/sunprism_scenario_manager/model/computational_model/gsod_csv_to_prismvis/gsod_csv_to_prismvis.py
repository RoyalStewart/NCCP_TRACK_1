# Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
# obo University of Nevada, Reno
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#  * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

import Image as PIL_Image
import csv
import os
import shutil
from collections import defaultdict
import datetime


class Gsod_csv_to_prismvis:

    def __init__(self):
        self.fieldValueList = {}
        self.inputDataModelList = {}
        self.outputDataModelList = {}
    
    
    def run(self):
        gsod_in = self.inputDataModelList["gsod_in"]
        gsod_csv_in = self.inputDataModelList["gsod_csv_in"]
       
        gsod_csv_in_filename = gsod_csv_in.fieldValueList["filename"]

        #max_latitude = max([location.get("LAT") for station_id, location in gsod_in.ishHistoryLookup.items()])
        #min_latitude = min([location.get("LAT") for station_id, location in gsod_in.ishHistoryLookup.items()])

        #print "max_latitude = " + str(max_latitude)
        #print "min_latitude = " + str(min_latitude)
        
        #max_longitude = max([location.get("LON") for station_id, location in gsod_in.ishHistoryLookup.items()])
        #min_longitude = min([location.get("LON") for station_id, location in gsod_in.ishHistoryLookup.items()])

        #print "max_longitude = " + str(max_longitude)
        #print "min_longitude = " + str(min_longitude)
        
        #diff_latitude = float(max_latitude - min_latitude)
        #diff_longitude = float(max_longitude - min_longitude)

        #print "diff_latitude = " + str(diff_latitude)
        #print "diff_longitude = " + str(diff_longitude)

        create_station_map = 1
        if create_station_map:
            filename = "station_map.png"
            
            #image_width = 1000
            #image_height = 500
            
            #image = PIL_Image.new ("RGB", (image_width, image_height))
            
            image = PIL_Image.open("world_map_resized.png")
            (image_width, image_height) = image.size
            
            pixel = image.load()
            
            for station_id, location in gsod_in.ishHistoryLookup.items():
                #print location.get("LON"), location.get("LAT")
                
                #x = int((location.get("LON") - min_longitude) / diff_longitude * (image_width-1)) 
                #y = int((location.get("LAT") - min_latitude) / diff_latitude * (image_height-1)) 
                
                # adjust range to be positive, also to match with existing map
                longitude = location.get("LON") / 1000.0 + 180.0 - 10.0
                if longitude < 0:
                    360 - longitude
                
                # adjust range to be positive, also to match with existing map
                latitude = location.get("LAT") / 1000.0 + 90.0 + 0.5
                if latitude < 0:
                    180 - latitude
                    
                x = int(longitude / 360.0 * (image_width-1))
                y = image_height - int(latitude / 180.0 * (image_height-1))
                
                #print x, y
                
                #if 0 <= x and x < image_width and 0 <= y and y < image_height:
                if 0 <= x < image_width and 0 <= y < image_height:
                    pixel[x, y] = (255, 0, 0)
                
            image.save(filename)
        
        
        gsod_csv_in_file = open(gsod_csv_in_filename, 'rt')
        
        csv_reader = csv.DictReader(gsod_csv_in_file)
        
        precipitation_lookup = defaultdict(lambda : defaultdict(float))
        
        min_date = "99999999"
        max_date = "00000000"
        
        for row in csv_reader:
            station_id = "%s-%s" % (row.get("STN---"), row.get("WBAN"))
            
            #initialize station data lookup
            #if station_id not in data_lookup:
            #    data_lookup[station_id] = {[]}
               
            #year, month, date
            date = "%s%s" % (row.get("YEAR"), row.get("MODA"))
            
            precipitation = float(row.get("PRCP"))
            if precipitation == 99.99:
                precipitation = 0.0
                
            precipitation_lookup[station_id][date] = precipitation
            
            if date < min_date:
                min_date = date
                
            if date > max_date:
                max_date = date
                
            #print "station_id: %s, date: %s, precipitation: %f" % (station_id, date, precipitation)
        
        min_date = datetime.date(int(min_date[0:4]), int(min_date[4:6]), int(min_date[6:8]))
        max_date = datetime.date(int(max_date[0:4]), int(max_date[4:6]), int(max_date[6:8]))
        
        print "min_date: %s, max_date: %s" % (min_date.strftime("%Y%m%d"), max_date.strftime("%Y%m%d"))    
    
        
        snapshot_precipitation_lookup = defaultdict(lambda : defaultdict(float))
        
        day_increment = int(self.fieldValueList["day_increment"])
        
        snapshot_date_list = []
        for day_count in range(day_increment-1, (max_date - min_date).days, day_increment):
          snapshot_date = min_date + datetime.timedelta(days=day_count)
          
          snapshot_date_list.append(snapshot_date.strftime("%Y%m%d"))
            
        print "snapshot_date_list"
        print snapshot_date_list
        
        max_snapshot_precipitation = 0.0
        
        for station_id, precipitation_data_lookup in precipitation_lookup.items():
            #print "station_id: %s, data_count: %d" % (station_id, len(precipitation_data_lookup))
    
            day_counter = 1
            snapshot_precipitation = 0.0
            
            #for date in range(min_date, max_date+1):
            for day_count in range((max_date - min_date).days):
                date = min_date + datetime.timedelta(days=day_count)
                date_string = date.strftime("%Y%m%d")
                  
                snapshot_precipitation += precipitation_data_lookup.get(date_string, 0.0)

                #if day_counter % day_increment == 0:
                if date_string in snapshot_date_list:
                    #print "date: %s, snapshot_precipitation: %f" % (date_string, snapshot_precipitation)
                    
                    snapshot_precipitation_lookup[station_id][date_string] = snapshot_precipitation
                    
                    max_snapshot_precipitation = max(max_snapshot_precipitation, snapshot_precipitation)
                    
                    snapshot_precipitation = 0.0
                    
                #day_counter += 1

        print "max_snapshot_precipitation: %f" % (max_snapshot_precipitation)


        if "image_out" in self.outputDataModelList:
            print "Gsod_to_prismvis: image_out is present. write image file of stations' locations"
            
            image_out = self.outputDataModelList.get("image_out")
            
            filename = image_out.fieldValueList.get("filename")
                
            #image_width = 1000
            #image_height = 500
            
            #image = PIL_Image.new ("RGB", (image_width, image_height))            
            
            image = PIL_Image.open("world_map_resized.png")
            (image_width, image_height) = image.size
            
            pixel = image.load()
            
            for snapshot_date in snapshot_date_list:
                extension_index = filename.rindex(".")
                
                snapshot_filename = "%s.%s.%s" % (filename[:extension_index], snapshot_date, filename[extension_index+1:])
                
                print snapshot_filename
                
                image = PIL_Image.open("world_map_resized.png")
                (image_width, image_height) = image.size
                
                pixel = image.load()
                
                for station_id, snapshot_precipitation_data_lookup in snapshot_precipitation_lookup.items():
                    location = gsod_in.ishHistoryLookup.get(station_id)
                    
                    #print location
                    
                    # adjust range to be positive, also to match with existing map
                    longitude = location.get("LON") / 1000.0 + 180.0 - 10.0
                    if longitude < 0:
                        360 - longitude
                    
                    # adjust range to be positive, also to match with existing map
                    latitude = location.get("LAT") / 1000.0 + 90.0 + 0.5
                    if latitude < 0:
                        180 - latitude
                        
                    x = int(longitude / 360.0 * (image_width-1))
                    y = image_height - int(latitude / 180.0 * (image_height-1))
                    
                    #print (x, y)
                    
                    if 0 <= x < image_width and 0 <= y < image_height:
                        snapshot_precipitation = snapshot_precipitation_data_lookup[snapshot_date]
                        
                        # normalize brightness
                        opacity = int(snapshot_precipitation /  max_snapshot_precipitation * 200) + 55
                        pixel[x, y] = (255-opacity, 255-opacity, 255)
                        
                        #print (x, y, opacity)
                    
                image.save(snapshot_filename)            
             

        if "prismvis_out" in self.outputDataModelList:
            print "Gsod_to_prismvis: prismvis_out is present. write prismvis file of stations' locations"
            
            prismvis_out = self.outputDataModelList.get("prismvis_out")
            
            prismvis_filename = prismvis_out.fieldValueList.get("filename")
                
            playback_directory = prismvis_filename + ".playback"
            
            if os.path.exists(playback_directory):
                shutil.rmtree(playback_directory)
            os.mkdir(playback_directory)
            
            # time increment in seconds
            time_increment = 0.25
            playback_time = 0.0
            
            for snapshot_date in snapshot_date_list:
                snapshot_filename = "%s/%f.pvs" % (playback_directory, playback_time)
                playback_time += time_increment
                
                print snapshot_filename
            
                prismvis_file = open(snapshot_filename, 'w')
                
                prismvis_file.write('<?xml version="1.0" encoding="UTF-8"?>\n')
                prismvis_file.write('<scenario>\n')
                prismvis_file.write('<scene>defaultscene</scene>\n')
    
                for station_id, snapshot_precipitation_data_lookup in snapshot_precipitation_lookup.items():
                    location = gsod_in.ishHistoryLookup.get(station_id)
                    
                    #print location
                    
                    # adjust range to be positive, also to match with existing map
                    longitude = location.get("LON") / 1000.0 + 180.0 - 10.0
                    if longitude < 0:
                        360 - longitude
                    
                    # adjust range to be positive, also to match with existing map
                    latitude = location.get("LAT") / 1000.0 + 90.0 + 0.5
                    if latitude < 0:
                        180 - latitude
                        
                    x = int(longitude / 360.0 * (image_width-1))
                    y = image_height - int(latitude / 180.0 * (image_height-1))
                    
                    #print (x, y)
                    
                    if 0 <= x < image_width and 0 <= y < image_height:
                        height = snapshot_precipitation_data_lookup[snapshot_date]
                        
                        if height > 0.0:
                            vis_x = x - image_width/2
                            vis_z = y - image_height/2
                            translation = "%d:%f:%d" % (vis_x, height/2.0, vis_z)
                            scale = "%f:%f:%f" % (1.0, height, 1.0)
                            
                            prismvis_file.write('<object object_type="box" object_id="%s">\n' % station_id)
                            prismvis_file.write('<name>%s</name>\n' % station_id)
                            prismvis_file.write('<translation>%s</translation>\n' % translation)
                            prismvis_file.write('<scale>%s</scale>\n' % scale)
                            prismvis_file.write('<height>%f</height>\n' % height)
                            prismvis_file.write('</object>\n')
                    
                prismvis_file.write('</scenario>\n')
                
                prismvis_file.close()  
                         
        return
        
        precipitation_lookup = {}
        total_precipitation_lookup = {}
        max_total_precipitation = 0.0
        
        day_increment = int(self.fieldValueList["day_increment"])
        
        for lookup_key, gsod_filename in gsod_filename_list.items():
            #print "Gsod_to_prismvis: read %s" % gsod_filename 
            
            data = gsod_in.readGsod(lookup_key)
            
            precipitation_lookup[lookup_key] = []

            total_precipitation = 0.0
            
            snapshot_precipitation = 0.0

            day_counter = 0
       
            for row in data:
                precipitation = float(row.get("PRCP"))
                if precipitation == 99.99:
                    precipitation = 0
                
                total_precipitation += precipitation
                
                snapshot_precipitation += precipitation
                
                if day_counter % day_increment == (day_increment - 1):
                    precipitation_lookup[lookup_key].append(snapshot_precipitation)
                    
                    snapshot_precipitation = 0.0
                
                day_counter += 1
        
            total_precipitation_lookup[lookup_key] = total_precipitation

        max_total_precipitation = max(total_precipitation_lookup.values())
        
        max_snapshot_precipitation = max([value for values in  precipitation_lookup.values() for value in values])

        print "max_snapshot_precipitation: %f" % max_snapshot_precipitation
        
        max_num_snapshot = max([len(values) for values in  precipitation_lookup.values()])
        
        print "max_num_snapshot: %d" % max_num_snapshot
        
        if self.outputDataModelList.get("image_out") != None:
            print "Gsod_to_prismvis: image_out is present. write image file of stations' locations"
            
            image_out = self.outputDataModelList.get("image_out")
            
            filename = image_out.fieldValueList.get("filename")
                
            #image_width = 1000
            #image_height = 500
            
            #image = PIL_Image.new ("RGB", (image_width, image_height))            
            
            image = PIL_Image.open("world_map_resized.png")
            (image_width, image_height) = image.size
            
            pixel = image.load()
            
            for lookup_key, total_precipitation in total_precipitation_lookup.items():
                location = gsod_in.ishHistoryLookup.get(lookup_key)
                
                #print location
                
                # adjust range to be positive, also to match with existing map
                longitude = location.get("LON") / 1000.0 + 180.0 - 10.0
                if longitude < 0:
                    360 - longitude
                
                # adjust range to be positive, also to match with existing map
                latitude = location.get("LAT") / 1000.0 + 90.0 + 0.5
                if latitude < 0:
                    180 - latitude
                    
                x = int(longitude / 360.0 * (image_width-1))
                y = image_height - int(latitude / 180.0 * (image_height-1))
                
                #print (x, y)
                
                if 0 <= x < image_width and 0 <= y < image_height:
                    # normalize brightness
                    opacity = int(total_precipitation /  max_total_precipitation * 200) + 55
                    pixel[x, y] = (255-opacity, 255-opacity, 255)
                    #pixel[x, y] = (255, 255, 255)
                    
                    #print (x, y, opacity)
                
            image.save(filename)
            
            for snapshot_index in range(max_num_snapshot):
                extension_index = filename.rindex(".")
                
                snapshot_filename = "%s.%d.%s" % (filename[:extension_index], snapshot_index, filename[extension_index+1:])
                
                print snapshot_filename
                
                image = PIL_Image.open("world_map_resized.png")
                (image_width, image_height) = image.size
                
                pixel = image.load()
                
                for lookup_key, precipitation_snapshots in precipitation_lookup.items():
                    location = gsod_in.ishHistoryLookup.get(lookup_key)
                    
                    #print location
                    
                    # adjust range to be positive, also to match with existing map
                    longitude = location.get("LON") / 1000.0 + 180.0 - 10.0
                    if longitude < 0:
                        360 - longitude
                    
                    # adjust range to be positive, also to match with existing map
                    latitude = location.get("LAT") / 1000.0 + 90.0 + 0.5
                    if latitude < 0:
                        180 - latitude
                        
                    x = int(longitude / 360.0 * (image_width-1))
                    y = image_height - int(latitude / 180.0 * (image_height-1))
                    
                    #print (x, y)
                    
                    if 0 <= x < image_width and 0 <= y < image_height and snapshot_index < len(precipitation_snapshots):
                        snapshot_precipitation = precipitation_snapshots[snapshot_index]
                        
                        # normalize brightness
                        opacity = int(snapshot_precipitation /  max_snapshot_precipitation * 200) + 55
                        pixel[x, y] = (255-opacity, 255-opacity, 255)
                        
                        #print (x, y, opacity)
                    
                image.save(snapshot_filename)            
            

        if self.outputDataModelList.get("prismvis_out") != None:
            print "Gsod_to_prismvis: prismvis_out is present. write prismvis file of stations' locations"
            
            prismvis_out = self.outputDataModelList.get("prismvis_out")
            
            prismvis_filename = prismvis_out.fieldValueList.get("filename")
                
            prismvis_file = open(prismvis_filename, 'w')
            
            prismvis_file.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            prismvis_file.write('<scenario>\n')
            
            for lookup_key, total_precipitation in total_precipitation_lookup.items():
                location = gsod_in.ishHistoryLookup.get(lookup_key)
                
                #print location
                               
                # adjust range to be positive, also to match with existing map
                longitude = location.get("LON") / 1000.0 + 180.0 - 10.0
                if longitude < 0:
                    360 - longitude
                
                # adjust range to be positive, also to match with existing map
                latitude = location.get("LAT") / 1000.0 + 90.0 + 0.5
                if latitude < 0:
                    180 - latitude
                    
                x = int(longitude / 360.0 * (image_width-1))
                y = image_height - int(latitude / 180.0 * (image_height-1))
                
                #print (x, y)
                
                if 0 <= x < image_width and 0 <= y < image_height:
                    # normalize height
                    height = total_precipitation
                    
                    vis_x = x - image_width/2
                    vis_z = y - image_height/2
                    translation = "%d:%f:%d" % (vis_x, height/2, vis_z)
                    scale = "%f:%f:%f" % (1.0, height, 1.0)
                    
                    prismvis_file.write('<object type="box">\n')
                    prismvis_file.write('<name>%s</name>\n' % lookup_key)
                    prismvis_file.write('<translation>%s</translation>\n' % translation)
                    prismvis_file.write('<scale>%s</scale>\n' % scale)
                    prismvis_file.write('</object>\n')
    
            prismvis_file.write('</scenario>\n')
            
            prismvis_file.close()
            
            playback_directory = prismvis_filename + ".playback"
            
            shutil.rmtree(playback_directory)
            os.mkdir(playback_directory)
            
            # time increment in seconds
            time_increment = 0.25
            playback_time = 0.0
            
            for snapshot_index in range(max_num_snapshot):
                snapshot_filename = "%s/%f.pvs" % (playback_directory, playback_time)
                playback_time += time_increment
                
                print snapshot_filename
            
                prismvis_file = open(snapshot_filename, 'w')
                
                prismvis_file.write('<?xml version="1.0" encoding="UTF-8"?>\n')
                prismvis_file.write("<scenario time=\"%f\">\n"  % playback_time)
                prismvis_file.write('<scene>defaultscene</scene>\n')
    
                for lookup_key, precipitation_snapshots in precipitation_lookup.items():
                    location = gsod_in.ishHistoryLookup.get(lookup_key)
                    
                    #print location
                    
                    # adjust range to be positive, also to match with existing map
                    longitude = location.get("LON") / 1000.0 + 180.0 - 10.0
                    if longitude < 0:
                        360 - longitude
                    
                    # adjust range to be positive, also to match with existing map
                    latitude = location.get("LAT") / 1000.0 + 90.0 + 0.5
                    if latitude < 0:
                        180 - latitude
                        
                    x = int(longitude / 360.0 * (image_width-1))
                    y = image_height - int(latitude / 180.0 * (image_height-1))
                    
                    #print (x, y)
                    
                    if 0 <= x < image_width and 0 <= y < image_height and snapshot_index < len(precipitation_snapshots):
                        height = precipitation_snapshots[snapshot_index]
                        
                        #threshold to reduce the number of objects for performance
                        if height > 0.5:
                            vis_x = x - image_width/2
                            vis_z = y - image_height/2
                            translation = "%d:%f:%d" % (vis_x, height/2.0, vis_z)
                            scale = "%f:%f:%f" % (1.0, height, 1.0)
                            
                            prismvis_file.write('<object object_type="box" object_id="%s">\n' % lookup_key)
                            prismvis_file.write('<name>%s</name>\n' % lookup_key)
                            prismvis_file.write('<translation>%s</translation>\n' % translation)
                            prismvis_file.write('<scale>%s</scale>\n' % scale)
                            prismvis_file.write('</object>\n')
                    
                prismvis_file.write('</scenario>\n')
                
                prismvis_file.close()  
            
