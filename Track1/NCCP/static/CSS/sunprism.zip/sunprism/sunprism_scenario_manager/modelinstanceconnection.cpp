/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "modelinstanceconnection.h"

static const double PI = 3.14159265358979323846264338327950288419717;


ModelInstanceConnection::ModelInstanceConnection(ModelInstance *source_model_instance, ModelInstance *destination_model_instance) :
    QGraphicsItem()
{
    setFlags(QGraphicsItem::ItemIsSelectable);
        
    arrow_size = 10.0;
    
    // temp values
    // TODO: get these value through model instance
    width = 130;
    control_distance = 10.0;
    control_radius = 5.0;
 
    sourceModelInstance = NULL; 
    destinationModelInstance = NULL;
    
    setSourceModelInstance(source_model_instance);
    setDestinationModelInstance(destination_model_instance);
    
    setZValue(-1);
}


ModelInstanceConnection::~ModelInstanceConnection()
{
    if( sourceModelInstance != NULL )
    {
        sourceModelInstance->removeConnection(this);
    }
    
    if( destinationModelInstance != NULL )
    {
        destinationModelInstance->removeConnection(this);
    }
}


void ModelInstanceConnection::setSourceModelInstance(ModelInstance *source_model_instance)
{
    sourceModelInstance = source_model_instance;
         
    if( sourceModelInstance != NULL )
    {
        sourceModelInstance->addConnection(this);
    }
    
    adjust();
}


void ModelInstanceConnection::setDestinationModelInstance(ModelInstance *destination_model_instance)
{
    destinationModelInstance = destination_model_instance;
         
    if( destinationModelInstance != NULL )
    {
        destinationModelInstance->addConnection(this);
    }
    
    adjust();
}


ModelInstance* ModelInstanceConnection::getSourceModelInstance()
{
    return sourceModelInstance;
}


ModelInstance* ModelInstanceConnection::getDestinationModelInstance()
{
    return destinationModelInstance;
}


void ModelInstanceConnection::setSourcePoint(QPointF source_point)
{
    prepareGeometryChange();
    //sourcePoint = mapFromScene(source_point);
    sourcePoint = source_point;
    
    adjust();
}


void ModelInstanceConnection::setDestinationPoint(QPointF destination_point)
{
    prepareGeometryChange();
    destinationPoint = destination_point;
    
    adjust();
}


void ModelInstanceConnection::adjust()
{
    prepareGeometryChange();
    
    // map the center of model instance to this coordinate
    if( sourceModelInstance != NULL )
    {
        sourcePoint = mapFromItem(sourceModelInstance, width/2 + control_distance, 0);
    }
    
    if( destinationModelInstance != NULL )
    {
        destinationPoint = mapFromItem(destinationModelInstance, -(width/2 + control_distance), 0);
    }
    
    drawLine.setPoints(sourcePoint, destinationPoint);
     
  
    qreal length = drawLine.length();
    
    if( length > 0.0 )
    {
        // get line angle (in radian)
        arrowAngle = acos(drawLine.dx() / length);
            
        // acos range is 0 <= angle <= 180. flip angle when it's in lower quadrants
        if (drawLine.dy() < 0)
        {
            arrowAngle = -arrowAngle;
        }
         
        QPointF offset(cos(arrowAngle) * control_radius, sin(arrowAngle) * control_radius);
        
        drawLine.setP1(sourcePoint + offset);
        
        if( length >= (control_radius*2) )
        {
            drawLine.setP2(destinationPoint - offset);
        }
        else
        {
            drawLine.setP2(drawLine.p1());
        }
    }
}


QRectF ModelInstanceConnection::boundingRect() const
{     
    QRectF bounding_rectangle = QRectF(drawLine.p1(), drawLine.p2()).normalized();
    
    // make sure the bounding rectangle includes the arrow width
    //bounding_rectangle.adjust(-arrow_size/2, -arrow_size/2, arrow_size/2, arrow_size/2);
    bounding_rectangle.adjust(-arrow_size, -arrow_size, arrow_size*2, arrow_size*2);
        
    return bounding_rectangle;
}


QPainterPath ModelInstanceConnection::shape() const
{
    QPainterPath path;

    path.moveTo(drawLine.p1());
    path.lineTo(drawLine.p2());

    //return path;
    
    QPainterPathStroker stroker;
    stroker.setWidth(20);
    stroker.setCapStyle(Qt::FlatCap);
    stroker.setJoinStyle(Qt::RoundJoin);
    
    return stroker.createStroke(path);
}


void ModelInstanceConnection::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{   
    painter->setPen(QPen(Qt::black, 1, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
     
    if( option->state & QStyle::State_Selected )
    {
        painter->setPen(QPen(QColor(128, 128, 255, 255), 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    }
    
    painter->drawLine(drawLine);
    
    if( drawLine.length() > arrow_size )
    {
        arrow_size = 10.0;
        QPointF points[3];
        points[0] = QPointF(-arrow_size, -arrow_size/2);
        points[1] = QPointF(-arrow_size, arrow_size/2);
        points[2] = QPointF(0, 0);      
        
        // convert radian to degree
        qreal degree = arrowAngle * (180/PI);
        
        painter->translate(drawLine.p2());
        painter->rotate(degree);
        
        painter->setBrush(Qt::white);
        painter->drawPolygon(points, 3);
    }
}
