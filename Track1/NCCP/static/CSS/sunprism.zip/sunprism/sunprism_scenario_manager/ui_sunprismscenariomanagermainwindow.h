/********************************************************************************
** Form generated from reading UI file 'sunprismscenariomanagermainwindow.ui'
**
** Created: Thu Sep 13 19:00:06 2012
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUNPRISMSCENARIOMANAGERMAINWINDOW_H
#define UI_SUNPRISMSCENARIOMANAGERMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QSplitter>
#include <QtGui/QStatusBar>
#include <QtGui/QTableWidget>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "modeltreewidget.h"
#include "scenarioview.h"

QT_BEGIN_NAMESPACE

class Ui_SunprismScenarioManagerMainWindow
{
public:
    QAction *toolbarActionOpen;
    QAction *menuActionClose;
    QAction *toolbarActionSave;
    QAction *toolbarActionSaveAs;
    QAction *menuActionExit;
    QAction *menuActionCut;
    QAction *menuActionCopy;
    QAction *menuActionPaste;
    QAction *menuActionFind;
    QAction *toolbarActionZoomIn;
    QAction *toolbarActionZoomOut;
    QAction *toolbarActionFullScreen;
    QAction *menuActionAbout;
    QAction *menuActionSetConnection;
    QAction *menuActionZoomIn;
    QAction *menuActionZoomOut;
    QAction *menuActionFullScreen;
    QAction *menuActionOpen;
    QAction *menuActionSave;
    QAction *menuActionSaveAs;
    QAction *toolbarActionRun;
    QAction *menuActionAddUnit;
    QAction *menuActionEditUnit;
    QAction *menuActionDeleteUnit;
    QAction *menuActionFindUnit;
    QAction *toolbarActionStop;
    QAction *menuActionNew;
    QAction *menuActionUndo;
    QAction *menuActionRedo;
    QAction *menuActionSelectAll;
    QAction *menuActionSpeech;
    QAction *menuActionToolbar;
    QAction *menuActionOperationTips;
    QAction *menuActionInstallationInstructions;
    QAction *menuActionGrid;
    QAction *menuActionStatusBar;
    QAction *menuActionRun;
    QAction *menuActionStop;
    QAction *menuActionPause;
    QAction *menuActionRegisterDataModel;
    QAction *menuActionRegisterComputationalModel;
    QAction *toolbarActionNew;
    QAction *toolbarActionLowerLayer;
    QAction *toolbarActionHigherLayer;
    QAction *toolbarActionValidateScenario;
    QAction *menuActionValidateScenario;
    QAction *menuActionLowerLayer;
    QAction *menuActionHigherLayer;
    QAction *menuActionExportExecutable;
    QAction *menuActionSnapToGrid;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout_2;
    QSplitter *splitter_2;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *modelFilterEdit;
    ModelTreeWidget *dataModelTree;
    ModelTreeWidget *computationalModelTree;
    QSplitter *splitter;
    ScenarioView *scenarioView;
    QTableWidget *propertyTable;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuView;
    QMenu *menuTools;
    QMenu *menuExecution;
    QMenu *menuModel;
    QMenu *menuEdit;
    QMenu *menuHelp;
    QToolBar *mainToolbar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *SunprismScenarioManagerMainWindow)
    {
        if (SunprismScenarioManagerMainWindow->objectName().isEmpty())
            SunprismScenarioManagerMainWindow->setObjectName(QString::fromUtf8("SunprismScenarioManagerMainWindow"));
        SunprismScenarioManagerMainWindow->resize(816, 710);
        QIcon icon;
        icon.addFile(QString::fromUtf8("image/sunprism.png"), QSize(), QIcon::Normal, QIcon::Off);
        SunprismScenarioManagerMainWindow->setWindowIcon(icon);
        toolbarActionOpen = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionOpen->setObjectName(QString::fromUtf8("toolbarActionOpen"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("image/document-open-folder.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionOpen->setIcon(icon1);
        menuActionClose = new QAction(SunprismScenarioManagerMainWindow);
        menuActionClose->setObjectName(QString::fromUtf8("menuActionClose"));
        toolbarActionSave = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionSave->setObjectName(QString::fromUtf8("toolbarActionSave"));
        toolbarActionSave->setEnabled(true);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("image/document-save-7.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionSave->setIcon(icon2);
        toolbarActionSaveAs = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionSaveAs->setObjectName(QString::fromUtf8("toolbarActionSaveAs"));
        toolbarActionSaveAs->setEnabled(true);
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("image/document-save-as-6.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionSaveAs->setIcon(icon3);
        menuActionExit = new QAction(SunprismScenarioManagerMainWindow);
        menuActionExit->setObjectName(QString::fromUtf8("menuActionExit"));
        menuActionCut = new QAction(SunprismScenarioManagerMainWindow);
        menuActionCut->setObjectName(QString::fromUtf8("menuActionCut"));
        menuActionCopy = new QAction(SunprismScenarioManagerMainWindow);
        menuActionCopy->setObjectName(QString::fromUtf8("menuActionCopy"));
        menuActionPaste = new QAction(SunprismScenarioManagerMainWindow);
        menuActionPaste->setObjectName(QString::fromUtf8("menuActionPaste"));
        menuActionFind = new QAction(SunprismScenarioManagerMainWindow);
        menuActionFind->setObjectName(QString::fromUtf8("menuActionFind"));
        toolbarActionZoomIn = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionZoomIn->setObjectName(QString::fromUtf8("toolbarActionZoomIn"));
        toolbarActionZoomIn->setEnabled(true);
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("image/zoom-in-3.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionZoomIn->setIcon(icon4);
        toolbarActionZoomOut = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionZoomOut->setObjectName(QString::fromUtf8("toolbarActionZoomOut"));
        toolbarActionZoomOut->setEnabled(true);
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("image/zoom-out-3.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionZoomOut->setIcon(icon5);
        toolbarActionFullScreen = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionFullScreen->setObjectName(QString::fromUtf8("toolbarActionFullScreen"));
        toolbarActionFullScreen->setEnabled(true);
        QIcon icon6;
        icon6.addFile(QString::fromUtf8("image/view-fullscreen-5.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionFullScreen->setIcon(icon6);
        menuActionAbout = new QAction(SunprismScenarioManagerMainWindow);
        menuActionAbout->setObjectName(QString::fromUtf8("menuActionAbout"));
        menuActionSetConnection = new QAction(SunprismScenarioManagerMainWindow);
        menuActionSetConnection->setObjectName(QString::fromUtf8("menuActionSetConnection"));
        menuActionZoomIn = new QAction(SunprismScenarioManagerMainWindow);
        menuActionZoomIn->setObjectName(QString::fromUtf8("menuActionZoomIn"));
        menuActionZoomOut = new QAction(SunprismScenarioManagerMainWindow);
        menuActionZoomOut->setObjectName(QString::fromUtf8("menuActionZoomOut"));
        menuActionFullScreen = new QAction(SunprismScenarioManagerMainWindow);
        menuActionFullScreen->setObjectName(QString::fromUtf8("menuActionFullScreen"));
        menuActionFullScreen->setCheckable(true);
        menuActionOpen = new QAction(SunprismScenarioManagerMainWindow);
        menuActionOpen->setObjectName(QString::fromUtf8("menuActionOpen"));
        menuActionSave = new QAction(SunprismScenarioManagerMainWindow);
        menuActionSave->setObjectName(QString::fromUtf8("menuActionSave"));
        menuActionSaveAs = new QAction(SunprismScenarioManagerMainWindow);
        menuActionSaveAs->setObjectName(QString::fromUtf8("menuActionSaveAs"));
        toolbarActionRun = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionRun->setObjectName(QString::fromUtf8("toolbarActionRun"));
        toolbarActionRun->setEnabled(true);
        QIcon icon7;
        icon7.addFile(QString::fromUtf8("image/player_play.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionRun->setIcon(icon7);
        menuActionAddUnit = new QAction(SunprismScenarioManagerMainWindow);
        menuActionAddUnit->setObjectName(QString::fromUtf8("menuActionAddUnit"));
        menuActionEditUnit = new QAction(SunprismScenarioManagerMainWindow);
        menuActionEditUnit->setObjectName(QString::fromUtf8("menuActionEditUnit"));
        menuActionDeleteUnit = new QAction(SunprismScenarioManagerMainWindow);
        menuActionDeleteUnit->setObjectName(QString::fromUtf8("menuActionDeleteUnit"));
        menuActionFindUnit = new QAction(SunprismScenarioManagerMainWindow);
        menuActionFindUnit->setObjectName(QString::fromUtf8("menuActionFindUnit"));
        toolbarActionStop = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionStop->setObjectName(QString::fromUtf8("toolbarActionStop"));
        toolbarActionStop->setEnabled(true);
        QIcon icon8;
        icon8.addFile(QString::fromUtf8("image/player_stop.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionStop->setIcon(icon8);
        menuActionNew = new QAction(SunprismScenarioManagerMainWindow);
        menuActionNew->setObjectName(QString::fromUtf8("menuActionNew"));
        menuActionUndo = new QAction(SunprismScenarioManagerMainWindow);
        menuActionUndo->setObjectName(QString::fromUtf8("menuActionUndo"));
        menuActionRedo = new QAction(SunprismScenarioManagerMainWindow);
        menuActionRedo->setObjectName(QString::fromUtf8("menuActionRedo"));
        menuActionSelectAll = new QAction(SunprismScenarioManagerMainWindow);
        menuActionSelectAll->setObjectName(QString::fromUtf8("menuActionSelectAll"));
        menuActionSpeech = new QAction(SunprismScenarioManagerMainWindow);
        menuActionSpeech->setObjectName(QString::fromUtf8("menuActionSpeech"));
        menuActionToolbar = new QAction(SunprismScenarioManagerMainWindow);
        menuActionToolbar->setObjectName(QString::fromUtf8("menuActionToolbar"));
        menuActionToolbar->setCheckable(true);
        menuActionToolbar->setChecked(true);
        menuActionOperationTips = new QAction(SunprismScenarioManagerMainWindow);
        menuActionOperationTips->setObjectName(QString::fromUtf8("menuActionOperationTips"));
        menuActionInstallationInstructions = new QAction(SunprismScenarioManagerMainWindow);
        menuActionInstallationInstructions->setObjectName(QString::fromUtf8("menuActionInstallationInstructions"));
        menuActionGrid = new QAction(SunprismScenarioManagerMainWindow);
        menuActionGrid->setObjectName(QString::fromUtf8("menuActionGrid"));
        menuActionGrid->setCheckable(true);
        menuActionGrid->setChecked(true);
        menuActionStatusBar = new QAction(SunprismScenarioManagerMainWindow);
        menuActionStatusBar->setObjectName(QString::fromUtf8("menuActionStatusBar"));
        menuActionStatusBar->setCheckable(true);
        menuActionStatusBar->setChecked(true);
        menuActionRun = new QAction(SunprismScenarioManagerMainWindow);
        menuActionRun->setObjectName(QString::fromUtf8("menuActionRun"));
        menuActionStop = new QAction(SunprismScenarioManagerMainWindow);
        menuActionStop->setObjectName(QString::fromUtf8("menuActionStop"));
        menuActionPause = new QAction(SunprismScenarioManagerMainWindow);
        menuActionPause->setObjectName(QString::fromUtf8("menuActionPause"));
        menuActionRegisterDataModel = new QAction(SunprismScenarioManagerMainWindow);
        menuActionRegisterDataModel->setObjectName(QString::fromUtf8("menuActionRegisterDataModel"));
        menuActionRegisterComputationalModel = new QAction(SunprismScenarioManagerMainWindow);
        menuActionRegisterComputationalModel->setObjectName(QString::fromUtf8("menuActionRegisterComputationalModel"));
        toolbarActionNew = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionNew->setObjectName(QString::fromUtf8("toolbarActionNew"));
        toolbarActionNew->setEnabled(true);
        QIcon icon9;
        icon9.addFile(QString::fromUtf8("image/document-new-6.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionNew->setIcon(icon9);
        toolbarActionLowerLayer = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionLowerLayer->setObjectName(QString::fromUtf8("toolbarActionLowerLayer"));
        toolbarActionLowerLayer->setEnabled(true);
        QIcon icon10;
        icon10.addFile(QString::fromUtf8("image/layer_lower.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionLowerLayer->setIcon(icon10);
        toolbarActionHigherLayer = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionHigherLayer->setObjectName(QString::fromUtf8("toolbarActionHigherLayer"));
        toolbarActionHigherLayer->setEnabled(true);
        QIcon icon11;
        icon11.addFile(QString::fromUtf8("image/layer_higher.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionHigherLayer->setIcon(icon11);
        toolbarActionValidateScenario = new QAction(SunprismScenarioManagerMainWindow);
        toolbarActionValidateScenario->setObjectName(QString::fromUtf8("toolbarActionValidateScenario"));
        toolbarActionValidateScenario->setEnabled(true);
        QIcon icon12;
        icon12.addFile(QString::fromUtf8("image/dialog-ok-apply-6.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolbarActionValidateScenario->setIcon(icon12);
        menuActionValidateScenario = new QAction(SunprismScenarioManagerMainWindow);
        menuActionValidateScenario->setObjectName(QString::fromUtf8("menuActionValidateScenario"));
        menuActionLowerLayer = new QAction(SunprismScenarioManagerMainWindow);
        menuActionLowerLayer->setObjectName(QString::fromUtf8("menuActionLowerLayer"));
        menuActionHigherLayer = new QAction(SunprismScenarioManagerMainWindow);
        menuActionHigherLayer->setObjectName(QString::fromUtf8("menuActionHigherLayer"));
        menuActionExportExecutable = new QAction(SunprismScenarioManagerMainWindow);
        menuActionExportExecutable->setObjectName(QString::fromUtf8("menuActionExportExecutable"));
        menuActionSnapToGrid = new QAction(SunprismScenarioManagerMainWindow);
        menuActionSnapToGrid->setObjectName(QString::fromUtf8("menuActionSnapToGrid"));
        menuActionSnapToGrid->setCheckable(true);
        centralWidget = new QWidget(SunprismScenarioManagerMainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout_2 = new QHBoxLayout(centralWidget);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        splitter_2 = new QSplitter(centralWidget);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        widget = new QWidget(splitter_2);
        widget->setObjectName(QString::fromUtf8("widget"));
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy);
        widget->setMinimumSize(QSize(150, 0));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(-1);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy1);
        widget_2->setMinimumSize(QSize(150, 0));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy2);

        horizontalLayout->addWidget(label);

        modelFilterEdit = new QLineEdit(widget_2);
        modelFilterEdit->setObjectName(QString::fromUtf8("modelFilterEdit"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Minimum);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(modelFilterEdit->sizePolicy().hasHeightForWidth());
        modelFilterEdit->setSizePolicy(sizePolicy3);
        modelFilterEdit->setMinimumSize(QSize(50, 0));

        horizontalLayout->addWidget(modelFilterEdit);


        verticalLayout->addWidget(widget_2);

        dataModelTree = new ModelTreeWidget(widget);
        dataModelTree->setObjectName(QString::fromUtf8("dataModelTree"));
        dataModelTree->setMinimumSize(QSize(150, 100));
        dataModelTree->setLineWidth(1);
        dataModelTree->setDragEnabled(true);
        dataModelTree->setIconSize(QSize(32, 32));
        dataModelTree->setRootIsDecorated(false);
        dataModelTree->setUniformRowHeights(false);
        dataModelTree->setAnimated(false);

        verticalLayout->addWidget(dataModelTree);

        computationalModelTree = new ModelTreeWidget(widget);
        computationalModelTree->setObjectName(QString::fromUtf8("computationalModelTree"));
        computationalModelTree->setMinimumSize(QSize(150, 100));
        computationalModelTree->setDragEnabled(true);
        computationalModelTree->setIconSize(QSize(32, 32));
        computationalModelTree->setRootIsDecorated(false);

        verticalLayout->addWidget(computationalModelTree);

        splitter_2->addWidget(widget);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy4.setHorizontalStretch(1);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(splitter->sizePolicy().hasHeightForWidth());
        splitter->setSizePolicy(sizePolicy4);
        splitter->setOrientation(Qt::Vertical);
        scenarioView = new ScenarioView(splitter);
        scenarioView->setObjectName(QString::fromUtf8("scenarioView"));
        QSizePolicy sizePolicy5(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(10);
        sizePolicy5.setHeightForWidth(scenarioView->sizePolicy().hasHeightForWidth());
        scenarioView->setSizePolicy(sizePolicy5);
        scenarioView->setMinimumSize(QSize(400, 300));
        splitter->addWidget(scenarioView);
        splitter_2->addWidget(splitter);
        propertyTable = new QTableWidget(splitter_2);
        if (propertyTable->columnCount() < 2)
            propertyTable->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        propertyTable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        propertyTable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        propertyTable->setObjectName(QString::fromUtf8("propertyTable"));
        QSizePolicy sizePolicy6(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(propertyTable->sizePolicy().hasHeightForWidth());
        propertyTable->setSizePolicy(sizePolicy6);
        propertyTable->setMinimumSize(QSize(250, 200));
        propertyTable->setAutoFillBackground(false);
        propertyTable->setFrameShape(QFrame::StyledPanel);
        propertyTable->setFrameShadow(QFrame::Sunken);
        propertyTable->setLineWidth(1);
        propertyTable->setAutoScrollMargin(14);
        propertyTable->setAlternatingRowColors(false);
        propertyTable->setShowGrid(true);
        propertyTable->setGridStyle(Qt::SolidLine);
        propertyTable->setCornerButtonEnabled(true);
        propertyTable->setRowCount(0);
        propertyTable->setColumnCount(2);
        splitter_2->addWidget(propertyTable);
        propertyTable->horizontalHeader()->setVisible(true);
        propertyTable->horizontalHeader()->setCascadingSectionResizes(false);
        propertyTable->horizontalHeader()->setHighlightSections(false);
        propertyTable->horizontalHeader()->setMinimumSectionSize(30);
        propertyTable->horizontalHeader()->setStretchLastSection(true);
        propertyTable->verticalHeader()->setVisible(false);
        propertyTable->verticalHeader()->setCascadingSectionResizes(false);
        propertyTable->verticalHeader()->setDefaultSectionSize(23);
        propertyTable->verticalHeader()->setMinimumSectionSize(19);
        propertyTable->verticalHeader()->setProperty("showSortIndicator", QVariant(false));
        propertyTable->verticalHeader()->setStretchLastSection(false);

        horizontalLayout_2->addWidget(splitter_2);

        SunprismScenarioManagerMainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(SunprismScenarioManagerMainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 816, 21));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuView = new QMenu(menuBar);
        menuView->setObjectName(QString::fromUtf8("menuView"));
        menuTools = new QMenu(menuBar);
        menuTools->setObjectName(QString::fromUtf8("menuTools"));
        menuExecution = new QMenu(menuTools);
        menuExecution->setObjectName(QString::fromUtf8("menuExecution"));
        menuModel = new QMenu(menuTools);
        menuModel->setObjectName(QString::fromUtf8("menuModel"));
        menuEdit = new QMenu(menuBar);
        menuEdit->setObjectName(QString::fromUtf8("menuEdit"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        SunprismScenarioManagerMainWindow->setMenuBar(menuBar);
        mainToolbar = new QToolBar(SunprismScenarioManagerMainWindow);
        mainToolbar->setObjectName(QString::fromUtf8("mainToolbar"));
        mainToolbar->setIconSize(QSize(35, 35));
        SunprismScenarioManagerMainWindow->addToolBar(Qt::TopToolBarArea, mainToolbar);
        statusBar = new QStatusBar(SunprismScenarioManagerMainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        SunprismScenarioManagerMainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuEdit->menuAction());
        menuBar->addAction(menuView->menuAction());
        menuBar->addAction(menuTools->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuFile->addAction(menuActionNew);
        menuFile->addAction(menuActionOpen);
        menuFile->addAction(menuActionSave);
        menuFile->addAction(menuActionSaveAs);
        menuFile->addSeparator();
        menuFile->addAction(menuActionClose);
        menuFile->addSeparator();
        menuFile->addAction(menuActionExit);
        menuView->addAction(menuActionZoomIn);
        menuView->addAction(menuActionZoomOut);
        menuView->addSeparator();
        menuView->addAction(menuActionLowerLayer);
        menuView->addAction(menuActionHigherLayer);
        menuView->addSeparator();
        menuView->addAction(menuActionFullScreen);
        menuView->addSeparator();
        menuView->addAction(menuActionToolbar);
        menuView->addAction(menuActionGrid);
        menuView->addAction(menuActionSnapToGrid);
        menuView->addAction(menuActionStatusBar);
        menuTools->addAction(menuModel->menuAction());
        menuTools->addSeparator();
        menuTools->addAction(menuActionValidateScenario);
        menuTools->addSeparator();
        menuTools->addAction(menuExecution->menuAction());
        menuTools->addAction(menuActionExportExecutable);
        menuExecution->addAction(menuActionRun);
        menuExecution->addAction(menuActionPause);
        menuExecution->addAction(menuActionStop);
        menuModel->addAction(menuActionRegisterDataModel);
        menuModel->addAction(menuActionRegisterComputationalModel);
        menuEdit->addAction(menuActionUndo);
        menuEdit->addAction(menuActionRedo);
        menuEdit->addSeparator();
        menuEdit->addAction(menuActionCut);
        menuEdit->addAction(menuActionCopy);
        menuEdit->addAction(menuActionPaste);
        menuEdit->addSeparator();
        menuEdit->addAction(menuActionSelectAll);
        menuEdit->addSeparator();
        menuEdit->addAction(menuActionFind);
        menuEdit->addSeparator();
        menuEdit->addAction(menuActionSpeech);
        menuHelp->addAction(menuActionAbout);
        menuHelp->addAction(menuActionOperationTips);
        menuHelp->addAction(menuActionInstallationInstructions);
        mainToolbar->addAction(toolbarActionNew);
        mainToolbar->addAction(toolbarActionOpen);
        mainToolbar->addAction(toolbarActionSave);
        mainToolbar->addAction(toolbarActionSaveAs);
        mainToolbar->addSeparator();
        mainToolbar->addAction(toolbarActionFullScreen);
        mainToolbar->addAction(toolbarActionZoomIn);
        mainToolbar->addAction(toolbarActionZoomOut);
        mainToolbar->addAction(toolbarActionLowerLayer);
        mainToolbar->addAction(toolbarActionHigherLayer);
        mainToolbar->addSeparator();
        mainToolbar->addAction(toolbarActionValidateScenario);
        mainToolbar->addAction(toolbarActionStop);
        mainToolbar->addAction(toolbarActionRun);

        retranslateUi(SunprismScenarioManagerMainWindow);

        QMetaObject::connectSlotsByName(SunprismScenarioManagerMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *SunprismScenarioManagerMainWindow)
    {
        SunprismScenarioManagerMainWindow->setWindowTitle(QApplication::translate("SunprismScenarioManagerMainWindow", "SUNPRISM Scenario Manager", 0, QApplication::UnicodeUTF8));
        toolbarActionOpen->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Open", 0, QApplication::UnicodeUTF8));
        menuActionClose->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Close", 0, QApplication::UnicodeUTF8));
        menuActionClose->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+W", 0, QApplication::UnicodeUTF8));
        toolbarActionSave->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Save", 0, QApplication::UnicodeUTF8));
        toolbarActionSaveAs->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Save as...", 0, QApplication::UnicodeUTF8));
        menuActionExit->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Exit", 0, QApplication::UnicodeUTF8));
        menuActionExit->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+Q", 0, QApplication::UnicodeUTF8));
        menuActionCut->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Cut", 0, QApplication::UnicodeUTF8));
        menuActionCut->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+X", 0, QApplication::UnicodeUTF8));
        menuActionCopy->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Copy", 0, QApplication::UnicodeUTF8));
        menuActionCopy->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+C", 0, QApplication::UnicodeUTF8));
        menuActionPaste->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Paste", 0, QApplication::UnicodeUTF8));
        menuActionPaste->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+V", 0, QApplication::UnicodeUTF8));
        menuActionFind->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Find", 0, QApplication::UnicodeUTF8));
        menuActionFind->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+F", 0, QApplication::UnicodeUTF8));
        toolbarActionZoomIn->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Zoom In", 0, QApplication::UnicodeUTF8));
        toolbarActionZoomOut->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Zoom Out", 0, QApplication::UnicodeUTF8));
        toolbarActionFullScreen->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Full Screen", 0, QApplication::UnicodeUTF8));
        menuActionAbout->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "About", 0, QApplication::UnicodeUTF8));
        menuActionSetConnection->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Set Connection", 0, QApplication::UnicodeUTF8));
        menuActionZoomIn->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Zoom In", 0, QApplication::UnicodeUTF8));
        menuActionZoomIn->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl++", 0, QApplication::UnicodeUTF8));
        menuActionZoomOut->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Zoom Out", 0, QApplication::UnicodeUTF8));
        menuActionZoomOut->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+-", 0, QApplication::UnicodeUTF8));
        menuActionFullScreen->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Full Screen", 0, QApplication::UnicodeUTF8));
        menuActionFullScreen->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "F11", 0, QApplication::UnicodeUTF8));
        menuActionOpen->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Open", 0, QApplication::UnicodeUTF8));
        menuActionOpen->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+O", 0, QApplication::UnicodeUTF8));
        menuActionSave->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Save", 0, QApplication::UnicodeUTF8));
        menuActionSave->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+S", 0, QApplication::UnicodeUTF8));
        menuActionSaveAs->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Save As...", 0, QApplication::UnicodeUTF8));
        menuActionSaveAs->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+Shift+S", 0, QApplication::UnicodeUTF8));
        toolbarActionRun->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Play", 0, QApplication::UnicodeUTF8));
        menuActionAddUnit->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Add Unit", 0, QApplication::UnicodeUTF8));
        menuActionAddUnit->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ins", 0, QApplication::UnicodeUTF8));
        menuActionEditUnit->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Edit Unit", 0, QApplication::UnicodeUTF8));
        menuActionDeleteUnit->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Delete Unit", 0, QApplication::UnicodeUTF8));
        menuActionDeleteUnit->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Del", 0, QApplication::UnicodeUTF8));
        menuActionFindUnit->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Find Unit", 0, QApplication::UnicodeUTF8));
        menuActionFindUnit->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+F", 0, QApplication::UnicodeUTF8));
        toolbarActionStop->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Stop", 0, QApplication::UnicodeUTF8));
        menuActionNew->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "New", 0, QApplication::UnicodeUTF8));
        menuActionNew->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+N", 0, QApplication::UnicodeUTF8));
        menuActionUndo->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Undo", 0, QApplication::UnicodeUTF8));
        menuActionUndo->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+Z", 0, QApplication::UnicodeUTF8));
        menuActionRedo->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Redo", 0, QApplication::UnicodeUTF8));
        menuActionRedo->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+Y", 0, QApplication::UnicodeUTF8));
        menuActionSelectAll->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Select All", 0, QApplication::UnicodeUTF8));
        menuActionSelectAll->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+A", 0, QApplication::UnicodeUTF8));
        menuActionSpeech->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Speech", 0, QApplication::UnicodeUTF8));
        menuActionToolbar->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Toolbar", 0, QApplication::UnicodeUTF8));
        menuActionToolbar->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+Alt+T", 0, QApplication::UnicodeUTF8));
        menuActionOperationTips->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Operation Tips", 0, QApplication::UnicodeUTF8));
        menuActionInstallationInstructions->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Installation Instructions", 0, QApplication::UnicodeUTF8));
        menuActionGrid->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Grid", 0, QApplication::UnicodeUTF8));
        menuActionGrid->setShortcut(QApplication::translate("SunprismScenarioManagerMainWindow", "Ctrl+L", 0, QApplication::UnicodeUTF8));
        menuActionStatusBar->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Status Bar", 0, QApplication::UnicodeUTF8));
        menuActionRun->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Run", 0, QApplication::UnicodeUTF8));
        menuActionStop->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Stop", 0, QApplication::UnicodeUTF8));
        menuActionPause->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Pause", 0, QApplication::UnicodeUTF8));
        menuActionRegisterDataModel->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Register New Data Resource", 0, QApplication::UnicodeUTF8));
        menuActionRegisterDataModel->setIconText(QApplication::translate("SunprismScenarioManagerMainWindow", "Register New Data Resource", 0, QApplication::UnicodeUTF8));
        menuActionRegisterComputationalModel->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Register New Computational Activity", 0, QApplication::UnicodeUTF8));
        toolbarActionNew->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "New", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        toolbarActionNew->setToolTip(QApplication::translate("SunprismScenarioManagerMainWindow", "New", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        toolbarActionLowerLayer->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Go To Lower Layer", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        toolbarActionLowerLayer->setToolTip(QApplication::translate("SunprismScenarioManagerMainWindow", "Go To Lower Layer", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        toolbarActionHigherLayer->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Go To Higher Layer", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        toolbarActionHigherLayer->setToolTip(QApplication::translate("SunprismScenarioManagerMainWindow", "Go To Higher Layer", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        toolbarActionValidateScenario->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Validate Scenario", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        toolbarActionValidateScenario->setToolTip(QApplication::translate("SunprismScenarioManagerMainWindow", "Validate Scenario", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        menuActionValidateScenario->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Validate Scenario", 0, QApplication::UnicodeUTF8));
        menuActionLowerLayer->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Go To Lower Layer", 0, QApplication::UnicodeUTF8));
        menuActionHigherLayer->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Go To Higher Layer", 0, QApplication::UnicodeUTF8));
        menuActionExportExecutable->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Export Executable", 0, QApplication::UnicodeUTF8));
        menuActionSnapToGrid->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Snap to Grid", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Filter", 0, QApplication::UnicodeUTF8));
        QTreeWidgetItem *___qtreewidgetitem = dataModelTree->headerItem();
        ___qtreewidgetitem->setText(0, QApplication::translate("SunprismScenarioManagerMainWindow", "Data Resources", 0, QApplication::UnicodeUTF8));
        QTreeWidgetItem *___qtreewidgetitem1 = computationalModelTree->headerItem();
        ___qtreewidgetitem1->setText(0, QApplication::translate("SunprismScenarioManagerMainWindow", "Computational Activities", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = propertyTable->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Field", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = propertyTable->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("SunprismScenarioManagerMainWindow", "Value", 0, QApplication::UnicodeUTF8));
        menuFile->setTitle(QApplication::translate("SunprismScenarioManagerMainWindow", "&File", 0, QApplication::UnicodeUTF8));
        menuView->setTitle(QApplication::translate("SunprismScenarioManagerMainWindow", "&View", 0, QApplication::UnicodeUTF8));
        menuTools->setTitle(QApplication::translate("SunprismScenarioManagerMainWindow", "&Tools", 0, QApplication::UnicodeUTF8));
        menuExecution->setTitle(QApplication::translate("SunprismScenarioManagerMainWindow", "Execution", 0, QApplication::UnicodeUTF8));
        menuModel->setTitle(QApplication::translate("SunprismScenarioManagerMainWindow", "Register...", 0, QApplication::UnicodeUTF8));
        menuEdit->setTitle(QApplication::translate("SunprismScenarioManagerMainWindow", "&Edit", 0, QApplication::UnicodeUTF8));
        menuHelp->setTitle(QApplication::translate("SunprismScenarioManagerMainWindow", "&Help", 0, QApplication::UnicodeUTF8));
        mainToolbar->setWindowTitle(QApplication::translate("SunprismScenarioManagerMainWindow", "main Toolbar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class SunprismScenarioManagerMainWindow: public Ui_SunprismScenarioManagerMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUNPRISMSCENARIOMANAGERMAINWINDOW_H
