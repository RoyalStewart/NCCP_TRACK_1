/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scenarioview.h"
#include "modelinstanceconnector.h"
#include "modelinstanceconnection.h"

#include <QtGui>


ScenarioView::ScenarioView(QWidget *parent) :
    QGraphicsView(parent)
{
    mouseMode = NONE;
    dragMode = DRAG_MODE_NONE;
    
    sourceModelInstance = NULL;
    destinationModelInstance = NULL;
    
    tempModelInstanceConnection = NULL;
}


void ScenarioView::setMouseMode(MOUSE_MODE mouse_mode)
{
    mouseMode = mouse_mode;
    
    switch(mouseMode)
    {
        case NONE:
            viewport()->setCursor(Qt::OpenHandCursor);
            setCursor(Qt::OpenHandCursor);
            
            setDragMode(ScrollHandDrag);
            break;
        case PICK_LOCATION:
            viewport()->setCursor(Qt::CrossCursor);
            setCursor(Qt::CrossCursor);
            
            setDragMode(NoDrag);
            break;
        case PICK_TARGET:
            viewport()->setCursor(Qt::ArrowCursor);
            setCursor(Qt::ArrowCursor);
            
            setDragMode(NoDrag);
            break;
    }
}


void ScenarioView::mousePressEvent(QMouseEvent *event)
{
    QGraphicsItem *item = itemAt(event->pos());
    
    if( item != NULL )
    {
        if( item->type() == ModelInstanceConnector::Type )
        {
            viewport()->setCursor(Qt::ClosedHandCursor);
            setCursor(Qt::ClosedHandCursor);
            
            ModelInstanceConnector *connector = qgraphicsitem_cast<ModelInstanceConnector*>(item);
            ModelInstance *model_instance = qgraphicsitem_cast<ModelInstance*>(connector->parentItem());
            
            // current model instance is source if dragging from output connector
            if( connector->getConnectorType() == ModelInstanceConnector::Output )
            {
                dragMode = DRAG_MODE_ADD_CONNECTOR_DESTINATION;
            
                sourceModelInstance = model_instance;
                
                tempModelInstanceConnection = new ModelInstanceConnection();
                tempModelInstanceConnection->setSourcePoint(connector->scenePos());
                
                tempModelInstanceConnection->setDestinationPoint(connector->scenePos());
                
                scene()->addItem(tempModelInstanceConnection);
            }
            // current model instance is destination if dragging from input connector
            else
            {
                dragMode = DRAG_MODE_ADD_CONNECTOR_SOURCE;
                
                destinationModelInstance = model_instance;
                
                tempModelInstanceConnection = new ModelInstanceConnection();
                tempModelInstanceConnection->setDestinationPoint(connector->scenePos());
                
                tempModelInstanceConnection->setSourcePoint(connector->scenePos());
                
                scene()->addItem(tempModelInstanceConnection);
            }
            
            return;
        }
    }
    
    if( event->button() == Qt::RightButton && mouseMode != NONE )
    {
        emit pickCanceled();
    }
    else if( event->button() == Qt::LeftButton )
    {
        switch(mouseMode)
        {
            case NONE:
                break;
            case PICK_LOCATION:
                emit locationPicked(mapToScene(event->pos()));
                
                return;
                
                break;
            case PICK_TARGET:
                QGraphicsItem *item = itemAt(event->pos());
                if( item )
                {
                    emit targetPicked(item);
                
                    return;
                }
                break;
        }
    }
    
	QGraphicsView::mousePressEvent(event);
}


void ScenarioView::mouseMoveEvent(QMouseEvent *event)
{
    if( dragMode == DRAG_MODE_ADD_CONNECTOR_DESTINATION )
    {
        tempModelInstanceConnection->setDestinationPoint(mapToScene(event->pos()));
    
        return;
    }
    else if( dragMode == DRAG_MODE_ADD_CONNECTOR_SOURCE )
    {
        tempModelInstanceConnection->setSourcePoint(mapToScene(event->pos()));
        
        return;
    }
    
	QGraphicsView::mouseMoveEvent(event);
}


void ScenarioView::mouseReleaseEvent(QMouseEvent *event)
{
    if( dragMode == DRAG_MODE_ADD_CONNECTOR_SOURCE ||
        dragMode == DRAG_MODE_ADD_CONNECTOR_DESTINATION )
    {
        QGraphicsItem *item = itemAt(event->pos());
        
        if( item != NULL )
        {
            if( item->type() == ModelInstanceConnector::Type )
            {
                ModelInstanceConnector *connector = qgraphicsitem_cast<ModelInstanceConnector*>(item);
                ModelInstance *model_instance = qgraphicsitem_cast<ModelInstance*>(connector->parentItem());
                
                if( dragMode == DRAG_MODE_ADD_CONNECTOR_DESTINATION &&
                    connector->getConnectorType() == ModelInstanceConnector::Input )
                {
                    destinationModelInstance = model_instance;
                }
                else if( dragMode == DRAG_MODE_ADD_CONNECTOR_SOURCE &&
                         connector->getConnectorType() == ModelInstanceConnector::Output )
                {
                    sourceModelInstance = model_instance;
                }
            }
        }

        if( sourceModelInstance != NULL &&
            destinationModelInstance != NULL &&
            sourceModelInstance != destinationModelInstance )
        {
            tempModelInstanceConnection->setSourceModelInstance(sourceModelInstance);
            tempModelInstanceConnection->setDestinationModelInstance(destinationModelInstance);
        }
        else
        {
            scene()->removeItem(tempModelInstanceConnection);
            delete tempModelInstanceConnection;
        }
        
        sourceModelInstance = NULL;
        destinationModelInstance = NULL;
        tempModelInstanceConnection = NULL;

        dragMode = DRAG_MODE_NONE;
        
        viewport()->setCursor(Qt::OpenHandCursor);
        setCursor(Qt::OpenHandCursor);
        
        return;
    }
    
	QGraphicsView::mouseReleaseEvent(event);
}


void ScenarioView::dragEnterEvent(QDragEnterEvent *event)
{
    if( event->mimeData()->hasFormat("application/x-modeltreeitem") )
    {
        event->accept();
    }
    else
    {
        event->ignore();
    }
}


void ScenarioView::dragMoveEvent(QDragMoveEvent *event)
{
    if( event->mimeData()->hasFormat("application/x-modeltreeitem") )
    {
        event->setDropAction(Qt::MoveAction);
        event->accept();
    }
    else
    {
        event->ignore();
    }
}


void ScenarioView::dropEvent(QDropEvent *event)
{    
    if( event->mimeData()->hasFormat("application/x-modeltreeitem") )
    {
        QByteArray pieceData = event->mimeData()->data("application/x-modeltreeitem");
        QDataStream dataStream(&pieceData, QIODevice::ReadOnly);
        
        QString tree_object;
        QString model;
        dataStream >> tree_object >> model;
         
        event->setDropAction(Qt::MoveAction);
        
        event->accept();
        
        emit modelDropped(tree_object, model, mapToScene(event->pos()));
    }
    else
    {
        event->ignore();
    }
}


void ScenarioView::keyPressEvent(QKeyEvent *event)
{   
    switch( event->key() )
    {
        case Qt::Key_Delete:
            emit deleteSelectedItems();
            
            break;
            
        default:
            QGraphicsView::keyPressEvent(event);
            break;
    }
}

