/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "computationalmodelreader.h"
#include "parameter.h"


ComputationalModelReader::ComputationalModelReader(QMap<QString, ComputationalModel*> *computational_model_list)
{
    computationalModelList = computational_model_list;
}


bool ComputationalModelReader::read(QIODevice *device)
{
    xml_reader.setDevice(device);

    computationalModelVector.clear();
            
    if( xml_reader.readNextStartElement() )
    {
        if( xml_reader.name() == "computational_model" )
        {
            readComputationalModel();
            
            if( computationalModelVector.size() == 0 )
            {
                xml_reader.raiseError(QObject::tr("computational Model loading failed."));
            }
            
            for( int i = 0; i < computationalModelVector.size(); i++ )
            {
                ComputationalModel *computational_model = computationalModelVector.value(i);
        
                QMap<QString, QString> *computational_model_field_value_list = computational_model->getFieldValueList();
                
                computationalModelList->insert(computational_model_field_value_list->value("name"), computational_model);
            }
        }
        else
        {
            xml_reader.raiseError(QObject::tr("The file is not an Computational Model file."));
        }
    }

    return !xml_reader.error();
}


QString ComputationalModelReader::errorString() const
{
    return QObject::tr("%1\nLine %2, column %3")
            .arg(xml_reader.errorString())
            .arg(xml_reader.lineNumber())
            .arg(xml_reader.columnNumber());
}


void ComputationalModelReader::readComputationalModel()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "computational_model");
    
    ComputationalModel *computational_model = new ComputationalModel();
    computationalModelVector.push_back(computational_model);
    
    foreach( QXmlStreamAttribute attribute, xml_reader.attributes() )
    {
        computational_model->getFieldValueList()->insert(attribute.name().toString(), attribute.value().toString());
    }
            
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "name" )
        {
            QString value = xml_reader.readElementText();
            computational_model->getFieldValueList()->insert(name, value);
        }
        else if( name == "icon" )
        {
            QString value = xml_reader.readElementText();
            computational_model->getFieldValueList()->insert(name, value);
        }
        else if( name == "api" )
        {
            QString value = xml_reader.readElementText();
            computational_model->getFieldValueList()->insert(name, value);
        }
        else if( name == "input_parameter" )
        {
            computational_model->getInputParameterList()->append(Parameter());
            readInputParameter();
        }
        else if( name == "input_data_model" )
        {
            QMap<QString, QString> input_data_model_field_list;
     
            foreach( QXmlStreamAttribute attribute, xml_reader.attributes() )
            {
                input_data_model_field_list.insert(attribute.name().toString(), attribute.value().toString());
            }
            
            computational_model->getInputDataModelList()->insert(input_data_model_field_list.value("name"), input_data_model_field_list);
            
            xml_reader.skipCurrentElement();
        }
        else if( name == "output_data_model" )
        {
            QMap<QString, QString> output_data_model_field_list;
     
            foreach( QXmlStreamAttribute attribute, xml_reader.attributes() )
            {
                output_data_model_field_list.insert(attribute.name().toString(), attribute.value().toString());
            }
            
            computational_model->getOutputDataModelList()->insert(output_data_model_field_list.value("name"), output_data_model_field_list);
            
            xml_reader.skipCurrentElement();
        }
        else
        {
            xml_reader.skipCurrentElement();
        }
    }
}
 

void ComputationalModelReader::readInputParameter()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "input_parameter");
    
    ComputationalModel *computational_model = computationalModelVector.back();
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "name" )
        {
            QString value = xml_reader.readElementText();
            computational_model->getInputParameterList()->last().setName(value);
        }
        else if( name == "type" )
        {
            QString value = xml_reader.readElementText();
            computational_model->getInputParameterList()->last().setType(value);
        }
        else if( name == "default" )
        {
            QString value = xml_reader.readElementText();
            computational_model->getInputParameterList()->last().setDefaultValue(value);
        }
        else if( name == "order" )
        {
            QString value = xml_reader.readElementText();
            computational_model->getInputParameterList()->last().setOrder(value.toInt());
        }
        else
        {
            xml_reader.skipCurrentElement();
        }
    }
}


void ComputationalModelReader::readInputDataModel()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "input_data_model");
}


void ComputationalModelReader::readOutputDataModel()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "output_data_model");
}
