/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scenarioreader.h"

#include <QtGui>


ScenarioReader::ScenarioReader(Scenario *scenario_reference)
{
    scenario = scenario_reference;
}


bool ScenarioReader::read(QIODevice *device)
{
    xml_reader.setDevice(device);
            
    if( xml_reader.readNextStartElement() )
    {
        if( xml_reader.name() == "scenario" )
        {
            readScenario();
            
            setModelInstanceConnections();
        }
        else
        {
            xml_reader.raiseError(QObject::tr("The file is not an Scenario file."));
        }
    }

    return !xml_reader.error();
}


QString ScenarioReader::errorString() const
{
    return QObject::tr("%1\nLine %2, column %3")
            .arg(xml_reader.errorString())
            .arg(xml_reader.lineNumber())
            .arg(xml_reader.columnNumber());
}


void ScenarioReader::readScenario()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "scenario");
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "data_model_instance" )
        {
            scenario->getDataModelInstanceList()->append(new DataModelInstance());
            readDataModelInstance();
        }
        else if( name == "computational_model_instance" )
        {
            scenario->getComputationalModelInstanceList()->append(new ComputationalModelInstance());
            readComputationalModelInstance();
        }
        else
        {
            xml_reader.skipCurrentElement();
        }
    }
}
 

void ScenarioReader::readDataModelInstance()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "data_model_instance");
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        QString value = xml_reader.readElementText();
        scenario->getDataModelInstanceList()->last()->getFieldValueList()->insert(name, value);
    }
}


void ScenarioReader::readComputationalModelInstance()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "computational_model_instance");
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        if( name == "input_data_model" )
        {
            scenario->getComputationalModelInstanceList()->last()->getInputDataModelList()->append(QMap<QString, QString>());
            readInputDataModel();
        }
        else if( name == "output_data_model" )
        {
            scenario->getComputationalModelInstanceList()->last()->getOutputDataModelList()->append(QMap<QString, QString>());
            readOutputDataModel();
        }
        else
        {
            QString value = xml_reader.readElementText();
            scenario->getComputationalModelInstanceList()->last()->getFieldValueList()->insert(name, value);
        }
    }
}


void ScenarioReader::readInputDataModel()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "input_data_model");
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        QString value = xml_reader.readElementText();
        scenario->getComputationalModelInstanceList()->last()->getInputDataModelList()->last().insert(name, value);
    }
}


void ScenarioReader::readOutputDataModel()
{
    Q_ASSERT(xml_reader.isStartElement() && xml_reader.name() == "output_data_model");
    
    while( xml_reader.readNextStartElement() )
    {
        QString name = xml_reader.name().toString();
        
        QString value = xml_reader.readElementText();
        scenario->getComputationalModelInstanceList()->last()->getOutputDataModelList()->last().insert(name, value);
    }
}


void ScenarioReader::setModelInstanceConnections()
{
    for( int i = 0; i < scenario->getComputationalModelInstanceList()->size(); i++ )
    {
        ComputationalModelInstance *computational_model_instance = scenario->getComputationalModelInstanceList()->value(i);

        QVector< QMap<QString, QString> > *input_data_model_list = computational_model_instance->getInputDataModelList();
        for( int j = 0; j < input_data_model_list->size(); j++ )
        {
            QMap<QString, QString> input_data_model = input_data_model_list->value(j);
        
            QMap<QString, QString>::const_iterator input_data_model_field_iterator = input_data_model.constBegin();
             
            while (input_data_model_field_iterator != input_data_model.constEnd())
            {
                ++input_data_model_field_iterator;
            }
            
            DataModelInstance* input_data_model_instance = scenario->findDataModelInstance(input_data_model.value("instance_name"));
            if( input_data_model_instance != NULL )
            {
                ModelInstanceConnection *model_instance_connection = new ModelInstanceConnection(input_data_model_instance, computational_model_instance);
                
                model_instance_connection->setParentItem(computational_model_instance);
            }
        }
        
        QVector< QMap<QString, QString> > *output_data_model_list = computational_model_instance->getOutputDataModelList();
        for( int j = 0; j < output_data_model_list->size(); j++ )
        {
            QMap<QString, QString> output_data_model = output_data_model_list->value(j);
        
            QMap<QString, QString>::const_iterator output_data_model_field_iterator = output_data_model.constBegin();
             
            while (output_data_model_field_iterator != output_data_model.constEnd())
            {
                ++output_data_model_field_iterator;
            }
            
            DataModelInstance* output_data_model_instance = scenario->findDataModelInstance(output_data_model.value("instance_name"));
            if( output_data_model_instance != NULL )
            {
                ModelInstanceConnection *model_instance_connection = new ModelInstanceConnection(computational_model_instance, output_data_model_instance);
                
                model_instance_connection->setParentItem(computational_model_instance);
            }
        }
    }
}

