/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "datamodelwriter.h"


DataModelWriter::DataModelWriter(DataModelRegistrationDialog *data_model_registration_dialog)
{
    dataModelRegistrationDialog = data_model_registration_dialog;
  
    xml_writer.setAutoFormatting(true);
}


bool DataModelWriter::writeDataModel(QIODevice *device)
{
    xml_writer.setDevice(device);

    xml_writer.writeStartDocument();

    xml_writer.writeStartElement("data_model");

    xml_writer.writeTextElement("name", dataModelRegistrationDialog->getNameEdit()->text());
    xml_writer.writeTextElement("icon", dataModelRegistrationDialog->getIconFileEdit()->text());
    xml_writer.writeTextElement("api", dataModelRegistrationDialog->getApiFileEdit()->text());

    // write input parameters
    
    QTableWidget *input_parameters_table = dataModelRegistrationDialog->getInputParametersTable();
    
    int row_count = 0;
    
    for( int i = 0; i < input_parameters_table->rowCount(); i++ )
    {
        // quick validation
        if( input_parameters_table->item(i, 0) != NULL &&
            input_parameters_table->item(i, 1) != NULL &&
            input_parameters_table->item(i, 2) != NULL &&
            input_parameters_table->item(i, 3) != NULL )
        {
            ++row_count;
            
            xml_writer.writeStartElement("input_parameter");
            
            xml_writer.writeTextElement("name", input_parameters_table->item(i, 0)->text());
            xml_writer.writeTextElement("type", input_parameters_table->item(i, 1)->text());
            
            if( input_parameters_table->item(i, 2)->checkState() == Qt::Checked )
            {
                xml_writer.writeAttribute("required", "1");
            }
            
            xml_writer.writeTextElement("default", input_parameters_table->item(i, 3)->text());
            xml_writer.writeTextElement("order", QString::number(row_count));
            
            xml_writer.writeEndElement();
        }
    }
    
    // write static parameters
    
    QTableWidget *static_parameters_table = dataModelRegistrationDialog->getStaticParametersTable();
    
    row_count = 0;
    
    for( int i = 0; i < static_parameters_table->rowCount(); i++ )
    {
        // quick validation
        if( static_parameters_table->item(i, 0) != NULL &&
            static_parameters_table->item(i, 1) != NULL &&
            static_parameters_table->item(i, 2) != NULL )
        {
            ++row_count;
            
            xml_writer.writeStartElement("static_parameter");
            
            xml_writer.writeTextElement("name", static_parameters_table->item(i, 0)->text());
            xml_writer.writeTextElement("type", static_parameters_table->item(i, 1)->text());
            xml_writer.writeTextElement("value", static_parameters_table->item(i, 2)->text());
            xml_writer.writeTextElement("order", QString::number(row_count));
            
            xml_writer.writeEndElement();
        }
    }
    
    xml_writer.writeEndElement();

    xml_writer.writeEndDocument();

    return true;
}

