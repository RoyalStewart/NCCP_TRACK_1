/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "sunprismscenariomanagermainwindow.h"
#include "model.h"

#include "datamodelreader.h"
#include "computationalmodelreader.h"
#include "scenarioreader.h"

#include "datamodelregistrationdialog.h"
#include "computationalmodelregistrationdialog.h"

#include "datamodelwriter.h"
#include "computationalmodelwriter.h"
#include "scenariowriter.h"

#include "ui_sunprismscenariomanagermainwindow.h"
 

SunprismScenarioManagerMainWindow::SunprismScenarioManagerMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SunprismScenarioManagerMainWindow)
{
    QDir::setCurrent(QCoreApplication::applicationDirPath());
    
    ui->setupUi(this);
    
    pythonConsole = new PythonQtScriptingConsole(ui->splitter, *scenarioExecutor.getModule());
    
    pythonConsole->hide();
    
    
    dataModelPath = "model/data_model";
    computationalModelPath = "model/computational_model";
    
    loadDataModelList();
    
    loadComputationalModelList();
      
    ui->scenarioView->setAcceptDrops(false);
    ui->dataModelTree->setAcceptDrops(false);
    ui->computationalModelTree->setAcceptDrops(false);
    
    
    connect(ui->menuActionNew, SIGNAL(triggered()),
            this, SLOT(newScenario()));
    connect(ui->toolbarActionNew, SIGNAL(triggered()),
            this, SLOT(newScenario()));
    
    connect(ui->menuActionOpen, SIGNAL(triggered()),
            this, SLOT(openScenario()));
    connect(ui->toolbarActionOpen, SIGNAL(triggered()),
            this, SLOT(openScenario()));
    
    connect(ui->menuActionSave, SIGNAL(triggered()),
            this, SLOT(saveScenario()));
    connect(ui->toolbarActionSave, SIGNAL(triggered()),
            this, SLOT(saveScenario()));
    
    connect(ui->menuActionSaveAs, SIGNAL(triggered()),
            this, SLOT(saveScenarioAs()));
    connect(ui->toolbarActionSaveAs, SIGNAL(triggered()),
            this, SLOT(saveScenarioAs()));
    
    connect(ui->menuActionClose, SIGNAL(triggered()),
            this, SLOT(closeScenario()));
    
    connect(ui->menuActionExit, SIGNAL(triggered()),
            this, SLOT(close()));
    
    
    connect(ui->menuActionZoomIn, SIGNAL(triggered()),
            this, SLOT(zoomIn()));
    connect(ui->toolbarActionZoomIn, SIGNAL(triggered()),
            this, SLOT(zoomIn()));
    
    connect(ui->menuActionZoomOut, SIGNAL(triggered()),
            this, SLOT(zoomOut()));
    connect(ui->toolbarActionZoomOut, SIGNAL(triggered()),
            this, SLOT(zoomOut()));
    
    connect(ui->menuActionFullScreen, SIGNAL(triggered()),
            this, SLOT(toggleFullScreen()));
    connect(ui->toolbarActionFullScreen, SIGNAL(triggered()),
            this, SLOT(toggleFullScreen()));
    
    connect(ui->menuActionGrid, SIGNAL(triggered()),
            this, SLOT(toggleGrid()));
    
    connect(ui->menuActionSnapToGrid, SIGNAL(triggered()),
            this, SLOT(toggleSnapToGrid()));
    
    connect(ui->menuActionRegisterDataModel, SIGNAL(triggered()),
            this, SLOT(registerDataModel()));
    
    connect(ui->menuActionRegisterComputationalModel, SIGNAL(triggered()),
            this, SLOT(registerComputationalModel()));
    
    connect(ui->menuActionRun, SIGNAL(triggered()),
            this, SLOT(runScenario()));
    connect(ui->toolbarActionRun, SIGNAL(triggered()),
            this, SLOT(runScenario()));
    
    connect(ui->menuActionExportExecutable, SIGNAL(triggered()),
            this, SLOT(exportExecutable()));
    
    
    connect(&scenario, SIGNAL(selectionChanged()),
            this, SLOT(scenarioSelectionChanged()));
    
    connect(ui->propertyTable, SIGNAL(itemChanged(QTableWidgetItem*)),
            this, SLOT(propertyTableItemChanged(QTableWidgetItem*)));
    
    connect(ui->scenarioView, SIGNAL(modelDropped(QString, QString, QPointF)),
            this, SLOT(scenarioViewModelDropped(QString, QString, QPointF)));
    
    connect(ui->scenarioView, SIGNAL(deleteSelectedItems()),
            this, SLOT(scenarioViewDeleteSelectedItems()));
    
    connect(&scenarioExecutor, SIGNAL(modelInstanceExecutionStarted(ModelInstance*)),
            this, SLOT(modelInstanceExecutionStarted(ModelInstance*)));
    connect(&scenarioExecutor, SIGNAL(modelInstanceExecutionFinished(ModelInstance*)),
            this, SLOT(modelInstanceExecutionFinished(ModelInstance*)));
    
    connect(&scenarioExecutor, SIGNAL(evaluatingScript(QString)),
            this, SLOT(evaluatingScript(QString)));
    
    connect(&scenarioExecutor, SIGNAL(finished()),
            this, SLOT(scenarioExecutionFinished()));
    
    
    scenarioExecutionTimer = new QTimer(this);
    connect(scenarioExecutionTimer, SIGNAL(timeout()), this, SLOT(updateScenarioExecution()));
    scenarioExecutionTimer->setInterval(100);
    
    currentProgressIndicator = NULL;
    
    // initialize as closed
    closeScenario();
}


SunprismScenarioManagerMainWindow::~SunprismScenarioManagerMainWindow()
{
    delete ui;
}


void SunprismScenarioManagerMainWindow::loadDataModelList()
{
    // clear data model list, and add all data models in dataModelPath folder
    dataModelList.clear();
     
    DataModelReader data_model_reader(&dataModelList);
    
    // get all the folder names in dataModelPath folder
    QDir data_model_directory(dataModelPath);
    QFileInfoList data_model_directory_list = data_model_directory.entryInfoList(QDir::AllDirs | QDir::NoDotAndDotDot);
    
    // iterate and check if there is any ".dtm" file
    // read just the first found ".dtm" file
    for( int i = 0; i < data_model_directory_list.size(); i++ )
    {
        data_model_directory.setPath(data_model_directory_list.at(i).filePath());
        
        QFileInfoList data_model_file_list = data_model_directory.entryInfoList(QStringList("*.dtm"), QDir::Files);

        if( data_model_file_list.size() > 0 )
        {
            QFile data_model_file(data_model_file_list.at(0).filePath());
            if( !data_model_file.open(QFile::ReadOnly | QFile::Text) )
            {
                QMessageBox::warning(this, tr("Data Model Reader"),
                                     tr("Cannot read file %1:\n%2.")
                                     .arg(data_model_file_list.at(0).filePath())
                                     .arg(data_model_file.errorString()));
            
                return;
            }
        
            if( !data_model_reader.read(&data_model_file) )
            {
               QMessageBox::warning(this, tr("Data Model Reader"),
                               tr("Parse error in file %1:\n\n%2")
                               .arg(data_model_file_list.at(0).filePath())
                               .arg(data_model_reader.errorString()));
            
               return;
            }             
        }
    }
    
    
    // TODO: Need to validate and remove invalid data models

    
    QMap<QString, DataModel*>::const_iterator data_model_iterator = dataModelList.constBegin();
    
    while( data_model_iterator != dataModelList.constEnd() )
    {
        DataModel *data_model = data_model_iterator.value();
            
        QMap<QString, QString> *field_value_list = data_model->getFieldValueList();
        
        field_value_list->insert("path", dataModelPath);
        
        QString icon_file = QString("%1/%2/%3")
                            .arg(field_value_list->value("path"))
                            .arg(field_value_list->value("name"))
                            .arg(field_value_list->value("icon"));
                            
        QTreeWidgetItem *tree_item = new QTreeWidgetItem(ui->dataModelTree);
        tree_item->setIcon(0, QIcon(icon_file));
        tree_item->setText(0, field_value_list->value("name"));
        
        ++data_model_iterator;
    }
}


void SunprismScenarioManagerMainWindow::loadComputationalModelList()
{
    // clear computational model list, and add all computational models in computationalModelPath folder
    computationalModelList.clear();
     
    ComputationalModelReader computational_model_reader(&computationalModelList);
    
    // get all the folder names in computationalModelPath folder
    QDir computational_model_directory(computationalModelPath);
    QFileInfoList computational_model_directory_list = computational_model_directory.entryInfoList(QDir::AllDirs | QDir::NoDotAndDotDot);
    
    // iterate and check if there is any ".dtm" file
    // read just the first found ".dtm" file
    for( int i = 0; i < computational_model_directory_list.size(); i++ )
    {
        computational_model_directory.setPath(computational_model_directory_list.at(i).filePath());
        
        QFileInfoList computational_model_file_list = computational_model_directory.entryInfoList(QStringList("*.cpm"), QDir::Files);

        if( computational_model_file_list.size() > 0 )
        {
            QFile computational_model_file(computational_model_file_list.at(0).filePath());
            if( !computational_model_file.open(QFile::ReadOnly | QFile::Text) )
            {
                QMessageBox::warning(this, tr("Computational Model Reader"),
                                     tr("Cannot read file %1:\n%2.")
                                     .arg(computational_model_file_list.at(0).filePath())
                                     .arg(computational_model_file.errorString()));
            
                return;
            }
        
            if( !computational_model_reader.read(&computational_model_file) )
            {
               QMessageBox::warning(this, tr("Computational Model Reader"),
                               tr("Parse error in file %1:\n\n%2")
                               .arg(computational_model_file_list.at(0).filePath())
                               .arg(computational_model_reader.errorString()));
            
               return;
            }             
        }
    }        
    
    // TODO: Need to validate and remove invalid computational models
    
    
    QMap<QString, ComputationalModel*>::const_iterator computational_model_iterator = computationalModelList.constBegin();
    
    while( computational_model_iterator != computationalModelList.constEnd() )
    {
        ComputationalModel *computational_model = computational_model_iterator.value();
                
        QMap<QString, QString> *field_value_list = computational_model->getFieldValueList();
        
        field_value_list->insert("path", computationalModelPath);
        
        QString icon_file = QString("%1/%2/%3")
                            .arg(field_value_list->value("path"))
                            .arg(field_value_list->value("name"))
                            .arg(field_value_list->value("icon"));
                            
        QTreeWidgetItem *tree_item = new QTreeWidgetItem(ui->computationalModelTree);
        tree_item->setIcon(0, QIcon(icon_file));
        tree_item->setText(0, field_value_list->value("name"));
        
        ++computational_model_iterator;
    }    
}


void SunprismScenarioManagerMainWindow::setBasicOperationsEnabled(bool enable)
{
    ui->menuActionSave->setEnabled(enable);
    ui->toolbarActionSave->setEnabled(enable);

    ui->menuActionSaveAs->setEnabled(enable);
    ui->toolbarActionSaveAs->setEnabled(enable);

    ui->menuActionClose->setEnabled(enable);

    ui->menuActionZoomIn->setEnabled(enable);
    ui->toolbarActionZoomIn->setEnabled(enable);

    ui->menuActionZoomOut->setEnabled(enable);
    ui->toolbarActionZoomOut->setEnabled(enable);
    
    ui->menuActionLowerLayer->setEnabled(enable);
    ui->toolbarActionLowerLayer->setEnabled(enable);
    
    ui->menuActionHigherLayer->setEnabled(enable);
    ui->toolbarActionHigherLayer->setEnabled(enable);
    
    ui->menuActionValidateScenario->setEnabled(enable);
    ui->toolbarActionValidateScenario->setEnabled(enable);
    
    ui->menuExecution->setEnabled(enable);
    
    ui->toolbarActionRun->setEnabled(enable);
    
    ui->toolbarActionStop->setEnabled(enable);
    
    ui->menuActionExportExecutable->setEnabled(enable);
}


void SunprismScenarioManagerMainWindow::newScenario()
{ 
    closeScenario();
    
    resetScenarioView();
    
    setBasicOperationsEnabled(true);
    
    // disable save, since no filename to save yet
    ui->menuActionSave->setEnabled(false);
    ui->toolbarActionSave->setEnabled(false);
    
    ui->scenarioView->setAcceptDrops(true);
    ui->dataModelTree->setAcceptDrops(true);
    ui->computationalModelTree->setAcceptDrops(true);
}


void SunprismScenarioManagerMainWindow::openScenario()
{
    QString filename =
            QFileDialog::getOpenFileName( this, tr("Open Scenario File"),
                                          QDir::currentPath(),
                                          tr("SCN Files (*.scn)") );
            
    if( filename.isEmpty() )
    {
        return;
    }
    
    currentScenarioFile.setFileName(filename);
    if( !currentScenarioFile.open(QFile::ReadOnly | QFile::Text) )
    {
        QMessageBox::warning( this, tr("Scenario Reader"),
                              tr("Cannot read file %1:\n%2.")
                              .arg(filename)
                              .arg(currentScenarioFile.errorString()) );
        return;
    }

    closeScenario();
    
    ScenarioReader scenario_reader( &scenario );
    
    if( !scenario_reader.read(&currentScenarioFile) )
    {
        QMessageBox::warning(this, tr("Scenario Reader"),
                             tr("Parse error in file %1:\n\n%2")
                             .arg(filename)
                             .arg(scenario_reader.errorString()));
    }
    else
    {
        validateScenario();
        
        statusBar()->showMessage(tr("Scenario file loaded"), 2000);

        // Update scenarioView
        resetScenarioView();
        
        setBasicOperationsEnabled(true);
        
        ui->scenarioView->setAcceptDrops(true);
        ui->dataModelTree->setAcceptDrops(true);
        ui->computationalModelTree->setAcceptDrops(true);
    }

    currentScenarioFile.close();
}


void SunprismScenarioManagerMainWindow::validateScenario()
{
    // TODO: Need to validate and remove invalid model instances
    
    for( int i = 0; i < scenario.getDataModelInstanceList()->size(); i++ )
    {
        DataModelInstance *data_model_instance = scenario.getDataModelInstanceList()->value(i);
        
        QMap<QString, QString> *field_value_list = data_model_instance->getFieldValueList();
        
        DataModel *data_model = dataModelList.value(field_value_list->value("model"));
        
        if( data_model == NULL )
        {
            // TODO: need to remove the model instance from the list
        }
        else
        {
            QMap<QString, QString> *model_field_value_list = data_model->getFieldValueList();
        
            QString icon_file = QString("%1/%2/%3")
                                .arg(dataModelPath)
                                .arg(model_field_value_list->value("name"))
                                .arg(model_field_value_list->value("icon"));
                                
            data_model_instance->resetPixmap(icon_file);

            // insert input parameter fields based on model definition
            
            QVector<Parameter> *input_parameter_list = data_model->getInputParameterList();
            
            for( int j = 0; j < input_parameter_list->size(); j++ )
            {
                Parameter input_parameter = input_parameter_list->value(j);
            
                if( field_value_list->find(input_parameter.getName()) == field_value_list->end() )
                {
                    field_value_list->insert(input_parameter.getName(), input_parameter.getDefaultValue());
                }
            }            
        }
    }
    
    for( int i = 0; i < scenario.getComputationalModelInstanceList()->size(); i++ )
    {
        ComputationalModelInstance *computational_model_instance = scenario.getComputationalModelInstanceList()->value(i);
        
        QMap<QString, QString> *field_value_list = computational_model_instance->getFieldValueList();
        
        ComputationalModel *computational_model = computationalModelList.value(field_value_list->value("model"));
        
        if( computational_model == NULL )
        {
            // TODO: need to remove the model instance from the list
        }
        else
        {
            QMap<QString, QString> *model_field_value_list = computational_model->getFieldValueList();
        
            QString icon_file = QString("%1/%2/%3")
                                .arg(computationalModelPath)
                                .arg(model_field_value_list->value("name"))
                                .arg(model_field_value_list->value("icon"));
                                
            computational_model_instance->resetPixmap(icon_file);

            // insert input parameter fields based on model definition
            
            QVector<Parameter> *input_parameter_list = computational_model->getInputParameterList();
            
            for( int j = 0; j < input_parameter_list->size(); j++ )
            {
                Parameter input_parameter = input_parameter_list->value(j);
            
                if( field_value_list->find(input_parameter.getName()) == field_value_list->end() )
                {
                    field_value_list->insert(input_parameter.getName(), input_parameter.getDefaultValue());
                }
            }    
        }
    }    
}


void SunprismScenarioManagerMainWindow::saveScenario()
{
    if( !currentScenarioFile.fileName().isEmpty() )
    {
        if( !currentScenarioFile.open(QFile::WriteOnly | QFile::Text) )
        {
            QMessageBox::warning(this, tr("Scenario Writer"),
                                 tr("Cannot write file %1:\n%2.")
                                 .arg(currentScenarioFile.fileName())
                                 .arg(currentScenarioFile.errorString()));
            return;
        }
    
        ScenarioWriter scenario_writer( &scenario, &dataModelList, &computationalModelList );
        if( scenario_writer.writeScenario(&currentScenarioFile) )
        {
            statusBar()->showMessage(tr("File saved"), 2000);
        }

        currentScenarioFile.close();
    }
}


void SunprismScenarioManagerMainWindow::saveScenarioAs()
{
    QString file_name =
            QFileDialog::getSaveFileName( this, tr("Save Scenario File"),
                                          QDir::currentPath(),
                                          tr("SCN Files (*.scn)") );
            
    if( file_name.isEmpty() )
    {
        return;
    }

    currentScenarioFile.setFileName(file_name);
    if( !currentScenarioFile.open(QFile::WriteOnly | QFile::Text) )
    {
        QMessageBox::warning( this, tr("Scenario Writer"),
                              tr("Cannot write file %1:\n%2.")
                              .arg(file_name)
                              .arg(currentScenarioFile.errorString()) );
        return;
    }

    ScenarioWriter scenario_writer( &scenario, &dataModelList, &computationalModelList );
    if( scenario_writer.writeScenario(&currentScenarioFile) )
    {
        statusBar()->showMessage(tr("File saved"), 2000);
    }
    
    currentScenarioFile.close();

    // enable save
    ui->menuActionSave->setEnabled(true);
    ui->toolbarActionSave->setEnabled(true);
}


void SunprismScenarioManagerMainWindow::closeScenario()
{
    scenario.clearModelInstanceList();
    
    initializeScenarioView();
    
    setBasicOperationsEnabled(false);
    
    ui->scenarioView->setAcceptDrops(false);
    ui->dataModelTree->setAcceptDrops(false);
    ui->computationalModelTree->setAcceptDrops(false);
    
    updatePropertyTable();
}


void SunprismScenarioManagerMainWindow::runScenario()
{    
    pythonConsole->show();

	scenarioExecutor.setModelList(&dataModelList, &computationalModelList);
	scenarioExecutor.setScenario(&scenario);
	
	scenarioExecutor.executeScenario();
	
    scenarioExecutionTimer->start();
}


void SunprismScenarioManagerMainWindow::modelInstanceExecutionStarted(ModelInstance* model_instance)
{
    progressBarWidget->setParentItem(model_instance);
    
    QPointF position;
    position.setX(-progressBarWidget->size().width()/2);
    position.setY(model_instance->boundingRect().height()/2 + 5);
    
    progressBarWidget->setPos(position);
    
    ProgressIndicator *progress_indicator = new ProgressIndicator();
    currentProgressIndicator = progress_indicator;
    
    currentProgressIndicator->setParentItem(model_instance);
    currentProgressIndicator->setPos(0, 100);
    
    executionStartTime = QTime::currentTime();
}


void SunprismScenarioManagerMainWindow::evaluatingScript(QString script)
{
    pythonConsole->append(script + "\n");
}



void SunprismScenarioManagerMainWindow::updateScenarioExecution()
{
    if( currentProgressIndicator )
    {
        int ms_elapsed = executionStartTime.msecsTo(QTime::currentTime());
        int s  = ms_elapsed / 1000;
        int m  = s  / 60;      s  %= 60;
        int h  = m  / 60;      m  %= 60;
        QString time_string = QString("%1:%2:%3")
                                .arg(h, 2, 10, QChar('0'))
                                .arg(m, 2, 10, QChar('0'))
                                .arg(s, 2, 10, QChar('0'));
        currentProgressIndicator->setText(time_string);
        
        currentProgressIndicator->setAngle(ms_elapsed/10);
    }
}


void SunprismScenarioManagerMainWindow::modelInstanceExecutionFinished(ModelInstance* model_instance)
{
    if( currentProgressIndicator )
    {
        currentProgressIndicator->setMode(1);
    }
}


void SunprismScenarioManagerMainWindow::scenarioExecutionFinished()
{
    progressBarWidget->setVisible(false);
    
    scenarioExecutionTimer->stop();
}


void SunprismScenarioManagerMainWindow::exportExecutable()
{
    QString output_filename =
            QFileDialog::getSaveFileName( this, tr("Export Executable"),
                                          QDir::currentPath(),
                                          tr("Python Files (*.py)") );
            
    if( output_filename.isEmpty() )
    {
        return;
    }
    
    QFile output_file(output_filename);
    
    if( !output_file.open(QFile::WriteOnly | QFile::Text) )
    {
        QMessageBox::warning(this, tr("Export Executable"),
                             tr("Cannot write file %1:\n%2.")
                             .arg(output_file.fileName())
                             .arg(output_file.errorString()));
        return;
    }
    
    QTextStream out(&output_file);
    
	scenarioExecutor.setModelList(&dataModelList, &computationalModelList);
	scenarioExecutor.setScenario(&scenario);
	
    out << scenarioExecutor.generateExecutableScript();

    statusBar()->showMessage(tr("Executable saved"), 2000);

    output_file.close();
}


void SunprismScenarioManagerMainWindow::initializeScenarioView()
{
    scenario.clear();
    
    scenario.setSceneRect(300, 300, 1, 1);

    ui->scenarioView->setScene(&scenario);

    ui->scenarioView->resetTransform();
    
    ui->scenarioView->setBackgroundBrush(QPixmap("image/sunprism_background.png"));
    
    ui->scenarioView->setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);
    ui->scenarioView->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
    
    ui->scenarioView->setDragMode(QGraphicsView::NoDrag);
}


void SunprismScenarioManagerMainWindow::resetScenarioView()
{
    resetGraphicsScene();

    ui->scenarioView->resetTransform();
    
    ui->scenarioView->setBackgroundBrush(Qt::NoBrush);

    QRectF items_bounding_rect = scenario.visibleItemsBoundingRect();
    
    if( !items_bounding_rect.isEmpty() )
    {
        ui->scenarioView->centerOn(items_bounding_rect.x() + ui->scenarioView->width()/2, items_bounding_rect.y() + ui->scenarioView->height()/2);
    }
    else
    {
        ui->scenarioView->centerOn(scenario.width()/2, scenario.height()/2);
    }
    
    ui->scenarioView->setDragMode(QGraphicsView::ScrollHandDrag);
}


void SunprismScenarioManagerMainWindow::resetGraphicsScene()
{
    scenario.resetGraphicsScene();
    
	QProgressBar *progressBar = new QProgressBar();
    progressBar->resize(125, 15);
	progressBar->setOrientation(Qt::Horizontal);
	progressBar->setRange(0, 0); // marquee-style progress bar
	
	progressBarWidget = scenario.addWidget(progressBar);
	progressBarWidget->setVisible(false);

    return;
}


void SunprismScenarioManagerMainWindow::zoomIn()
{
    ui->scenarioView->scale(1.1, 1.1);
}


void SunprismScenarioManagerMainWindow::zoomOut()
{
    ui->scenarioView->scale(0.9, 0.9);
}


void SunprismScenarioManagerMainWindow::toggleFullScreen()
{
    if( !isFullScreen() )
    {
        showFullScreen();
    }
    else
    {
        showNormal();
    }
    
    ui->menuActionFullScreen->setChecked(isFullScreen());
}


void SunprismScenarioManagerMainWindow::toggleGrid()
{
    scenario.setDrawGrid(!scenario.getDrawGrid());
    
    // make sure to redraw the background with/without grid
    ui->scenarioView->viewport()->update();
    
    ui->menuActionGrid->setChecked(scenario.getDrawGrid());
}


void SunprismScenarioManagerMainWindow::toggleSnapToGrid()
{
    scenario.setSnapToGrid(!scenario.getSnapToGrid());
    
    ui->menuActionSnapToGrid->setChecked(scenario.getSnapToGrid());
}


void SunprismScenarioManagerMainWindow::scenarioSelectionChanged()
{
    updatePropertyTable();
}


void SunprismScenarioManagerMainWindow::updatePropertyTable()
{
    ModelInstance *selected_model_instance = NULL;
    Model *selected_model_instance_model = NULL;
    
    if( scenario.selectedItems().size() == 1 )
    {
        selected_model_instance = dynamic_cast<ModelInstance*>(scenario.selectedItems().first());
        
        if( dynamic_cast<DataModelInstance*>(selected_model_instance) != NULL )
        {
            selected_model_instance_model = dataModelList.value(selected_model_instance->getFieldValueList()->value("model"));
        }
        else if( dynamic_cast<ComputationalModelInstance*>(selected_model_instance) != NULL )
        {
            selected_model_instance_model = computationalModelList.value(selected_model_instance->getFieldValueList()->value("model"));
        }
    }
    
    if( selected_model_instance != NULL && selected_model_instance_model != NULL )
    {
        QVector<Parameter> *input_parameter_list = selected_model_instance_model->getInputParameterList();
        
        QMap<int, Parameter> sorted_parameter_map;
        for( int j = 0; j < input_parameter_list->size(); j++ )
        {
            Parameter input_parameter = input_parameter_list->value(j);
        
            sorted_parameter_map.insertMulti(input_parameter.getOrder(), input_parameter);
        } 
        
        QMap<QString, QString> *field_value_list = selected_model_instance->getFieldValueList();
        
        QMap<QString, QString>::const_iterator field_value_iterator = field_value_list->constBegin();
         
        ui->propertyTable->horizontalHeader()->show();
        ui->propertyTable->setRowCount(sorted_parameter_map.size()+2);
        
        int row_count = 0;
     
        QTableWidgetItem *field_item_model = new QTableWidgetItem("model");
        ui->propertyTable->setItem(row_count, 0, field_item_model);

        field_item_model->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);
        field_item_model->setBackground(QBrush(QColor(209, 235, 241, 255)));
        QFont font_model(field_item_model->font());
        font_model.setBold(true);
        field_item_model->setFont(font_model);
        
        QTableWidgetItem *value_item_model = new QTableWidgetItem(field_value_list->value("model"));
        value_item_model->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);  // ^Qt::ItemIsEditable
        ui->propertyTable->setItem(row_count, 1, value_item_model);
        
        ++row_count;
        
        QTableWidgetItem *field_item_name = new QTableWidgetItem("name");
        ui->propertyTable->setItem(row_count, 0, field_item_name);

        field_item_name->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);
        field_item_name->setBackground(QBrush(QColor(209, 235, 241, 255)));
        QFont font_name(field_item_name->font());
        font_name.setBold(true);
        field_item_name->setFont(font_name);
        
        QTableWidgetItem *value_item_name = new QTableWidgetItem(field_value_list->value("name"));
        ui->propertyTable->setItem(row_count, 1, value_item_name);
        
        ++row_count;
        
        QMap<int, Parameter>::const_iterator input_parameter_iterator = sorted_parameter_map.constBegin();
        
        while( input_parameter_iterator != sorted_parameter_map.constEnd() )
        {
            Parameter input_parameter = input_parameter_iterator.value();
            
            QTableWidgetItem *field_item = new QTableWidgetItem(input_parameter.getName());
            ui->propertyTable->setItem(row_count, 0, field_item);

            field_item->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);
            field_item->setBackground(QBrush(QColor(209, 235, 241, 255)));
            QFont font(field_item->font());
            font.setBold(true);
            field_item->setFont(font);
            
            QTableWidgetItem *value_item = new QTableWidgetItem(field_value_list->value(input_parameter.getName()));
            ui->propertyTable->setItem(row_count, 1, value_item);
    
            ++row_count;
            
            ++input_parameter_iterator;
        }
    }
    else
    {
        ui->propertyTable->horizontalHeader()->hide();
        ui->propertyTable->setRowCount(0);
    }
}


void SunprismScenarioManagerMainWindow::propertyTableItemChanged(QTableWidgetItem *item)
{
    if( item->column() == 1 )
    {
        if( scenario.selectedItems().size() == 1 )
        {
            QTableWidgetItem *field_item = ui->propertyTable->item(item->row(), 0);
        
            ModelInstance *selected_model_instance = (ModelInstance*)scenario.selectedItems().first();
            
            QMap<QString, QString> *field_value_list = selected_model_instance->getFieldValueList();
            
            field_value_list->insert(field_item->text(), item->text());
        }
    }
}


void SunprismScenarioManagerMainWindow::scenarioViewModelDropped(QString tree_object, QString model, QPointF position)
{
    if( tree_object == "dataModelTree" )
    {
        DataModel *data_model = dataModelList.value(model);
    
        if( data_model != NULL )
        {
            QString model_instance_name = getAvailableModelInstanceName(model, "DataModel");
            
            DataModelInstance *data_model_instance = new DataModelInstance();
            
            data_model_instance->getFieldValueList()->insert("name", model_instance_name);
            data_model_instance->getFieldValueList()->insert("model", model);
            data_model_instance->getFieldValueList()->insert("x", QString::number(position.x()));
            data_model_instance->getFieldValueList()->insert("y", QString::number(position.y()));
            
            scenario.getDataModelInstanceList()->append(data_model_instance);
        
            scenario.addItem(data_model_instance);
            
            data_model_instance->setPos(position);
            
            validateScenario();
        }
    }
    if( tree_object == "computationalModelTree" )
    {
        ComputationalModel *computational_model = computationalModelList.value(model);
        
        if( computational_model != NULL )
        {
            QString model_instance_name = getAvailableModelInstanceName(model, "ComputationalModel");
            
            ComputationalModelInstance *computational_model_instance = new ComputationalModelInstance();
            
            computational_model_instance->getFieldValueList()->insert("name", model_instance_name);
            computational_model_instance->getFieldValueList()->insert("model", model);
            computational_model_instance->getFieldValueList()->insert("x", QString::number(position.x()));
            computational_model_instance->getFieldValueList()->insert("y", QString::number(position.y()));
            
            scenario.getComputationalModelInstanceList()->append(computational_model_instance);
        
            scenario.addItem(computational_model_instance);
            
            computational_model_instance->setPos(position);
            
            validateScenario();
        }
    }
}


QString SunprismScenarioManagerMainWindow::getAvailableModelInstanceName(QString model, QString model_type)
{
    QString model_instance_name = model + "_instance";
    bool unique_name_found = false;
    int model_instance_name_number = 1;
    
    QVector<ModelInstance*> *model_instance_list = NULL;
    
    if( model_type == "DataModel" )
    {
        model_instance_list = (QVector<ModelInstance*> *)scenario.getDataModelInstanceList();
    }
    else if( model_type == "ComputationalModel" )
    {
        model_instance_list = (QVector<ModelInstance*> *)scenario.getComputationalModelInstanceList();
    }
    
    if( model_instance_list != NULL )
    {
        while( !unique_name_found )
        {
            bool same_name_exists = false;
    
            for( int i = 0; i < model_instance_list->size(); i++ )
            {
                if( model_instance_list->value(i)->getFieldValueList()->value("name") == model_instance_name )
                {
                    same_name_exists = true;
                }
            }
            
            if( same_name_exists )
            {
                ++model_instance_name_number;
                model_instance_name = model + "_instance_" + QString::number(model_instance_name_number);
            }
            else
            {
                unique_name_found = true;
            }
        }
    }
    
    return model_instance_name;
}


void SunprismScenarioManagerMainWindow::scenarioViewDeleteSelectedItems()
{
    QVector<ModelInstanceConnection*> delete_model_instance_connection_list;
    QVector<ModelInstance*> delete_model_instance_list;
    
    foreach( QGraphicsItem *item, scenario.selectedItems() )
    {
        ModelInstance *model_instance = dynamic_cast<ModelInstance*>(item);
     
        if( model_instance != NULL )
        {
            for( int i = 0; i < model_instance->getModelInstanceConnectionList()->size(); i++ )
            {
                ModelInstanceConnection *model_instance_connection = model_instance->getModelInstanceConnectionList()->value(i);
                
                if( !delete_model_instance_connection_list.contains(model_instance_connection) )
                {
                    delete_model_instance_connection_list.append(model_instance_connection);
                }
            }
            
            delete_model_instance_list.append(model_instance);
        }
        
        ModelInstanceConnection *model_instance_connection = dynamic_cast<ModelInstanceConnection*>(item);
        
        if( !delete_model_instance_connection_list.contains(model_instance_connection) )
        {
            delete_model_instance_connection_list.append(model_instance_connection);
        }
    }
    
    for( int i = 0; i < delete_model_instance_connection_list.size(); i++ )
    {
        ModelInstanceConnection *model_instance_connection = delete_model_instance_connection_list.value(i);
        
        scenario.removeItem(model_instance_connection);
        delete model_instance_connection;
    }    
    
    for( int i = 0; i < delete_model_instance_list.size(); i++ )
    {
        ModelInstance *model_instance = delete_model_instance_list.value(i);
        
        int index_of_data_model_instance = scenario.getDataModelInstanceList()->indexOf(dynamic_cast<DataModelInstance*>(model_instance));
  
        if( index_of_data_model_instance >= 0 )
        {
            scenario.getDataModelInstanceList()->remove(index_of_data_model_instance);
        }
        
        int index_of_computational_model_instance = scenario.getComputationalModelInstanceList()->indexOf(dynamic_cast<ComputationalModelInstance*>(model_instance));
  
        if( index_of_computational_model_instance >= 0 )
        {
            scenario.getComputationalModelInstanceList()->remove(index_of_computational_model_instance);
        }
        
        scenario.removeItem(model_instance);
        delete model_instance;
    }    
}


void SunprismScenarioManagerMainWindow::registerDataModel()
{
    DataModelRegistrationDialog dataModelRegistrationDialog;
    
    dataModelRegistrationDialog.exec();
    
    if( dataModelRegistrationDialog.result() )
    {
        QString data_model_name = dataModelRegistrationDialog.getNameEdit()->text();
        
        if( !data_model_name.isEmpty() )
        {
            QDir data_model_directory(dataModelPath);
        
            data_model_directory.mkdir(data_model_name);
            
            if( data_model_directory.cd(data_model_name) )
            {
                // create empty python init file (__init.py)
                QFile python_init_file(data_model_directory.absoluteFilePath("__init__.py"));
                python_init_file.open(QFile::WriteOnly | QFile::Text);
                python_init_file.close();
                
                // copy icon file, and change the absolute file path to filename 
                
                QString icon_file = dataModelRegistrationDialog.getIconFileEdit()->text();
                   
                QFileInfo icon_file_info(icon_file);
                QString icon_file_name = icon_file_info.fileName();

                QFile::copy(icon_file, data_model_directory.absoluteFilePath(icon_file_name));

                dataModelRegistrationDialog.getIconFileEdit()->setText(icon_file_name);
                
                // copy api file, and change the absolute file path to filename 
                
                QString api_file = dataModelRegistrationDialog.getApiFileEdit()->text();
                
                QFileInfo api_file_info(api_file);
                QString api_file_name = api_file_info.fileName();

                QFile::copy(api_file, data_model_directory.absoluteFilePath(api_file_name));

                dataModelRegistrationDialog.getApiFileEdit()->setText(api_file_name);
                
                // create data model file (.dtm)
                QString data_model_file_name = data_model_directory.absoluteFilePath(data_model_name + ".dtm");
            
                QFile data_model_file(data_model_file_name);
                if( !data_model_file.open(QFile::WriteOnly | QFile::Text) )
                {
                    QMessageBox::warning( this, tr("Data Model Writer"),
                                          tr("Cannot write file %1:\n%2.")
                                          .arg(data_model_file_name)
                                          .arg(data_model_file.errorString()) );
                    return;
                }
            
                DataModelWriter data_model_writer( &dataModelRegistrationDialog );
                if( data_model_writer.writeDataModel(&data_model_file) )
                {
                    statusBar()->showMessage(tr("Data Model registered"), 2000);
                }
                
                data_model_file.close();
            }
        }
    }
}


void SunprismScenarioManagerMainWindow::registerComputationalModel()
{
    ComputationalModelRegistrationDialog computationalModelRegistrationDialog;
    
    computationalModelRegistrationDialog.exec();
    
    if( computationalModelRegistrationDialog.result() )
    {
        QString computational_model_name = computationalModelRegistrationDialog.getNameEdit()->text();
        
        if( !computational_model_name.isEmpty() )
        {
            QDir computational_model_directory(computationalModelPath);
        
            computational_model_directory.mkdir(computational_model_name);
            
            if( computational_model_directory.cd(computational_model_name) )
            {
                // create empty python init file (__init.py)
                QFile python_init_file(computational_model_directory.absoluteFilePath("__init__.py"));
                python_init_file.open(QFile::WriteOnly | QFile::Text);
                python_init_file.close();
                
                // copy icon file, and change the absolute file path to filename 
                
                QString icon_file = computationalModelRegistrationDialog.getIconFileEdit()->text();
                   
                QFileInfo icon_file_info(icon_file);
                QString icon_file_name = icon_file_info.fileName();

                QFile::copy(icon_file, computational_model_directory.absoluteFilePath(icon_file_name));

                computationalModelRegistrationDialog.getIconFileEdit()->setText(icon_file_name);
                
                // copy api file, and change the absolute file path to filename 
                
                QString api_file = computationalModelRegistrationDialog.getApiFileEdit()->text();
                
                QFileInfo api_file_info(api_file);
                QString api_file_name = api_file_info.fileName();

                QFile::copy(api_file, computational_model_directory.absoluteFilePath(api_file_name));

                computationalModelRegistrationDialog.getApiFileEdit()->setText(api_file_name);
                
                // create computational model file (.cpm)
                QString computational_model_file_name = computational_model_directory.absoluteFilePath(computational_model_name + ".cpm");
            
                QFile computational_model_file(computational_model_file_name);
                if( !computational_model_file.open(QFile::WriteOnly | QFile::Text) )
                {
                    QMessageBox::warning( this, tr("Computational Model Writer"),
                                          tr("Cannot write file %1:\n%2.")
                                          .arg(computational_model_file_name)
                                          .arg(computational_model_file.errorString()) );
                    return;
                }
            
                ComputationalModelWriter computational_model_writer( &computationalModelRegistrationDialog );
                if( computational_model_writer.writeComputationalModel(&computational_model_file) )
                {
                    statusBar()->showMessage(tr("Computational Model registered"), 2000);
                }
                
                computational_model_file.close();
            }
        }
    }
}

