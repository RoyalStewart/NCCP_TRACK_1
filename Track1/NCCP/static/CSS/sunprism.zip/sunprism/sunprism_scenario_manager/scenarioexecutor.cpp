/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scenarioexecutor.h"


ScenarioExecutor::ScenarioExecutor(QObject *parent) :
    QThread(parent)
{
    PythonQt::init(PythonQt::RedirectStdOut);
    
    // get a smart pointer to the __main__ module of the Python interpreter
    pythonModule = PythonQt::self()->getMainModule();

    // add current working directory to the sys path, so that dynamic import works
    pythonModule.evalScript("import os, sys\nsys.path.append(os.getcwd())\n");
    
    scriptGenerationMode = false;
}


PythonQtObjectPtr* ScenarioExecutor::getModule()
{
    return &pythonModule;
}


void ScenarioExecutor::setModelList(QMap<QString, DataModel*> *data_model_list, QMap<QString, ComputationalModel*> *computational_model_list)
{
    dataModelList = data_model_list;
    computationalModelList = computational_model_list;
}


void ScenarioExecutor::setScenario(Scenario *scenario)
{
    this->scenario = scenario;
}


void ScenarioExecutor::executeScenario()
{    
    if( scenario && dataModelList && computationalModelList )
    {
        scriptGenerationMode = false;
        
        // start() intiates a new thread
        // new thread starts with run(), which calls execute()
        start();
    }
}


QString ScenarioExecutor::generateExecutableScript()
{    
    if( scenario && dataModelList && computationalModelList )
    {
        scriptGenerationMode = true;
        
        executableScript = "";
        
        execute();
        
        return executableScript;
    }
}


void ScenarioExecutor::run()
{
    execute();
}


void ScenarioExecutor::execute()
{    
    QString python_script;

    sortModelInstanceList();
    
    
    python_script = generateLoadingScript();
    evalScript(python_script);
    
    
    // load all data model instances. computational model instances need them beforehand
    for( int i = 0; i < sortedModelInstanceList.size(); i++ )
    {
        DataModelInstance *data_model_instance = dynamic_cast<DataModelInstance*>(sortedModelInstanceList.value(i));
        if( data_model_instance != NULL )
        {
            QString instance_name = data_model_instance->getFieldValueList()->value("name");
            QString model_name = data_model_instance->getFieldValueList()->value("model");
            
            // quick convention to get the class name
            model_name[0] = model_name[0].toUpper();
            
            python_script = QString("%1 = %2()").arg(instance_name).arg(model_name);
            evalScript(python_script);
    
            QMap<QString, QString> *field_value_list = data_model_instance->getFieldValueList();
    
            QMap<QString, QString>::const_iterator field_value_iterator = field_value_list->constBegin();
    
            while (field_value_iterator != field_value_list->constEnd())
            {
                python_script = QString("%1.fieldValueList[\"%2\"] = \"%3\"").arg(instance_name).arg(field_value_iterator.key()).arg(field_value_iterator.value());
                evalScript(python_script);
        
                ++field_value_iterator;
            }
            
            python_script = QString("%1.init()").arg(instance_name);
            evalScript(python_script);
        }
    }

    
    // load and execute computational model objects
    for( int i = 0; i < sortedModelInstanceList.size(); i++ )
    {
        ComputationalModelInstance *computational_model_instance = dynamic_cast<ComputationalModelInstance*>(sortedModelInstanceList.value(i));
        if( computational_model_instance != NULL )
        {
            emit modelInstanceExecutionStarted(computational_model_instance);
            
            QString instance_name = computational_model_instance->getFieldValueList()->value("name");
            QString model_name = computational_model_instance->getFieldValueList()->value("model");
            
            // quick convention to get the class name
            QString model_class_name(model_name);
            model_class_name[0] = model_class_name[0].toUpper();
            
            python_script = QString("%1 = %2()").arg(instance_name).arg(model_class_name);
            evalScript(python_script);
    
            QMap<QString, QString> *field_value_list = computational_model_instance->getFieldValueList();
    
            QMap<QString, QString>::const_iterator field_value_iterator = field_value_list->constBegin();
    
            while (field_value_iterator != field_value_list->constEnd())
            {
                python_script = QString("%1.fieldValueList[\"%2\"] = \"%3\"").arg(instance_name).arg(field_value_iterator.key()).arg(field_value_iterator.value());
                evalScript(python_script);
        
                ++field_value_iterator;
            }
            
            QVector<ModelInstanceConnection*> *model_instance_connection_list = computational_model_instance->getModelInstanceConnectionList();
            
            for( int j = 0; j < model_instance_connection_list->size(); j++ )
            {
                ModelInstanceConnection *model_instance_connection = model_instance_connection_list->value(j);
                    
                ModelInstance *source_model_instance = model_instance_connection->getSourceModelInstance();
                ModelInstance *destination_model_instance = model_instance_connection->getDestinationModelInstance();
                
                ComputationalModel *computational_model = computationalModelList->value(model_name);
                    
                // input connection
                if( destination_model_instance == computational_model_instance )
                {
                    QMap<QString, QString> *model_instance_field_value_list = source_model_instance->getFieldValueList();
                    
                    QString data_model_name = model_instance_field_value_list->value("model");
                                            
                    // TODO: Should be changed to QMap pointer
                    QMap<QString, QString> input_data_model_field_value_list;                                         
    
                    QMap< QString, QMap<QString, QString> > *input_data_model_list = computational_model->getInputDataModelList();
                    
                    QMap<QString, QMap<QString, QString> >::const_iterator input_data_model_iterator = input_data_model_list->constBegin();
                    
                    while( input_data_model_iterator != input_data_model_list->constEnd() && input_data_model_field_value_list.size() == 0 )
                    {
                        if( input_data_model_iterator.value().value("model") == data_model_name )
                        {
                            input_data_model_field_value_list = input_data_model_iterator.value();
                        }
                        
                        ++input_data_model_iterator;
                    }
                    
                    if( input_data_model_field_value_list.size() > 0 )
                    {
                        python_script = QString("%1.inputDataModelList[\"%2\"] = %3").arg(instance_name).arg(input_data_model_field_value_list.value("name")).arg(model_instance_field_value_list->value("name"));
                        evalScript(python_script);
                    }
                }
                // output connection
                else if( source_model_instance == computational_model_instance )
                {
                    QMap<QString, QString> *model_instance_field_value_list = destination_model_instance->getFieldValueList();
                    
                    QString data_model_name = model_instance_field_value_list->value("model");
                                            
                    // TODO: Should be changed to QMap pointer
                    QMap<QString, QString> output_data_model_field_value_list;                                         
    
                    QMap< QString, QMap<QString, QString> > *output_data_model_list = computational_model->getOutputDataModelList();
                    
                    QMap<QString, QMap<QString, QString> >::const_iterator output_data_model_iterator = output_data_model_list->constBegin();
                    
                    while( output_data_model_iterator != output_data_model_list->constEnd() && output_data_model_field_value_list.size() == 0 )
                    {
                        if( output_data_model_iterator.value().value("model") == data_model_name )
                        {
                            output_data_model_field_value_list = output_data_model_iterator.value();
                        }
                        
                        ++output_data_model_iterator;
                    }
                    
                    if( output_data_model_field_value_list.size() > 0 )
                    {
                        python_script = QString("%1.outputDataModelList[\"%2\"] = %3").arg(instance_name).arg(output_data_model_field_value_list.value("name")).arg(model_instance_field_value_list->value("name"));
                        evalScript(python_script);
                    }
                }
            }
            
            python_script = QString("%1.run()").arg(instance_name);
            evalScript(python_script);
            emit modelInstanceExecutionFinished(computational_model_instance);
        }    
    }
}


void ScenarioExecutor::sortModelInstanceList()
{
    sortedModelInstanceList.clear();
    
    // sortedModelInstanceList: empty list to store sorted model instances
    
    // sort model instances in a topological order (Tarjan's algorithm)
    // edge direction is considered reverse for the job dependency
    
    // start sort with a list of all model instances that has no depending connections (by other)
    QVector<ModelInstance*> model_instance_list;

    for( int i = 0; i < scenario->getDataModelInstanceList()->size(); i++ )
    {
        ModelInstance *model_instance = scenario->getDataModelInstanceList()->value(i);
        
        bool has_incoming_connection = false;
        
        QVector<ModelInstanceConnection*> *model_instance_connection_list = model_instance->getModelInstanceConnectionList();
        
        for( int j = 0; j < model_instance_connection_list->size(); j++ )
        {
            ModelInstanceConnection *model_instance_connection = model_instance_connection_list->value(j);
                
            ModelInstance *source_model_instance = model_instance_connection->getSourceModelInstance();
            ModelInstance *destination_model_instance = model_instance_connection->getDestinationModelInstance();
            
            // has depending connection (by other)
            if( source_model_instance == model_instance )
            {
                has_incoming_connection = true;
            }
        }
        
        if( !has_incoming_connection )
        {
            model_instance_list.append(model_instance);
        }
    }
    
    for( int i = 0; i < scenario->getComputationalModelInstanceList()->size(); i++ )
    {
        ModelInstance *model_instance = scenario->getComputationalModelInstanceList()->value(i);
        
        bool has_incoming_connection = false;
        
        QVector<ModelInstanceConnection*> *model_instance_connection_list = model_instance->getModelInstanceConnectionList();
        
        for( int j = 0; j < model_instance_connection_list->size(); j++ )
        {
            ModelInstanceConnection *model_instance_connection = model_instance_connection_list->value(j);
                
            ModelInstance *source_model_instance = model_instance_connection->getSourceModelInstance();
            ModelInstance *destination_model_instance = model_instance_connection->getDestinationModelInstance();
            
            // has depending connection (by other)
            if( source_model_instance == model_instance )
            {
                has_incoming_connection = true;
            }
        }
        
        if( !has_incoming_connection )
        {
            model_instance_list.append(model_instance);
        }
    }
    
    // keep track of visited model instances
    QVector<ModelInstance*> visited_model_instance_list;
    
    // sort visit for each model instance in model_instance_list
    for( int i = 0; i < model_instance_list.size(); i++ )
    {
        sortVisitModelInstanceList(model_instance_list.value(i), &visited_model_instance_list);
    }
}


void ScenarioExecutor::sortVisitModelInstanceList(ModelInstance *model_instance, QVector<ModelInstance*> *visited_model_instance_list)
{
    // if model_instance has not been visited yet
    if( visited_model_instance_list->indexOf(model_instance) < 0 ) 
    {
        // mark it as visited
        visited_model_instance_list->append(model_instance);
        
        // for each model instance that model_instance depends
        
        QVector<ModelInstanceConnection*> *model_instance_connection_list = model_instance->getModelInstanceConnectionList();
        
        for( int j = 0; j < model_instance_connection_list->size(); j++ )
        {
            ModelInstanceConnection *model_instance_connection = model_instance_connection_list->value(j);
                
            ModelInstance *source_model_instance = model_instance_connection->getSourceModelInstance();
            ModelInstance *destination_model_instance = model_instance_connection->getDestinationModelInstance();
            
            // depending connection
            if( destination_model_instance == model_instance )
            {
                // sort visit destination_model_instance
                sortVisitModelInstanceList(source_model_instance, visited_model_instance_list);
            }
        }
        
        sortedModelInstanceList.append(model_instance);
    }
}


QString ScenarioExecutor::generateLoadingScript()
{
    // get list of data models used in current scenario
    QList<Model*> data_model_list;
    
    for( int i = 0; i < scenario->getDataModelInstanceList()->size(); i++ )
    {
        DataModelInstance *data_model_instance = scenario->getDataModelInstanceList()->value(i);
        
        QMap<QString, QString> *field_value_list = data_model_instance->getFieldValueList();
        
        DataModel *data_model = dataModelList->value(field_value_list->value("model"));
        
        if( data_model_list.indexOf(data_model) < 0 )
        {
            data_model_list.append(data_model);
        }
    }
    
    // get list of computational models used in current scenario
    QList<Model*> computational_model_list;
    
    for( int i = 0; i < scenario->getComputationalModelInstanceList()->size(); i++ )
    {
        ComputationalModelInstance *computational_model_instance = scenario->getComputationalModelInstanceList()->value(i);
        
        QMap<QString, QString> *field_value_list = computational_model_instance->getFieldValueList();
        
        ComputationalModel *computational_model = computationalModelList->value(field_value_list->value("model"));
        
        if( computational_model_list.indexOf(computational_model) < 0 )
        {
            computational_model_list.append(computational_model);
        }
    }    
    
    QString script;
    
    // model files should be loaded only once
    for( int i = 0; i < data_model_list.size(); i++ )
    {
        Model *data_model = data_model_list[i];
        
        QMap<QString, QString> *field_value_list = data_model->getFieldValueList();

        QString api_file = QString("%1/%2/%3")
                            .arg(field_value_list->value("path"))
                            .arg(field_value_list->value("name"))
                            .arg(field_value_list->value("api"));
                            
        script.append(QString("from %1 import *\n").arg(api_file.split(".")[0].replace("/", ".")));
    }
    
    for( int i = 0; i < computational_model_list.size(); i++ )
    {
        Model *computational_model = computational_model_list[i];
        
        QMap<QString, QString> *field_value_list = computational_model->getFieldValueList();

        QString api_file = QString("%1/%2/%3")
                            .arg(field_value_list->value("path"))
                            .arg(field_value_list->value("name"))
                            .arg(field_value_list->value("api"));
                            
        script.append(QString("from %1 import *\n").arg(api_file.split(".")[0].replace("/", ".")));
    }
    
    return script;
}


void ScenarioExecutor::evalScript(const QString& script)
{
    if( scriptGenerationMode )
    {
        executableScript.append(script + "\n");
    }
    else
    {
        emit evaluatingScript(script);
        
        pythonModule.evalScript(script);
    }
}

