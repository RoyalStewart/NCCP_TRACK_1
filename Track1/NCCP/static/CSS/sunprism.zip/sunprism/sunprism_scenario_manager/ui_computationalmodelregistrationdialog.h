/********************************************************************************
** Form generated from reading UI file 'computationalmodelregistrationdialog.ui'
**
** Created: Thu Sep 13 19:00:06 2012
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COMPUTATIONALMODELREGISTRATIONDIALOG_H
#define UI_COMPUTATIONALMODELREGISTRATIONDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTabWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ComputationalModelRegistrationDialog
{
public:
    QDialogButtonBox *buttonBox;
    QTabWidget *tabWidget;
    QWidget *tab_7;
    QWidget *verticalLayoutWidget_8;
    QVBoxLayout *verticalLayout_9;
    QHBoxLayout *horizontalLayout_24;
    QLabel *label_11;
    QLineEdit *lineEdit_7;
    QSpacerItem *horizontalSpacer_23;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_5;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_5;
    QSpacerItem *horizontalSpacer_10;
    QSpacerItem *verticalSpacer_8;
    QHBoxLayout *horizontalLayout_25;
    QLabel *label_12;
    QLineEdit *lineEdit_8;
    QPushButton *pushButton_12;
    QSpacerItem *horizontalSpacer_24;
    QWidget *tab_8;
    QWidget *verticalLayoutWidget_9;
    QVBoxLayout *verticalLayout_10;
    QHBoxLayout *horizontalLayout_26;
    QTableWidget *tableWidget_9;
    QSpacerItem *horizontalSpacer_25;
    QHBoxLayout *horizontalLayout_27;
    QPushButton *pushButton_13;
    QSpacerItem *horizontalSpacer_26;
    QWidget *tab_9;
    QWidget *verticalLayoutWidget_10;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_28;
    QTableWidget *tableWidget_10;
    QSpacerItem *horizontalSpacer_27;
    QHBoxLayout *horizontalLayout_29;
    QPushButton *pushButton_14;
    QSpacerItem *horizontalSpacer_28;
    QWidget *tab_10;
    QWidget *verticalLayoutWidget_11;
    QVBoxLayout *verticalLayout_12;
    QHBoxLayout *horizontalLayout_30;
    QTableWidget *tableWidget_3;
    QSpacerItem *horizontalSpacer_29;
    QHBoxLayout *horizontalLayout_31;
    QPushButton *pushButton_15;
    QSpacerItem *horizontalSpacer_30;
    QSpacerItem *verticalSpacer_10;
    QCheckBox *checkBox;
    QWidget *tab_11;
    QWidget *verticalLayoutWidget_12;
    QVBoxLayout *verticalLayout_13;
    QHBoxLayout *horizontalLayout_32;
    QTableWidget *tableWidget_11;
    QSpacerItem *horizontalSpacer_31;
    QHBoxLayout *horizontalLayout_33;
    QPushButton *pushButton_16;
    QSpacerItem *horizontalSpacer_32;
    QSpacerItem *verticalSpacer_9;
    QCheckBox *checkBox_3;

    void setupUi(QDialog *ComputationalModelRegistrationDialog)
    {
        if (ComputationalModelRegistrationDialog->objectName().isEmpty())
            ComputationalModelRegistrationDialog->setObjectName(QString::fromUtf8("ComputationalModelRegistrationDialog"));
        ComputationalModelRegistrationDialog->resize(490, 280);
        buttonBox = new QDialogButtonBox(ComputationalModelRegistrationDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(10, 240, 141, 32));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(buttonBox->sizePolicy().hasHeightForWidth());
        buttonBox->setSizePolicy(sizePolicy);
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Save);
        buttonBox->setCenterButtons(true);
        tabWidget = new QTabWidget(ComputationalModelRegistrationDialog);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(10, 10, 471, 221));
        tab_7 = new QWidget();
        tab_7->setObjectName(QString::fromUtf8("tab_7"));
        verticalLayoutWidget_8 = new QWidget(tab_7);
        verticalLayoutWidget_8->setObjectName(QString::fromUtf8("verticalLayoutWidget_8"));
        verticalLayoutWidget_8->setGeometry(QRect(10, 10, 443, 118));
        verticalLayout_9 = new QVBoxLayout(verticalLayoutWidget_8);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        label_11 = new QLabel(verticalLayoutWidget_8);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        sizePolicy.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy);

        horizontalLayout_24->addWidget(label_11);

        lineEdit_7 = new QLineEdit(verticalLayoutWidget_8);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        QSizePolicy sizePolicy1(QSizePolicy::MinimumExpanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(lineEdit_7->sizePolicy().hasHeightForWidth());
        lineEdit_7->setSizePolicy(sizePolicy1);

        horizontalLayout_24->addWidget(lineEdit_7);

        horizontalSpacer_23 = new QSpacerItem(40, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_24->addItem(horizontalSpacer_23);


        verticalLayout_9->addLayout(horizontalLayout_24);

        verticalSpacer = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_9->addItem(verticalSpacer);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        label_5 = new QLabel(verticalLayoutWidget_8);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        sizePolicy.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy);

        horizontalLayout_11->addWidget(label_5);

        lineEdit_3 = new QLineEdit(verticalLayoutWidget_8);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        sizePolicy1.setHeightForWidth(lineEdit_3->sizePolicy().hasHeightForWidth());
        lineEdit_3->setSizePolicy(sizePolicy1);

        horizontalLayout_11->addWidget(lineEdit_3);

        pushButton_5 = new QPushButton(verticalLayoutWidget_8);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(pushButton_5->sizePolicy().hasHeightForWidth());
        pushButton_5->setSizePolicy(sizePolicy2);
        pushButton_5->setMinimumSize(QSize(50, 0));

        horizontalLayout_11->addWidget(pushButton_5);

        horizontalSpacer_10 = new QSpacerItem(200, 0, QSizePolicy::Minimum, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_10);


        verticalLayout_9->addLayout(horizontalLayout_11);

        verticalSpacer_8 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_9->addItem(verticalSpacer_8);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));
        label_12 = new QLabel(verticalLayoutWidget_8);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        sizePolicy.setHeightForWidth(label_12->sizePolicy().hasHeightForWidth());
        label_12->setSizePolicy(sizePolicy);

        horizontalLayout_25->addWidget(label_12);

        lineEdit_8 = new QLineEdit(verticalLayoutWidget_8);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        sizePolicy1.setHeightForWidth(lineEdit_8->sizePolicy().hasHeightForWidth());
        lineEdit_8->setSizePolicy(sizePolicy1);

        horizontalLayout_25->addWidget(lineEdit_8);

        pushButton_12 = new QPushButton(verticalLayoutWidget_8);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        sizePolicy2.setHeightForWidth(pushButton_12->sizePolicy().hasHeightForWidth());
        pushButton_12->setSizePolicy(sizePolicy2);
        pushButton_12->setMinimumSize(QSize(50, 0));

        horizontalLayout_25->addWidget(pushButton_12);

        horizontalSpacer_24 = new QSpacerItem(200, 0, QSizePolicy::Minimum, QSizePolicy::Minimum);

        horizontalLayout_25->addItem(horizontalSpacer_24);


        verticalLayout_9->addLayout(horizontalLayout_25);

        tabWidget->addTab(tab_7, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName(QString::fromUtf8("tab_8"));
        verticalLayoutWidget_9 = new QWidget(tab_8);
        verticalLayoutWidget_9->setObjectName(QString::fromUtf8("verticalLayoutWidget_9"));
        verticalLayoutWidget_9->setGeometry(QRect(10, 10, 431, 141));
        verticalLayout_10 = new QVBoxLayout(verticalLayoutWidget_9);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setObjectName(QString::fromUtf8("horizontalLayout_26"));
        tableWidget_9 = new QTableWidget(verticalLayoutWidget_9);
        if (tableWidget_9->columnCount() < 5)
            tableWidget_9->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_9->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_9->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_9->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget_9->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        __qtablewidgetitem4->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        tableWidget_9->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        if (tableWidget_9->rowCount() < 1)
            tableWidget_9->setRowCount(1);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget_9->setVerticalHeaderItem(0, __qtablewidgetitem5);
        QIcon icon;
        icon.addFile(QString::fromUtf8("image/messagebox_critical.png"), QSize(), QIcon::Normal, QIcon::Off);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        __qtablewidgetitem6->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem6->setIcon(icon);
        tableWidget_9->setItem(0, 4, __qtablewidgetitem6);
        tableWidget_9->setObjectName(QString::fromUtf8("tableWidget_9"));
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(tableWidget_9->sizePolicy().hasHeightForWidth());
        tableWidget_9->setSizePolicy(sizePolicy3);
        tableWidget_9->setMinimumSize(QSize(425, 100));
        tableWidget_9->setMaximumSize(QSize(16777215, 200));
        tableWidget_9->setMidLineWidth(0);
        tableWidget_9->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        tableWidget_9->setAlternatingRowColors(false);
        tableWidget_9->verticalHeader()->setVisible(false);

        horizontalLayout_26->addWidget(tableWidget_9);

        horizontalSpacer_25 = new QSpacerItem(40, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_26->addItem(horizontalSpacer_25);


        verticalLayout_10->addLayout(horizontalLayout_26);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setObjectName(QString::fromUtf8("horizontalLayout_27"));
        pushButton_13 = new QPushButton(verticalLayoutWidget_9);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        sizePolicy.setHeightForWidth(pushButton_13->sizePolicy().hasHeightForWidth());
        pushButton_13->setSizePolicy(sizePolicy);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("image/edit-add-4.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_13->setIcon(icon1);

        horizontalLayout_27->addWidget(pushButton_13);

        horizontalSpacer_26 = new QSpacerItem(40, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_27->addItem(horizontalSpacer_26);


        verticalLayout_10->addLayout(horizontalLayout_27);

        tabWidget->addTab(tab_8, QString());
        tab_9 = new QWidget();
        tab_9->setObjectName(QString::fromUtf8("tab_9"));
        verticalLayoutWidget_10 = new QWidget(tab_9);
        verticalLayoutWidget_10->setObjectName(QString::fromUtf8("verticalLayoutWidget_10"));
        verticalLayoutWidget_10->setGeometry(QRect(10, 10, 431, 141));
        verticalLayout_11 = new QVBoxLayout(verticalLayoutWidget_10);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setObjectName(QString::fromUtf8("horizontalLayout_28"));
        tableWidget_10 = new QTableWidget(verticalLayoutWidget_10);
        if (tableWidget_10->columnCount() < 4)
            tableWidget_10->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget_10->setHorizontalHeaderItem(0, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget_10->setHorizontalHeaderItem(1, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget_10->setHorizontalHeaderItem(2, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        __qtablewidgetitem10->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        tableWidget_10->setHorizontalHeaderItem(3, __qtablewidgetitem10);
        if (tableWidget_10->rowCount() < 1)
            tableWidget_10->setRowCount(1);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget_10->setVerticalHeaderItem(0, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        __qtablewidgetitem12->setIcon(icon);
        tableWidget_10->setItem(0, 3, __qtablewidgetitem12);
        tableWidget_10->setObjectName(QString::fromUtf8("tableWidget_10"));
        sizePolicy3.setHeightForWidth(tableWidget_10->sizePolicy().hasHeightForWidth());
        tableWidget_10->setSizePolicy(sizePolicy3);
        tableWidget_10->setMinimumSize(QSize(325, 100));
        tableWidget_10->setMaximumSize(QSize(16777215, 200));
        tableWidget_10->setMidLineWidth(0);
        tableWidget_10->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        tableWidget_10->setAlternatingRowColors(false);
        tableWidget_10->verticalHeader()->setVisible(false);

        horizontalLayout_28->addWidget(tableWidget_10);

        horizontalSpacer_27 = new QSpacerItem(40, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_28->addItem(horizontalSpacer_27);


        verticalLayout_11->addLayout(horizontalLayout_28);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setObjectName(QString::fromUtf8("horizontalLayout_29"));
        pushButton_14 = new QPushButton(verticalLayoutWidget_10);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
        sizePolicy.setHeightForWidth(pushButton_14->sizePolicy().hasHeightForWidth());
        pushButton_14->setSizePolicy(sizePolicy);
        pushButton_14->setIcon(icon1);

        horizontalLayout_29->addWidget(pushButton_14);

        horizontalSpacer_28 = new QSpacerItem(40, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_29->addItem(horizontalSpacer_28);


        verticalLayout_11->addLayout(horizontalLayout_29);

        tabWidget->addTab(tab_9, QString());
        tab_10 = new QWidget();
        tab_10->setObjectName(QString::fromUtf8("tab_10"));
        verticalLayoutWidget_11 = new QWidget(tab_10);
        verticalLayoutWidget_11->setObjectName(QString::fromUtf8("verticalLayoutWidget_11"));
        verticalLayoutWidget_11->setGeometry(QRect(10, 10, 431, 175));
        verticalLayout_12 = new QVBoxLayout(verticalLayoutWidget_11);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        verticalLayout_12->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setObjectName(QString::fromUtf8("horizontalLayout_30"));
        tableWidget_3 = new QTableWidget(verticalLayoutWidget_11);
        if (tableWidget_3->columnCount() < 4)
            tableWidget_3->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(0, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(1, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(2, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        __qtablewidgetitem16->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        tableWidget_3->setHorizontalHeaderItem(3, __qtablewidgetitem16);
        if (tableWidget_3->rowCount() < 1)
            tableWidget_3->setRowCount(1);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget_3->setVerticalHeaderItem(0, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        __qtablewidgetitem18->setIcon(icon);
        tableWidget_3->setItem(0, 3, __qtablewidgetitem18);
        tableWidget_3->setObjectName(QString::fromUtf8("tableWidget_3"));
        sizePolicy3.setHeightForWidth(tableWidget_3->sizePolicy().hasHeightForWidth());
        tableWidget_3->setSizePolicy(sizePolicy3);
        tableWidget_3->setMinimumSize(QSize(325, 100));
        tableWidget_3->setMaximumSize(QSize(16777215, 200));
        tableWidget_3->setMidLineWidth(0);
        tableWidget_3->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        tableWidget_3->setAlternatingRowColors(false);
        tableWidget_3->verticalHeader()->setVisible(false);

        horizontalLayout_30->addWidget(tableWidget_3);

        horizontalSpacer_29 = new QSpacerItem(40, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_30->addItem(horizontalSpacer_29);


        verticalLayout_12->addLayout(horizontalLayout_30);

        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setObjectName(QString::fromUtf8("horizontalLayout_31"));
        pushButton_15 = new QPushButton(verticalLayoutWidget_11);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));
        sizePolicy.setHeightForWidth(pushButton_15->sizePolicy().hasHeightForWidth());
        pushButton_15->setSizePolicy(sizePolicy);
        pushButton_15->setIcon(icon1);

        horizontalLayout_31->addWidget(pushButton_15);

        horizontalSpacer_30 = new QSpacerItem(40, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_31->addItem(horizontalSpacer_30);


        verticalLayout_12->addLayout(horizontalLayout_31);

        verticalSpacer_10 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_12->addItem(verticalSpacer_10);

        checkBox = new QCheckBox(verticalLayoutWidget_11);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));

        verticalLayout_12->addWidget(checkBox);

        tabWidget->addTab(tab_10, QString());
        tab_11 = new QWidget();
        tab_11->setObjectName(QString::fromUtf8("tab_11"));
        verticalLayoutWidget_12 = new QWidget(tab_11);
        verticalLayoutWidget_12->setObjectName(QString::fromUtf8("verticalLayoutWidget_12"));
        verticalLayoutWidget_12->setGeometry(QRect(10, 10, 431, 175));
        verticalLayout_13 = new QVBoxLayout(verticalLayoutWidget_12);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        verticalLayout_13->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setObjectName(QString::fromUtf8("horizontalLayout_32"));
        tableWidget_11 = new QTableWidget(verticalLayoutWidget_12);
        if (tableWidget_11->columnCount() < 4)
            tableWidget_11->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget_11->setHorizontalHeaderItem(0, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget_11->setHorizontalHeaderItem(1, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget_11->setHorizontalHeaderItem(2, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        __qtablewidgetitem22->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        tableWidget_11->setHorizontalHeaderItem(3, __qtablewidgetitem22);
        if (tableWidget_11->rowCount() < 1)
            tableWidget_11->setRowCount(1);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget_11->setVerticalHeaderItem(0, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        __qtablewidgetitem24->setIcon(icon);
        tableWidget_11->setItem(0, 3, __qtablewidgetitem24);
        tableWidget_11->setObjectName(QString::fromUtf8("tableWidget_11"));
        sizePolicy3.setHeightForWidth(tableWidget_11->sizePolicy().hasHeightForWidth());
        tableWidget_11->setSizePolicy(sizePolicy3);
        tableWidget_11->setMinimumSize(QSize(325, 100));
        tableWidget_11->setMaximumSize(QSize(16777215, 200));
        tableWidget_11->setMidLineWidth(0);
        tableWidget_11->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        tableWidget_11->setAlternatingRowColors(false);
        tableWidget_11->verticalHeader()->setVisible(false);

        horizontalLayout_32->addWidget(tableWidget_11);

        horizontalSpacer_31 = new QSpacerItem(40, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_32->addItem(horizontalSpacer_31);


        verticalLayout_13->addLayout(horizontalLayout_32);

        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setObjectName(QString::fromUtf8("horizontalLayout_33"));
        pushButton_16 = new QPushButton(verticalLayoutWidget_12);
        pushButton_16->setObjectName(QString::fromUtf8("pushButton_16"));
        sizePolicy.setHeightForWidth(pushButton_16->sizePolicy().hasHeightForWidth());
        pushButton_16->setSizePolicy(sizePolicy);
        pushButton_16->setIcon(icon1);

        horizontalLayout_33->addWidget(pushButton_16);

        horizontalSpacer_32 = new QSpacerItem(40, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_33->addItem(horizontalSpacer_32);


        verticalLayout_13->addLayout(horizontalLayout_33);

        verticalSpacer_9 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_13->addItem(verticalSpacer_9);

        checkBox_3 = new QCheckBox(verticalLayoutWidget_12);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));

        verticalLayout_13->addWidget(checkBox_3);

        tabWidget->addTab(tab_11, QString());

        retranslateUi(ComputationalModelRegistrationDialog);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(ComputationalModelRegistrationDialog);
    } // setupUi

    void retranslateUi(QDialog *ComputationalModelRegistrationDialog)
    {
        ComputationalModelRegistrationDialog->setWindowTitle(QApplication::translate("ComputationalModelRegistrationDialog", "Computational Model Registration", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Name", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Icon file", 0, QApplication::UnicodeUTF8));
        pushButton_5->setText(QApplication::translate("ComputationalModelRegistrationDialog", "...", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("ComputationalModelRegistrationDialog", "API file", 0, QApplication::UnicodeUTF8));
        pushButton_12->setText(QApplication::translate("ComputationalModelRegistrationDialog", "...", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_7), QApplication::translate("ComputationalModelRegistrationDialog", "General", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = tableWidget_9->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Type", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_9->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Name", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_9->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Required", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget_9->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Default", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget_9->verticalHeaderItem(0);
        ___qtablewidgetitem4->setText(QApplication::translate("ComputationalModelRegistrationDialog", "1", 0, QApplication::UnicodeUTF8));

        const bool __sortingEnabled = tableWidget_9->isSortingEnabled();
        tableWidget_9->setSortingEnabled(false);
        tableWidget_9->setSortingEnabled(__sortingEnabled);

        pushButton_13->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_8), QApplication::translate("ComputationalModelRegistrationDialog", "Input Parameters", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget_10->horizontalHeaderItem(0);
        ___qtablewidgetitem5->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Type", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget_10->horizontalHeaderItem(1);
        ___qtablewidgetitem6->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Name", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget_10->horizontalHeaderItem(2);
        ___qtablewidgetitem7->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Value", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget_10->verticalHeaderItem(0);
        ___qtablewidgetitem8->setText(QApplication::translate("ComputationalModelRegistrationDialog", "1", 0, QApplication::UnicodeUTF8));

        const bool __sortingEnabled1 = tableWidget_10->isSortingEnabled();
        tableWidget_10->setSortingEnabled(false);
        tableWidget_10->setSortingEnabled(__sortingEnabled1);

        pushButton_14->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_9), QApplication::translate("ComputationalModelRegistrationDialog", "Static Parameters", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget_3->horizontalHeaderItem(0);
        ___qtablewidgetitem9->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Data Model", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget_3->horizontalHeaderItem(1);
        ___qtablewidgetitem10->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Name", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget_3->horizontalHeaderItem(2);
        ___qtablewidgetitem11->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Required", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget_3->verticalHeaderItem(0);
        ___qtablewidgetitem12->setText(QApplication::translate("ComputationalModelRegistrationDialog", "1", 0, QApplication::UnicodeUTF8));

        const bool __sortingEnabled2 = tableWidget_3->isSortingEnabled();
        tableWidget_3->setSortingEnabled(false);
        tableWidget_3->setSortingEnabled(__sortingEnabled2);

        pushButton_15->setText(QString());
        checkBox->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Multiple input commections supported", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_10), QApplication::translate("ComputationalModelRegistrationDialog", "Input Models", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget_11->horizontalHeaderItem(0);
        ___qtablewidgetitem13->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Data Model", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget_11->horizontalHeaderItem(1);
        ___qtablewidgetitem14->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Name", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget_11->horizontalHeaderItem(2);
        ___qtablewidgetitem15->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Required", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget_11->verticalHeaderItem(0);
        ___qtablewidgetitem16->setText(QApplication::translate("ComputationalModelRegistrationDialog", "1", 0, QApplication::UnicodeUTF8));

        const bool __sortingEnabled3 = tableWidget_11->isSortingEnabled();
        tableWidget_11->setSortingEnabled(false);
        tableWidget_11->setSortingEnabled(__sortingEnabled3);

        pushButton_16->setText(QString());
        checkBox_3->setText(QApplication::translate("ComputationalModelRegistrationDialog", "Multiple output conenctions supported", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_11), QApplication::translate("ComputationalModelRegistrationDialog", "Output Models", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ComputationalModelRegistrationDialog: public Ui_ComputationalModelRegistrationDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COMPUTATIONALMODELREGISTRATIONDIALOG_H
