/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#ifndef SUNPRISMSCENARIOMANAGERMAINWINDOW_H
#define SUNPRISMSCENARIOMANAGERMAINWINDOW_H    

#include <QMainWindow>
#include "datamodel.h"
#include "computationalmodel.h"
#include "scenario.h"
#include "progressindicator.h"

#include "scenarioexecutor.h"
#include "PythonQt.h"
#include "gui/PythonQtScriptingConsole.h"

namespace Ui {
    class SunprismScenarioManagerMainWindow;
}


class SunprismScenarioManagerMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit SunprismScenarioManagerMainWindow(QWidget *parent = 0);
    ~SunprismScenarioManagerMainWindow();
    
private slots:
    void loadDataModelList();
    void loadComputationalModelList();

    void setBasicOperationsEnabled(bool enable);
    
    void newScenario();
    void openScenario();
    void validateScenario();
    void saveScenario();
    void saveScenarioAs();
    void closeScenario();
    void runScenario();
    
    void modelInstanceExecutionStarted(ModelInstance* model_instance);
    void evaluatingScript(QString script);
    void updateScenarioExecution();
    void modelInstanceExecutionFinished(ModelInstance* model_instance);
    void scenarioExecutionFinished();
    
    void exportExecutable();
    
    void zoomIn();
    void zoomOut();
    void toggleFullScreen();
    void toggleGrid();
    void toggleSnapToGrid();
    
    void initializeScenarioView();
    void resetScenarioView();
    void resetGraphicsScene();
    void scenarioSelectionChanged();

    void updatePropertyTable();
    void propertyTableItemChanged(QTableWidgetItem *item);

    void scenarioViewModelDropped(QString tree_object, QString model, QPointF position);
    QString getAvailableModelInstanceName(QString model, QString model_type);

    void scenarioViewDeleteSelectedItems();
    
    void registerDataModel();
    void registerComputationalModel();

private:
    Ui::SunprismScenarioManagerMainWindow *ui;
    
    QString dataModelPath;
    QString computationalModelPath;
    
    QMap<QString, DataModel*> dataModelList;
    QMap<QString, ComputationalModel*> computationalModelList;
    
    QFile currentScenarioFile;
    Scenario scenario;
    QProgressBar *progressBar;
    QGraphicsProxyWidget *progressBarWidget;
    
    ScenarioExecutor scenarioExecutor;
    PythonQtScriptingConsole *pythonConsole;
    
    QTimer *scenarioExecutionTimer;
    QTime executionStartTime;
    ProgressIndicator *currentProgressIndicator;
};

#endif // SUNPRISMSCENARIOMANAGERMAINWINDOW_H
