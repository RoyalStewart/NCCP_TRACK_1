/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "modelinstance.h"
#include "modelinstanceconnector.h"
#include "modelinstanceconnection.h"
#include "scenario.h"


ModelInstance::ModelInstance() :
    QGraphicsItem()
{
    setFlags(QGraphicsItem::ItemIsSelectable | QGraphicsItem::ItemIsMovable);
    setFlag(ItemSendsGeometryChanges);
    
    backgroundColor = Qt::white;
    sideBorderWidth = 0;
    
    // temp values
    width = 130;
    height = 50;
    text_height = 20;
    text_width = width + 50;
    control_distance = 10.0;
    control_radius = 5.0;
    
    ModelInstanceConnector *input_connector = new ModelInstanceConnector(this);
    input_connector->setRadius(control_radius);
    input_connector->setPos(-(width/2 + control_distance), 0);
    input_connector->setConnectorType(ModelInstanceConnector::Input);
    
    ModelInstanceConnector *output_connector = new ModelInstanceConnector(this);
    output_connector->setRadius(control_radius);
    output_connector->setPos(width/2 + control_distance, 0);
    output_connector->setConnectorType(ModelInstanceConnector::Output);
}


ModelInstance::~ModelInstance()
{
    modelInstanceConnectionList.clear();
}


QMap<QString, QString>* ModelInstance::getFieldValueList()
{ 
    return &fieldValueList;
}


void ModelInstance::resetPixmap(QString filename)
{
    pixmap.load(filename);
}


void ModelInstance::addConnection(ModelInstanceConnection *connection)
{
    int found_index = modelInstanceConnectionList.indexOf(connection);
    
    if( found_index < 0 )
    {
        modelInstanceConnectionList.append(connection);
        connection->setParentItem(this);
    }
}


void ModelInstance::removeConnection(ModelInstanceConnection *connection)
{
    int found_index = modelInstanceConnectionList.indexOf(connection);
    
    if( found_index >= 0 )
    {
        modelInstanceConnectionList.remove(found_index);
    }
}


QVector<ModelInstanceConnection*>* ModelInstance::getModelInstanceConnectionList()
{
    return &modelInstanceConnectionList;
}


QRectF ModelInstance::boundingRect() const
{
    qreal expand = 10;
    qreal total_width = text_width + expand;
    qreal total_height = height + text_height * 2 + expand;
    
    return QRectF(-(total_width/2), -(total_height/2),
                  total_width, total_height);
}


QPainterPath ModelInstance::shape() const
{
    QPainterPath path;
    path.addRect(QRectF(-(width/2), -(height/2),
                  width, height));
    return path;
}


void ModelInstance::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{   
    if( option->state & QStyle::State_Selected )
    {
        painter->setPen(Qt::NoPen);
        painter->setBrush(QColor(128, 128, 255, 32));
        painter->drawRect(boundingRect());
    }

    painter->setPen(Qt::NoPen);
    painter->setBrush(backgroundColor);
    painter->drawRect(QRectF(-width/2, -height/2, width, height));
    
    if( sideBorderWidth > 0 )
    {
        painter->setPen(Qt::NoPen);
        painter->setBrush(Qt::white);
        painter->drawRect(QRectF(-width/2, -height/2, sideBorderWidth, height));
        painter->drawRect(QRectF(width/2 - sideBorderWidth, -height/2, sideBorderWidth, height));
       
        painter->setPen(QPen(Qt::black, 0));
        painter->drawLine(-width/2 + sideBorderWidth, -height/2, -width/2 + sideBorderWidth, height/2);
        painter->drawLine(width/2 - sideBorderWidth, -height/2, width/2 - sideBorderWidth, height/2);
    }
    
    
    painter->setPen(QPen(Qt::black, 0));
    painter->setBrush(Qt::NoBrush);
    painter->drawRect(QRectF(-width/2, -height/2, width, height));
    
    
    qreal pixmap_margin = 3;
    painter->setPen(QPen(QColor(128, 128, 128), 0));
    painter->setBrush(Qt::white);
    painter->drawRect(-pixmap.width()/2 - pixmap_margin, -pixmap.height()/2 - pixmap_margin, pixmap.width() + pixmap_margin*2, pixmap.height() + pixmap_margin*2);
    
    painter->drawPixmap(QPointF(-(pixmap.width()/2), -(pixmap.height()/2)), pixmap);
    
    painter->setPen(Qt::black);
    
    QFont font = painter->font();
    
    font.setItalic(true);
    painter->setFont(font);
    
    QRectF model_text_rectangle(boundingRect());
    model_text_rectangle.setHeight(text_height);
    painter->drawText(model_text_rectangle, Qt::AlignCenter, fieldValueList.value("model"));
    
    font.setItalic(false);
    painter->setFont(font);
    
    QRectF name_text_rectangle(boundingRect());
    name_text_rectangle.setY(height/2);
    name_text_rectangle.setHeight(text_height);
    painter->drawText(name_text_rectangle, Qt::AlignCenter, fieldValueList.value("name"));

    if( option->state & QStyle::State_Selected )
    {
        painter->setPen(QPen(Qt::white, 2, Qt::SolidLine));
        painter->setBrush(Qt::NoBrush);
        painter->drawRect(boundingRect());

        painter->setPen(QPen(QColor(128, 128, 255, 255), 2, Qt::DashLine));
        painter->setBrush(Qt::NoBrush);
        painter->drawRect(boundingRect());
    }
}


QVariant ModelInstance::itemChange(GraphicsItemChange change, const QVariant &value)
{
    if( change == ItemPositionHasChanged )
    {
        Scenario* scenario = (Scenario*)scene();
        if( scenario != NULL  && scenario->getSnapToGrid() )
        {
            int grid_step_half = scenario->getGridStep()/2;
            
            setX(round(x()/grid_step_half)*grid_step_half);
            setY(round(y()/grid_step_half)*grid_step_half);
        }
        
        for( int i = 0; i < modelInstanceConnectionList.size(); i++ )
        {
            modelInstanceConnectionList[i]->adjust();
        }
        
        fieldValueList.insert("x", QString::number(x()));
        fieldValueList.insert("y", QString::number(y()));
    }

    return QGraphicsItem::itemChange(change, value);
}
