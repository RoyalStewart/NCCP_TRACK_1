/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "scenariowriter.h"


ScenarioWriter::ScenarioWriter(Scenario *scenario, QMap<QString, DataModel*> *data_model_list, QMap<QString, ComputationalModel*> *computational_model_list)
{
    this->scenario = scenario;
    this->dataModelList = data_model_list;
    this->computationalModelList = computational_model_list;
  
    xml_writer.setAutoFormatting(true);
}


bool ScenarioWriter::writeScenario(QIODevice *device)
{
    xml_writer.setDevice(device);

    xml_writer.writeStartDocument();

    xml_writer.writeStartElement("scenario");

    // write data model instances
    
    QVector<DataModelInstance*> *data_model_instance_list = scenario->getDataModelInstanceList();
    
    for( int i = 0; i < data_model_instance_list->size(); i++ )
    {
        writeDataModelInstance(data_model_instance_list->value(i));
    }
        
    // write computational model instances
    
    QVector<ComputationalModelInstance*> *computational_model_instance_list = scenario->getComputationalModelInstanceList();
    
    for( int i = 0; i < computational_model_instance_list->size(); i++ )
    {
        writeComputationalModelInstance(computational_model_instance_list->value(i));
    }
    
    xml_writer.writeEndElement();

    xml_writer.writeEndDocument();

    return true;
}


void ScenarioWriter::writeDataModelInstance(DataModelInstance *data_model_instance)
{
    xml_writer.writeStartElement("data_model_instance");
    
    QMap<QString, QString> *field_value_list = data_model_instance->getFieldValueList();
    
    xml_writer.writeTextElement("name", field_value_list->value("name"));
    xml_writer.writeTextElement("model", field_value_list->value("model"));
    
    QMap<QString, QString>::const_iterator field_value_iterator = field_value_list->constBegin();
    
    while( field_value_iterator != field_value_list->constEnd() )
    {
        if( field_value_iterator.key() != "name" && field_value_iterator.key() != "model" )
        {
            xml_writer.writeTextElement(field_value_iterator.key(), field_value_iterator.value());
        }
        
        ++field_value_iterator;
    }
    
    xml_writer.writeEndElement();    
}


void ScenarioWriter::writeComputationalModelInstance(ComputationalModelInstance *computational_model_instance)
{
    xml_writer.writeStartElement("computational_model_instance");
    
    QMap<QString, QString> *field_value_list = computational_model_instance->getFieldValueList();
    
    xml_writer.writeTextElement("name", field_value_list->value("name"));
    xml_writer.writeTextElement("model", field_value_list->value("model"));
    
    QMap<QString, QString>::const_iterator field_value_iterator = field_value_list->constBegin();
    
    while( field_value_iterator != field_value_list->constEnd() )
    {
        if( field_value_iterator.key() != "name" && field_value_iterator.key() != "model" )
        {
            xml_writer.writeTextElement(field_value_iterator.key(), field_value_iterator.value());
        }
        
        ++field_value_iterator;
    }

    
    QVector<ModelInstanceConnection*> *model_instance_connection_list = computational_model_instance->getModelInstanceConnectionList();
    
    for( int j = 0; j < model_instance_connection_list->size(); j++ )
    {
        ModelInstanceConnection *model_instance_connection = model_instance_connection_list->value(j);
            
        ModelInstance *source_model_instance = model_instance_connection->getSourceModelInstance();
        ModelInstance *destination_model_instance = model_instance_connection->getDestinationModelInstance();
        
        ComputationalModel *computational_model = computationalModelList->value(computational_model_instance->getFieldValueList()->value("model"));
            
        // input connection
        if( destination_model_instance == computational_model_instance )
        {
            QMap<QString, QString> *model_instance_field_value_list = source_model_instance->getFieldValueList();
            
            QString data_model_name = model_instance_field_value_list->value("model");
                                    
            // TODO: Should be changed to QMap pointer
            QMap<QString, QString> input_data_model_field_value_list;                                         
            
            QMap< QString, QMap<QString, QString> > *input_data_model_list = computational_model->getInputDataModelList();
            
            QMap<QString, QMap<QString, QString> >::const_iterator input_data_model_iterator = input_data_model_list->constBegin();
            
            while( input_data_model_iterator != input_data_model_list->constEnd() && input_data_model_field_value_list.size() == 0 )
            {
                if( input_data_model_iterator.value().value("model") == data_model_name )
                {
                    input_data_model_field_value_list = input_data_model_iterator.value();
                }
                
                ++input_data_model_iterator;
            }
            
            if( input_data_model_field_value_list.size() > 0 )
            {
                xml_writer.writeStartElement("input_data_model");
                
                xml_writer.writeTextElement("name", input_data_model_field_value_list.value("name"));
                xml_writer.writeTextElement("model", input_data_model_field_value_list.value("model"));
                xml_writer.writeTextElement("instance_name", model_instance_field_value_list->value("name"));
                
                xml_writer.writeEndElement();
            }
        }
        // output connection
        else if( source_model_instance == computational_model_instance )
        {
            QMap<QString, QString> *model_instance_field_value_list = destination_model_instance->getFieldValueList();
            
            QString data_model_name = model_instance_field_value_list->value("model");
                                    
            // TODO: Should be changed to QMap pointer
            QMap<QString, QString> output_data_model_field_value_list;                                         

            QMap< QString, QMap<QString, QString> > *output_data_model_list = computational_model->getOutputDataModelList();
            
            QMap<QString, QMap<QString, QString> >::const_iterator output_data_model_iterator = output_data_model_list->constBegin();
            
            while( output_data_model_iterator != output_data_model_list->constEnd() && output_data_model_field_value_list.size() == 0 )
            {
                if( output_data_model_iterator.value().value("model") == data_model_name )
                {
                    output_data_model_field_value_list = output_data_model_iterator.value();
                }
                
                ++output_data_model_iterator;
            }
            
            if( output_data_model_field_value_list.size() > 0 )
            {
                xml_writer.writeStartElement("output_data_model");
                
                xml_writer.writeTextElement("name", output_data_model_field_value_list.value("name"));
                xml_writer.writeTextElement("model", output_data_model_field_value_list.value("model"));
                xml_writer.writeTextElement("instance_name", model_instance_field_value_list->value("name"));
                
                xml_writer.writeEndElement();
            }
        }
    }


    xml_writer.writeEndElement();
}

