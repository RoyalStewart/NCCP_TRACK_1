/*
Copyright (c) 2013, Board of Regents, Nevada System of Higher Education (NSHE),
obo University of Nevada, Reno
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "computationalmodelregistrationdialog.h"
#include "inputparameterstabledelegate.h"


ComputationalModelRegistrationDialog::ComputationalModelRegistrationDialog(QWidget *parent) :
    QDialog(parent)
{
    resize(550, 300);

    tabWidget = new QTabWidget;
     
    tabWidget->addTab(createGeneralTab(), tr("General"));
    tabWidget->addTab(createInputParametersTab(), tr("Config Parameters"));
    tabWidget->addTab(createStaticParametersTab(), tr("Static Parameters"));
    tabWidget->addTab(createInputDataModelsTab(), tr("Input Data Resources"));
    tabWidget->addTab(createOutputDataModelsTab(), tr("Output Data Resources"));
    
    buttonBox = new QDialogButtonBox( QDialogButtonBox::Ok
                                      | QDialogButtonBox::Cancel );
    
    connect(buttonBox, SIGNAL(accepted()), this, SLOT(accept()));
    connect(buttonBox, SIGNAL(rejected()), this, SLOT(reject()));
    
    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(tabWidget);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);
    
    setWindowTitle(tr("Computational Activity Registration"));
}


ComputationalModelRegistrationDialog::~ComputationalModelRegistrationDialog()
{
}


QLineEdit* ComputationalModelRegistrationDialog::getNameEdit()
{
    return nameEdit;
}


QLineEdit* ComputationalModelRegistrationDialog::getIconFileEdit()
{
    return iconFileEdit;  
}


QLineEdit* ComputationalModelRegistrationDialog::getApiFileEdit()
{
    return apiFileEdit;   
}


QTableWidget* ComputationalModelRegistrationDialog::getInputParametersTable()
{
    return inputParametersTable;   
}


QTableWidget* ComputationalModelRegistrationDialog::getStaticParametersTable()
{
    return staticParametersTable;   
}

    
QTableWidget* ComputationalModelRegistrationDialog::getInputDataModelsTable()
{
    return inputDataModelsTable;   
}


QTableWidget* ComputationalModelRegistrationDialog::getOutputDataModelsTable()
{
    return outputDataModelsTable;   
}

    
QWidget* ComputationalModelRegistrationDialog::createGeneralTab()
{
    QWidget *widget = new QWidget;
     
    QGridLayout *grid_layout = new QGridLayout;
    
    grid_layout->setSizeConstraint(QLayout::SetFixedSize);

    grid_layout->setColumnMinimumWidth(1, 300);
    
    
    int row = 0;
    
    nameEdit = new QLineEdit;
    
    grid_layout->addWidget(new QLabel(tr("Name")), row, 0);
    grid_layout->addWidget(nameEdit, row, 1);
 
    
    row++;
    
    QHBoxLayout *icon_input_horizontal_layout = new QHBoxLayout;
    
    iconFileEdit = new QLineEdit;
    
    QToolButton *icon_file_button = new QToolButton;
    icon_file_button->setText("...");
    
    connect(icon_file_button, SIGNAL(clicked()), this, SLOT(getIconFile()));
    
    icon_input_horizontal_layout->addWidget(iconFileEdit);
    icon_input_horizontal_layout->addWidget(icon_file_button);
    
    grid_layout->addWidget(new QLabel(tr("Icon file")), row, 0);
    grid_layout->addLayout(icon_input_horizontal_layout, row, 1);
    
    
    row++;
    
    QHBoxLayout *api_input_horizontal_layout = new QHBoxLayout;
    
    apiFileEdit = new QLineEdit;
    QToolButton *api_file_button = new QToolButton;
    api_file_button->setText("...");
    
    connect(api_file_button, SIGNAL(clicked()), this, SLOT(getApiFile()));
    
    api_input_horizontal_layout->addWidget(apiFileEdit);
    api_input_horizontal_layout->addWidget(api_file_button);
    
    grid_layout->addWidget(new QLabel(tr("API file")), row, 0);
    grid_layout->addLayout(api_input_horizontal_layout, row, 1);
    
    
    row++;
    
    QSpacerItem *spacer = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Expanding);
    
    grid_layout->addItem(spacer, row, 0, 1, 3);
    
    
    widget->setLayout(grid_layout);
     
    return widget;
}


void ComputationalModelRegistrationDialog::getIconFile()
{
    QString file_name =
            QFileDialog::getOpenFileName( this, tr("Choose Icon File"),
                                          QDir::currentPath(),
                                          tr("PNG Files (*.png)") );
    if( file_name.isEmpty() )
    {
        return;
    }
    
    QDir dir;
    iconFileEdit->setText(dir.relativeFilePath(file_name));
}


void ComputationalModelRegistrationDialog::getApiFile()
{
    QString file_name =
            QFileDialog::getOpenFileName( this, tr("Choose API File"),
                                          QDir::currentPath(),
                                          tr("Python Files (*.py)") );
    if( file_name.isEmpty() )
    {
        return;
    }
    
    QDir dir;
    apiFileEdit->setText(dir.relativeFilePath(file_name));
}


void ComputationalModelRegistrationDialog::swapRows(QTableWidget *table_widget, int row1, int row2)
{
    QList<QTableWidgetItem*> row1_items;
    
    for( int column = 0; column < table_widget->columnCount(); ++column )
    {
        row1_items.append(table_widget->takeItem(row1, column));
    }
    
    QList<QTableWidgetItem*> row2_items;
    
    for( int column = 0; column < table_widget->columnCount(); ++column )
    {
        row2_items.append(table_widget->takeItem(row2, column));
    }
 
    for( int column = 0; column < table_widget->columnCount(); ++column )
    {
        table_widget->setItem(row1, column, row2_items.at(column));
    }
    
    for( int column = 0; column < table_widget->columnCount(); ++column )
    {
        table_widget->setItem(row2, column, row1_items.at(column));
    }
}
 

QWidget* ComputationalModelRegistrationDialog::createInputParametersTab()
{
    QWidget *widget = new QWidget;
    
    QVBoxLayout *vertical_layout = new QVBoxLayout;
    
    
    inputParametersTable = new QTableWidget;
    inputParametersTable->setColumnCount(4);
    inputParametersTable->verticalHeader()->setVisible(false);
    
    inputParametersTable->setItemDelegate(new InputParametersTableDelegate(inputParametersTable));
            
    inputParametersTable->setHorizontalHeaderItem(0, new QTableWidgetItem(tr("Name")));
    inputParametersTable->setHorizontalHeaderItem(1, new QTableWidgetItem(tr("Type")));
    inputParametersTable->setHorizontalHeaderItem(2, new QTableWidgetItem(tr("Required")));
    inputParametersTable->setHorizontalHeaderItem(3, new QTableWidgetItem(tr("Default")));
    
    vertical_layout->addWidget(inputParametersTable);
 
    
    QHBoxLayout *horizontal_layout = new QHBoxLayout;
    
    inputParameterAddButton = new QToolButton;
    inputParameterAddButton->setIcon(QIcon("image/edit-add-4.png"));
    
    connect(inputParameterAddButton, SIGNAL(clicked()), this, SLOT(addInputParameter()));
    
    horizontal_layout->addWidget(inputParameterAddButton);
    
    
    inputParameterRemoveButton = new QToolButton;
    inputParameterRemoveButton->setIcon(QIcon("image/edit-remove-3.png"));
    
    connect(inputParameterRemoveButton, SIGNAL(clicked()), this, SLOT(removeInputParameter()));
    
    horizontal_layout->addWidget(inputParameterRemoveButton);
    
    
    inputParameterMoveUpButton = new QToolButton;
    inputParameterMoveUpButton->setIcon(QIcon("image/go-up-5.png"));
    
    connect(inputParameterMoveUpButton, SIGNAL(clicked()), this, SLOT(moveUpInputParameter()));
    
    horizontal_layout->addWidget(inputParameterMoveUpButton);
    
    
    inputParameterMoveDownButton = new QToolButton;
    inputParameterMoveDownButton->setIcon(QIcon("image/go-down-5.png"));
    
    connect(inputParameterMoveDownButton, SIGNAL(clicked()), this, SLOT(moveDownInputParameter()));
    
    horizontal_layout->addWidget(inputParameterMoveDownButton);
    
    
    QSpacerItem *spacer = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Expanding);
    
    horizontal_layout->addItem(spacer);
    
    
    vertical_layout->addLayout(horizontal_layout);
    
    
    inputParameterRemoveButton->setEnabled(false);
    inputParameterMoveUpButton->setEnabled(false);
    inputParameterMoveDownButton->setEnabled(false);
    
    addInputParameter();
    
    
    widget->setLayout(vertical_layout);
    
    return widget;    
}


void ComputationalModelRegistrationDialog::addInputParameter()
{
    inputParametersTable->insertRow(inputParametersTable->currentRow() + 1);
    
    QTableWidgetItem *item = new QTableWidgetItem;
    inputParametersTable->setItem(inputParametersTable->currentRow() + 1, 2, item);
    item->setFlags(Qt::ItemIsEnabled|Qt::ItemIsUserCheckable);
    item->setCheckState(Qt::Unchecked);
    
    inputParametersTable->setCurrentCell(inputParametersTable->currentRow() + 1, 0);
    
    if( inputParametersTable->rowCount() == 2 )
    {
        inputParameterRemoveButton->setEnabled(true);
        inputParameterMoveUpButton->setEnabled(true);
        inputParameterMoveDownButton->setEnabled(true);
    }
}


void ComputationalModelRegistrationDialog::removeInputParameter()
{
    if( inputParametersTable->rowCount() > 1 )
    {
        int row_delete = inputParametersTable->currentRow();
        
        if( row_delete < 0 )
        {
            row_delete = inputParametersTable->rowCount() - 1;
        }
        
        inputParametersTable->removeRow(row_delete);
                
        if( inputParametersTable->rowCount() == 1 )
        {
            inputParameterRemoveButton->setEnabled(false);
            inputParameterMoveUpButton->setEnabled(false);
            inputParameterMoveDownButton->setEnabled(false);
        }
    }
}


void ComputationalModelRegistrationDialog::moveUpInputParameter()
{
    if( inputParametersTable->currentRow() > 0 )
    {
        int row1 = inputParametersTable->currentRow();
        int row2 = row1 - 1;
        
        swapRows(inputParametersTable, row1, row2);
        
        inputParametersTable->setCurrentCell(row2, 0);
    }
}


void ComputationalModelRegistrationDialog::moveDownInputParameter()
{  
    if( inputParametersTable->currentRow() < (inputParametersTable->rowCount() - 1) )
    {
        int row1 = inputParametersTable->currentRow();
        int row2 = row1 + 1;
        
        swapRows(inputParametersTable, row1, row2);
        
        inputParametersTable->setCurrentCell(row2, 0);
    }
}


QWidget* ComputationalModelRegistrationDialog::createStaticParametersTab()
{
    QWidget *widget = new QWidget;
    
    QVBoxLayout *vertical_layout = new QVBoxLayout;
     
    
    staticParametersTable = new QTableWidget;
    staticParametersTable->setColumnCount(3);
    staticParametersTable->verticalHeader()->setVisible(false);
    
    staticParametersTable->setHorizontalHeaderItem(0, new QTableWidgetItem(tr("Name")));
    staticParametersTable->setHorizontalHeaderItem(1, new QTableWidgetItem(tr("Type")));
    staticParametersTable->setHorizontalHeaderItem(2, new QTableWidgetItem(tr("Value")));
    
    vertical_layout->addWidget(staticParametersTable);
 
    
    QHBoxLayout *horizontal_layout = new QHBoxLayout;
    
    staticParameterAddButton = new QToolButton;
    staticParameterAddButton->setIcon(QIcon("image/edit-add-4.png"));
    
    connect(staticParameterAddButton, SIGNAL(clicked()), this, SLOT(addStaticParameter()));
    
    horizontal_layout->addWidget(staticParameterAddButton);
    
    
    staticParameterRemoveButton = new QToolButton;
    staticParameterRemoveButton->setIcon(QIcon("image/edit-remove-3.png"));
    
    connect(staticParameterRemoveButton, SIGNAL(clicked()), this, SLOT(removeStaticParameter()));
    
    horizontal_layout->addWidget(staticParameterRemoveButton);
    
    
    staticParameterMoveUpButton = new QToolButton;
    staticParameterMoveUpButton->setIcon(QIcon("image/go-up-5.png"));
    
    connect(staticParameterMoveUpButton, SIGNAL(clicked()), this, SLOT(moveUpStaticParameter()));
    
    horizontal_layout->addWidget(staticParameterMoveUpButton);
    
    
    staticParameterMoveDownButton = new QToolButton;
    staticParameterMoveDownButton->setIcon(QIcon("image/go-down-5.png"));
    
    connect(staticParameterMoveDownButton, SIGNAL(clicked()), this, SLOT(moveDownStaticParameter()));
    
    horizontal_layout->addWidget(staticParameterMoveDownButton);
    
    
    QSpacerItem *spacer = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Expanding);
 
    horizontal_layout->addItem(spacer);
    
    
    vertical_layout->addLayout(horizontal_layout);
    
    
    staticParameterRemoveButton->setEnabled(false);
    staticParameterMoveUpButton->setEnabled(false);
    staticParameterMoveDownButton->setEnabled(false);
    
    
    addStaticParameter();
    
    
    widget->setLayout(vertical_layout);
    
    return widget;    
}


void ComputationalModelRegistrationDialog::addStaticParameter()
{
    staticParametersTable->insertRow(staticParametersTable->currentRow() + 1);
    
    staticParametersTable->setCurrentCell(staticParametersTable->currentRow() + 1, 0);
    
    if( staticParametersTable->rowCount() == 2 )
    {
        staticParameterRemoveButton->setEnabled(true);
        staticParameterMoveUpButton->setEnabled(true);
        staticParameterMoveDownButton->setEnabled(true);
    }
}


void ComputationalModelRegistrationDialog::removeStaticParameter()
{
    if( staticParametersTable->rowCount() > 1 )
    {
        int row_delete = staticParametersTable->currentRow();
        
        if( row_delete < 0 )
        {
            row_delete = staticParametersTable->rowCount() - 1;
        }
                
        staticParametersTable->removeRow(row_delete);
        
        if( staticParametersTable->rowCount() == 1 )
        {
            staticParameterRemoveButton->setEnabled(false);
            staticParameterMoveUpButton->setEnabled(false);
            staticParameterMoveDownButton->setEnabled(false);
        }
    }
}


void ComputationalModelRegistrationDialog::moveUpStaticParameter()
{
    if( staticParametersTable->currentRow() > 0 )
    {
        int row1 = staticParametersTable->currentRow();
        int row2 = row1 - 1;
        
        swapRows(staticParametersTable, row1, row2);
        
        staticParametersTable->setCurrentCell(row2, 0);
    }
}


void ComputationalModelRegistrationDialog::moveDownStaticParameter()
{  
    if( staticParametersTable->currentRow() < (staticParametersTable->rowCount() - 1) )
    {
        int row1 = staticParametersTable->currentRow();
        int row2 = row1 + 1;
        
        swapRows(staticParametersTable, row1, row2);
        
        staticParametersTable->setCurrentCell(row2, 0);
    }
}


QWidget* ComputationalModelRegistrationDialog::createInputDataModelsTab()
{
    QWidget *widget = new QWidget;
    
    QVBoxLayout *vertical_layout = new QVBoxLayout;
     
    
    inputDataModelsTable = new QTableWidget;
    inputDataModelsTable->setColumnCount(3);
    inputDataModelsTable->verticalHeader()->setVisible(false);
    
    // be able to reuse InputParametersTableDelegate since the checkbox is at the same column
    inputDataModelsTable->setItemDelegate(new InputParametersTableDelegate(inputDataModelsTable));
            
    inputDataModelsTable->setHorizontalHeaderItem(0, new QTableWidgetItem(tr("Name")));
    inputDataModelsTable->setHorizontalHeaderItem(1, new QTableWidgetItem(tr("Data Resource")));
    inputDataModelsTable->setHorizontalHeaderItem(2, new QTableWidgetItem(tr("Required")));
    
    vertical_layout->addWidget(inputDataModelsTable);
 
    
    QHBoxLayout *horizontal_layout = new QHBoxLayout;
    
    inputDataModelAddButton = new QToolButton;
    inputDataModelAddButton->setIcon(QIcon("image/edit-add-4.png"));
    
    connect(inputDataModelAddButton, SIGNAL(clicked()), this, SLOT(addInputDataModel()));
    
    horizontal_layout->addWidget(inputDataModelAddButton);
    
    
    inputDataModelRemoveButton = new QToolButton;
    inputDataModelRemoveButton->setIcon(QIcon("image/edit-remove-3.png"));
    
    connect(inputDataModelRemoveButton, SIGNAL(clicked()), this, SLOT(removeInputDataModel()));
    
    horizontal_layout->addWidget(inputDataModelRemoveButton);
    
    
    inputDataModelMoveUpButton = new QToolButton;
    inputDataModelMoveUpButton->setIcon(QIcon("image/go-up-5.png"));
    
    connect(inputDataModelMoveUpButton, SIGNAL(clicked()), this, SLOT(moveUpInputDataModel()));
    
    horizontal_layout->addWidget(inputDataModelMoveUpButton);
    
    
    inputDataModelMoveDownButton = new QToolButton;
    inputDataModelMoveDownButton->setIcon(QIcon("image/go-down-5.png"));
    
    connect(inputDataModelMoveDownButton, SIGNAL(clicked()), this, SLOT(moveDownInputDataModel()));
    
    horizontal_layout->addWidget(inputDataModelMoveDownButton);
    
    
    QSpacerItem *spacer = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Expanding);
    
    horizontal_layout->addItem(spacer);
    
    
    vertical_layout->addLayout(horizontal_layout);
    
    
    multipleInputConnectionsCheckBox = new QCheckBox;
    multipleInputConnectionsCheckBox->setText(tr("Multiple input connections supported"));
        
    vertical_layout->addWidget(multipleInputConnectionsCheckBox);
    
    
    inputDataModelRemoveButton->setEnabled(false);
    inputDataModelMoveUpButton->setEnabled(false);
    inputDataModelMoveDownButton->setEnabled(false);
    addInputDataModel();
    
    
    widget->setLayout(vertical_layout);
    
    return widget;    
}


void ComputationalModelRegistrationDialog::addInputDataModel()
{
    inputDataModelsTable->insertRow(inputDataModelsTable->currentRow() + 1);
    
    QTableWidgetItem *item = new QTableWidgetItem;
    inputDataModelsTable->setItem(inputDataModelsTable->currentRow() + 1, 2, item);
    item->setFlags(Qt::ItemIsEnabled|Qt::ItemIsUserCheckable);
    item->setCheckState(Qt::Unchecked);
    
    inputDataModelsTable->setCurrentCell(inputDataModelsTable->currentRow() + 1, 0);
    
    if( inputDataModelsTable->rowCount() == 2 )
    {
        inputDataModelRemoveButton->setEnabled(true);
        inputDataModelMoveUpButton->setEnabled(true);
        inputDataModelMoveDownButton->setEnabled(true);
    }
}


void ComputationalModelRegistrationDialog::removeInputDataModel()
{
    if( inputDataModelsTable->rowCount() > 1 )
    {
        int row_delete = inputDataModelsTable->currentRow();
        
        if( row_delete < 0 )
        {
            row_delete = inputDataModelsTable->rowCount() - 1;
        }
        
        inputDataModelsTable->removeRow(row_delete);
        
        if( inputDataModelsTable->rowCount() == 1 )
        {
            inputDataModelRemoveButton->setEnabled(false);
            inputDataModelMoveUpButton->setEnabled(false);
            inputDataModelMoveDownButton->setEnabled(false);
        }
    }
}



void ComputationalModelRegistrationDialog::moveUpInputDataModel()
{
    if( inputDataModelsTable->currentRow() > 0 )
    {
        int row1 = inputDataModelsTable->currentRow();
        int row2 = row1 - 1;
        
        swapRows(inputDataModelsTable, row1, row2);
        
        inputDataModelsTable->setCurrentCell(row2, 0);
    }
}


void ComputationalModelRegistrationDialog::moveDownInputDataModel()
{  
    if( inputDataModelsTable->currentRow() < (inputDataModelsTable->rowCount() - 1) )
    {
        int row1 = inputDataModelsTable->currentRow();
        int row2 = row1 + 1;
        
        swapRows(inputDataModelsTable, row1, row2);
        
        inputDataModelsTable->setCurrentCell(row2, 0);
    }
}


QWidget* ComputationalModelRegistrationDialog::createOutputDataModelsTab()
{
    QWidget *widget = new QWidget;
    
    QVBoxLayout *vertical_layout = new QVBoxLayout;
     
    
    outputDataModelsTable = new QTableWidget;
    outputDataModelsTable->setColumnCount(3);
    outputDataModelsTable->verticalHeader()->setVisible(false);
    
    // be able to reuse InputParametersTableDelegate since the checkbox is at the same column
    outputDataModelsTable->setItemDelegate(new InputParametersTableDelegate(outputDataModelsTable));
            
    outputDataModelsTable->setHorizontalHeaderItem(0, new QTableWidgetItem(tr("Name")));
    outputDataModelsTable->setHorizontalHeaderItem(1, new QTableWidgetItem(tr("Data Resource")));
    outputDataModelsTable->setHorizontalHeaderItem(2, new QTableWidgetItem(tr("Required")));
    
    vertical_layout->addWidget(outputDataModelsTable);
 
    
    QHBoxLayout *horizontal_layout = new QHBoxLayout;
    
    outputDataModelAddButton = new QToolButton;
    outputDataModelAddButton->setIcon(QIcon("image/edit-add-4.png"));
    
    connect(outputDataModelAddButton, SIGNAL(clicked()), this, SLOT(addOutputDataModel()));
    
    horizontal_layout->addWidget(outputDataModelAddButton);
    
    
    outputDataModelRemoveButton = new QToolButton;
    outputDataModelRemoveButton->setIcon(QIcon("image/edit-remove-3.png"));
    
    connect(outputDataModelRemoveButton, SIGNAL(clicked()), this, SLOT(removeOutputDataModel()));
    
    horizontal_layout->addWidget(outputDataModelRemoveButton);
    
    
    outputDataModelMoveUpButton = new QToolButton;
    outputDataModelMoveUpButton->setIcon(QIcon("image/go-up-5.png"));
    
    connect(outputDataModelMoveUpButton, SIGNAL(clicked()), this, SLOT(moveUpOutputDataModel()));
    
    horizontal_layout->addWidget(outputDataModelMoveUpButton);
    
    
    outputDataModelMoveDownButton = new QToolButton;
    outputDataModelMoveDownButton->setIcon(QIcon("image/go-down-5.png"));
    
    connect(outputDataModelMoveDownButton, SIGNAL(clicked()), this, SLOT(moveDownOutputDataModel()));
    
    horizontal_layout->addWidget(outputDataModelMoveDownButton);
    
    
    QSpacerItem *spacer = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Expanding);
    
    horizontal_layout->addItem(spacer);
    
    
    vertical_layout->addLayout(horizontal_layout);
    
    
    multipleOutputConnectionsCheckBox = new QCheckBox;
    multipleOutputConnectionsCheckBox->setText(tr("Multiple output connections supported"));
        
    vertical_layout->addWidget(multipleOutputConnectionsCheckBox);
    
    
    outputDataModelRemoveButton->setEnabled(false);
    outputDataModelMoveUpButton->setEnabled(false);
    outputDataModelMoveDownButton->setEnabled(false);
    
    addOutputDataModel();
    
    
    widget->setLayout(vertical_layout);
    
    return widget;    
}


void ComputationalModelRegistrationDialog::addOutputDataModel()
{
    outputDataModelsTable->insertRow(outputDataModelsTable->currentRow() + 1);
    
    QTableWidgetItem *item = new QTableWidgetItem;
    outputDataModelsTable->setItem(outputDataModelsTable->currentRow() + 1, 2, item);
    item->setFlags(Qt::ItemIsEnabled|Qt::ItemIsUserCheckable);
    item->setCheckState(Qt::Unchecked);
    
    outputDataModelsTable->setCurrentCell(outputDataModelsTable->currentRow() + 1, 0);
    
    if( outputDataModelsTable->rowCount() == 2 )
    {
        outputDataModelRemoveButton->setEnabled(true);
        outputDataModelMoveUpButton->setEnabled(true);
        outputDataModelMoveDownButton->setEnabled(true);
    }
}


void ComputationalModelRegistrationDialog::removeOutputDataModel()
{
    if( outputDataModelsTable->rowCount() > 1 )
    {
        int row_delete = outputDataModelsTable->currentRow();
        
        if( row_delete < 0 )
        {
            row_delete = outputDataModelsTable->rowCount() - 1;
        }
        
        outputDataModelsTable->removeRow(row_delete);
        
        if( outputDataModelsTable->rowCount() == 1 )
        {
            outputDataModelRemoveButton->setEnabled(false);
            outputDataModelMoveUpButton->setEnabled(false);
            outputDataModelMoveDownButton->setEnabled(false);
        }
    }
}


void ComputationalModelRegistrationDialog::moveUpOutputDataModel()
{
    if( outputDataModelsTable->currentRow() > 0 )
    {
        int row1 = outputDataModelsTable->currentRow();
        int row2 = row1 - 1;
        
        swapRows(outputDataModelsTable, row1, row2);
        
        outputDataModelsTable->setCurrentCell(row2, 0);
    }
}


void ComputationalModelRegistrationDialog::moveDownOutputDataModel()
{  
    if( outputDataModelsTable->currentRow() < (outputDataModelsTable->rowCount() - 1) )
    {
        int row1 = outputDataModelsTable->currentRow();
        int row2 = row1 + 1;
        
        swapRows(outputDataModelsTable, row1, row2);
        
        outputDataModelsTable->setCurrentCell(row2, 0);
    }
}

